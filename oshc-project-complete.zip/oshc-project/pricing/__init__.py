"""Advertised-price extraction from saved scraper snapshots."""
