"""Extract advertised prices from one saved scraper snapshot.

Insurer pages usually show "from $X per month" style prices; real OSHC/OVHC
premiums come from quote forms that the scraper does not fill in. Every record
therefore has extraction_method="advertised_text" and must be treated as an
advertised price, not a quote. Discount amounts (save $, gift card, cashback)
are skipped.
"""
from hashlib import sha1
import re

PRICE_RE = re.compile(r'\$\s?(\d{1,3}(?:,\d{3})+(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?)')
PERIODS = [
    ('month', re.compile(r'per\s+month|a\s+month|/\s*(?:mo|month)|monthly|\bpm\b', re.I)),
    ('year', re.compile(r'per\s+year|a\s+year|/\s*(?:yr|year)|annual|yearly|\bpa\b', re.I)),
    ('week', re.compile(r'per\s+week|a\s+week|/\s*(?:wk|week)|weekly|\bpw\b', re.I)),
    ('day', re.compile(r'per\s+day|a\s+day|/\s*day|daily', re.I)),
]
PER_MONTH = {'month': 1.0, 'year': 1 / 12, 'week': 52 / 12, 'day': 365 / 12}
PROMO_RE = re.compile(
    r'\b(save|saving|off|discount|gift\s*card|cash\s*back|cashback|rebate|voucher|free|bonus|excess|'
    r'claim|limit|up\s+to|worth)\b', re.I)
PRICE_WORDS_RE = re.compile(r'\b(from|starting|starts?|premium|cost|costs|price|prices|pay|cover\s+from)\b', re.I)
MIN_MONTHLY, MAX_MONTHLY = 10.0, 2500.0   # sanity bounds for a monthly premium in AUD


def cover_type_for(snapshot, text=''):
    ident = f"{snapshot.get('source_id', '')} {snapshot.get('market_segment', '')}".lower()
    for needle, cover in (('oshc', 'OSHC'), ('student', 'OSHC'), ('ovhc', 'OVHC'), ('visitor', 'OVHC'),
                          ('working', 'OWHC'), ('worker', 'OWHC'), ('485', 'OWHC'), ('owhc', 'OWHC')):
        if needle in ident:
            return cover
    low = text.lower()
    for needle, cover in (('student', 'OSHC'), ('visitor', 'OVHC'), ('working', 'OWHC'), ('worker', 'OWHC')):
        if needle in low:
            return cover
    return 'UNKNOWN'


def _period(text):
    hits = [(m.start(), name) for name, rx in PERIODS for m in [rx.search(text)] if m]
    return min(hits)[1] if hits else None


def extract_price_observations(snapshot):
    """Return a list of observation dicts for one snapshot."""
    paragraphs = list(snapshot.get('paragraphs') or [])
    for key in ('headings',):
        paragraphs += [h if isinstance(h, str) else str(h.get('text', '')) for h in snapshot.get(key) or []]
    out, seen = [], set()
    for text in paragraphs:
        if not isinstance(text, str) or '$' not in text:
            continue
        text = re.sub(r'\s+', ' ', text).strip()
        for m in PRICE_RE.finditer(text):
            window = text[max(0, m.start() - 70): m.end() + 70]
            if PROMO_RE.search(window):
                continue
            period = _period(text[m.end(): m.end() + 40]) or _period(window)
            if not period and not PRICE_WORDS_RE.search(window):
                continue
            amount = float(m.group(1).replace(',', ''))
            monthly = amount * PER_MONTH.get(period, 1.0) if period else None
            if period and not (MIN_MONTHLY <= monthly <= MAX_MONTHLY):
                continue
            if not period and not (MIN_MONTHLY <= amount <= MAX_MONTHLY):
                continue
            key = (amount, period)
            if key in seen:
                continue
            seen.add(key)
            context = window.strip()
            out.append({
                'observation_id': sha1(f"{snapshot.get('source_id')}|{snapshot.get('collected_at')}|{amount}|{period}|{context}".encode()).hexdigest()[:16],
                'collected_at': snapshot.get('collected_at'),
                'organisation': snapshot.get('organisation'),
                'source_id': snapshot.get('source_id'),
                'cover_type': cover_type_for(snapshot, window),
                'price_aud': amount,
                'price_period': period or 'unspecified',
                'price_monthly_aud': round(monthly, 2) if monthly is not None else None,
                'context': context,
                'source_url': snapshot.get('final_url') or snapshot.get('requested_url'),
                'extraction_method': 'advertised_text',
            })
    return out
