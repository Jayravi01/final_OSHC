"""Build pricing outputs from saved scraper snapshots.

python3 -m pricing.run_pricing [--raw-dir data/raw] [--output-dir data/pricing]
python3 -m pricing.run_pricing --manual data/pricing/manual_prices.csv

Outputs (rebuilt each run):
  observations.jsonl   one advertised price per line (upload this to S3 for Athena)
  daily_lowest.csv     lowest monthly price per organisation, cover type and day
                       (input for the HTML dashboard and for Tableau)
"""
import argparse
import csv
import json
from pathlib import Path

from .extract import PER_MONTH, extract_price_observations

ROOT = Path(__file__).resolve().parents[1]
COLUMNS = ['observation_id', 'collected_at', 'organisation', 'source_id', 'cover_type', 'price_aud',
           'price_period', 'price_monthly_aud', 'context', 'source_url', 'extraction_method']


def load_snapshots(raw_dir):
    for path in sorted(Path(raw_dir).rglob('*.json')):
        try:
            data = json.loads(path.read_text(encoding='utf8'))
        except (OSError, json.JSONDecodeError):
            continue
        if isinstance(data, dict) and data.get('collected_at') and data.get('organisation'):
            yield data


def load_manual(path):
    """Manual quote prices: organisation,cover_type,collected_at,price,period[,source_url,note]."""
    rows = []
    with open(path, newline='', encoding='utf8') as f:
        for r in csv.DictReader(f):
            period = (r.get('period') or 'month').strip().lower()
            price = float(r['price'])
            rows.append({
                'observation_id': f"manual-{r['organisation']}-{r['cover_type']}-{r['collected_at']}-{price}",
                'collected_at': r['collected_at'], 'organisation': r['organisation'].strip(),
                'source_id': 'manual_quote', 'cover_type': r['cover_type'].strip().upper(),
                'price_aud': price, 'price_period': period,
                'price_monthly_aud': round(price * PER_MONTH.get(period, 1.0), 2),
                'context': r.get('note', ''), 'source_url': r.get('source_url', ''),
                'extraction_method': 'manual_quote'})
    return rows


def daily_lowest(observations):
    best = {}
    for o in observations:
        if o.get('price_monthly_aud') is None or o['cover_type'] not in ('OSHC', 'OVHC', 'OWHC'):
            continue
        key = (o['organisation'], o['cover_type'], str(o['collected_at'])[:10])
        if key not in best or o['price_monthly_aud'] < best[key]:
            best[key] = o['price_monthly_aud']
    return [{'organisation': k[0], 'cover_type': k[1], 'collected_at': k[2], 'price_aud': v}
            for k, v in sorted(best.items(), key=lambda kv: (kv[0][2], kv[0][0], kv[0][1]))]


def run(raw_dir, output_dir, manual=None):
    observations, seen = [], set()
    for snap in load_snapshots(raw_dir):
        for o in extract_price_observations(snap):
            if o['observation_id'] not in seen:
                seen.add(o['observation_id'])
                observations.append(o)
    if manual:
        observations += load_manual(manual)
    observations.sort(key=lambda o: (str(o['collected_at']), o['organisation'] or ''))
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    with open(out / 'observations.jsonl', 'w', encoding='utf8') as f:
        for o in observations:
            f.write(json.dumps({k: o.get(k) for k in COLUMNS}, ensure_ascii=False) + '\n')
    daily = daily_lowest(observations)
    with open(out / 'daily_lowest.csv', 'w', newline='', encoding='utf8') as f:
        w = csv.DictWriter(f, ['organisation', 'cover_type', 'collected_at', 'price_aud'])
        w.writeheader()
        w.writerows(daily)
    return observations, daily


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--raw-dir', default=str(ROOT / 'data/raw'))
    ap.add_argument('--output-dir', default=str(ROOT / 'data/pricing'))
    ap.add_argument('--manual', help='optional CSV of manually recorded quote prices')
    a = ap.parse_args(argv)
    obs, daily = run(a.raw_dir, a.output_dir, a.manual)
    print(f'{len(obs)} price observations, {len(daily)} daily-lowest rows -> {a.output_dir}')
    if not obs:
        print('No prices found. Run "python3 -m scraper.run_scraper" first, or pass --manual.')


if __name__ == '__main__':
    main()
