"""Read daily lowest prices from Athena, build a Tableau Hyper extract, publish it to Tableau Cloud.

Not tested against a live AWS account or Tableau site. Run it once by hand and read the log.

Environment variables:
  ATHENA_DATABASE (oshc_pricing)   ATHENA_VIEW (daily_lowest_prices)
  ATHENA_OUTPUT   s3://bucket/athena-results/     AWS_REGION (ap-southeast-2)
  TABLEAU_SERVER_URL (https://prod-apsoutheast-a.online.tableau.com)
  TABLEAU_SITE (content URL of your site)   TABLEAU_PROJECT (default "Default")
  TABLEAU_PAT_NAME, TABLEAU_PAT_SECRET   TABLEAU_DATASOURCE (OSHC Prices)
Add --local-csv FILE to build the extract from a CSV instead of Athena (for a dry run).
"""
import argparse
import csv
import os
import sys
import time
from datetime import date
from pathlib import Path


def env(name, default=None, required=False):
    value = os.environ.get(name, default)
    if required and not value:
        sys.exit(f'Missing environment variable {name}')
    return value


def athena_rows():
    import boto3
    client = boto3.client('athena', region_name=env('AWS_REGION', 'ap-southeast-2'))
    sql = f"SELECT organisation, cover_type, collected_at, price_aud FROM {env('ATHENA_DATABASE', 'oshc_pricing')}.{env('ATHENA_VIEW', 'daily_lowest_prices')}"
    qid = client.start_query_execution(
        QueryString=sql, ResultConfiguration={'OutputLocation': env('ATHENA_OUTPUT', required=True)})['QueryExecutionId']
    while True:
        state = client.get_query_execution(QueryExecutionId=qid)['QueryExecution']['Status']
        if state['State'] in ('SUCCEEDED', 'FAILED', 'CANCELLED'):
            break
        time.sleep(1.5)
    if state['State'] != 'SUCCEEDED':
        sys.exit(f"Athena query {state['State']}: {state.get('StateChangeReason', '')}")
    rows, first = [], True
    for page in client.get_paginator('get_query_results').paginate(QueryExecutionId=qid):
        for r in page['ResultSet']['Rows']:
            vals = [c.get('VarCharValue') for c in r['Data']]
            if first:
                first = False
                continue
            rows.append(vals)
    return rows


def csv_rows(path):
    with open(path, newline='', encoding='utf8') as f:
        return [[r['organisation'], r['cover_type'], r['collected_at'], r['price_aud']] for r in csv.DictReader(f)]


def build_hyper(rows, path):
    from tableauhyperapi import (Connection, CreateMode, HyperProcess, Inserter, SqlType,
                                 TableDefinition, TableName, Telemetry)
    table = TableDefinition(TableName('Extract', 'Extract'), [
        TableDefinition.Column('organisation', SqlType.text()),
        TableDefinition.Column('cover_type', SqlType.text()),
        TableDefinition.Column('collected_at', SqlType.date()),
        TableDefinition.Column('price_aud', SqlType.double()),
    ])
    Path(path).unlink(missing_ok=True)
    with HyperProcess(Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as hyper:
        with Connection(hyper.endpoint, path, CreateMode.CREATE_AND_REPLACE) as conn:
            conn.catalog.create_schema('Extract')
            conn.catalog.create_table(table)
            with Inserter(conn, table) as ins:
                for org, cover, day, price in rows:
                    if price in (None, ''):
                        continue
                    ins.add_row([org, cover, date.fromisoformat(str(day)[:10]), float(price)])
                ins.execute()


def publish(path):
    import tableauserverclient as TSC
    auth = TSC.PersonalAccessTokenAuth(env('TABLEAU_PAT_NAME', required=True),
                                       env('TABLEAU_PAT_SECRET', required=True), env('TABLEAU_SITE', ''))
    server = TSC.Server(env('TABLEAU_SERVER_URL', required=True), use_server_version=True)
    with server.auth.sign_in(auth):
        wanted = env('TABLEAU_PROJECT', 'Default')
        project = next((p for p in TSC.Pager(server.projects) if p.name == wanted), None)
        if not project:
            sys.exit(f'Tableau project "{wanted}" not found')
        ds = TSC.DatasourceItem(project.id, name=env('TABLEAU_DATASOURCE', 'OSHC Prices'))
        item = server.datasources.publish(ds, path, TSC.Server.PublishMode.Overwrite)
        print(f'Published data source {item.name} ({item.id})')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--local-csv')
    ap.add_argument('--no-publish', action='store_true', help='build the .hyper file only')
    ap.add_argument('--out', default='oshc_prices.hyper')
    a = ap.parse_args()
    rows = csv_rows(a.local_csv) if a.local_csv else athena_rows()
    print(f'{len(rows)} rows')
    if not rows:
        sys.exit('No rows to publish')
    build_hyper(rows, a.out)
    print(f'Built {a.out}')
    if not a.no_publish:
        publish(a.out)


if __name__ == '__main__':
    main()
