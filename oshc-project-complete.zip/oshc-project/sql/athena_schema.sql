-- Athena schema for the OSHC advertised-price observations.
-- Replace YOUR-BUCKET before running. Run each statement separately in the Athena query editor.
-- If the stack "oshc-pricing-analytics" already created a table, compare it with this one first
-- (Athena: SHOW CREATE TABLE <table>) and keep whichever column names you decide to standardise on.

CREATE DATABASE IF NOT EXISTS oshc_pricing;

CREATE EXTERNAL TABLE IF NOT EXISTS oshc_pricing.observations (
  observation_id      string,
  collected_at        string,   -- ISO 8601 timestamp, UTC
  organisation        string,
  source_id           string,
  cover_type          string,   -- OSHC | OVHC | OWHC | UNKNOWN
  price_aud           double,   -- as advertised on the page
  price_period        string,   -- month | year | week | day | unspecified
  price_monthly_aud   double,   -- price_aud converted to a monthly figure
  context             string,   -- text around the price
  source_url          string,
  extraction_method   string    -- advertised_text | manual_quote
)
ROW FORMAT SERDE 'org.openx.data.jsonserde.JsonSerDe'
WITH SERDEPROPERTIES ('ignore.malformed.json' = 'true')
LOCATION 's3://YOUR-BUCKET/pricing/observations/'
TBLPROPERTIES ('classification' = 'json');

-- Lowest advertised monthly price per organisation, cover type and day.
CREATE OR REPLACE VIEW oshc_pricing.daily_lowest_prices AS
SELECT organisation,
       cover_type,
       CAST(from_iso8601_timestamp(collected_at) AS date) AS collected_at,
       MIN(price_monthly_aud) AS price_aud
FROM oshc_pricing.observations
WHERE price_monthly_aud IS NOT NULL
  AND cover_type IN ('OSHC', 'OVHC', 'OWHC')
GROUP BY 1, 2, 3;

-- Most recent day per organisation and cover type.
CREATE OR REPLACE VIEW oshc_pricing.latest_prices AS
SELECT d.*
FROM oshc_pricing.daily_lowest_prices d
JOIN (SELECT organisation, cover_type, MAX(collected_at) AS max_day
      FROM oshc_pricing.daily_lowest_prices GROUP BY 1, 2) m
  ON d.organisation = m.organisation AND d.cover_type = m.cover_type AND d.collected_at = m.max_day;

-- Change against the price on or before 30 days earlier.
CREATE OR REPLACE VIEW oshc_pricing.price_change_30d AS
SELECT l.organisation, l.cover_type, l.collected_at AS latest_day, l.price_aud AS latest_price,
       p.price_aud AS price_30d_ago,
       (l.price_aud - p.price_aud) / p.price_aud AS change_pct
FROM oshc_pricing.latest_prices l
JOIN oshc_pricing.daily_lowest_prices p
  ON p.organisation = l.organisation AND p.cover_type = l.cover_type
 AND p.collected_at = (SELECT MAX(x.collected_at) FROM oshc_pricing.daily_lowest_prices x
                       WHERE x.organisation = l.organisation AND x.cover_type = l.cover_type
                         AND x.collected_at <= date_add('day', -30, l.collected_at));
