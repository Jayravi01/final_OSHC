# Medibank overseas health market intelligence

Scraper, price extraction, Athena schema, Tableau sync and a standalone HTML dashboard.

## What was added to your original zip
| Path | What it is |
| --- | --- |
| `pricing/` | Reads saved scraper snapshots in `data/raw/` and extracts advertised prices |
| `sql/athena_schema.sql` | Athena database, table and views for the price observations |
| `tableau/sync.py`, `Dockerfile` | Athena to Tableau Hyper extract to Tableau Cloud (untested against live accounts) |
| `dashboard/oshc-dashboard.html` | Standalone dashboard. Open in a browser and load a CSV |
| `data/pricing/SAMPLE_daily_lowest.csv` | Made-up demo data in the dashboard's input format. Not scraped |
| `tests/test_pricing.py` | Tests for the extractor and outputs |

## Run it end to end
```sh
pip install -r requirements.txt
python3 -m scraper.run_scraper                 # saves snapshots to data/raw/
python3 -m pricing.run_pricing                 # writes data/pricing/observations.jsonl + daily_lowest.csv
python3 -m unittest discover -s tests -v
```
Then either:
- **Dashboard:** open `dashboard/oshc-dashboard.html` and load `data/pricing/daily_lowest.csv`.
- **Tableau Desktop:** connect to `data/pricing/daily_lowest.csv` (Text file). Fields: organisation, cover_type, collected_at (Date), price_aud (monthly, AUD).
- **AWS + Tableau Cloud:** upload `observations.jsonl` to `s3://YOUR-BUCKET/pricing/observations/`, run the statements in `sql/athena_schema.sql`, then run `tableau/sync.py` (see its docstring for environment variables).

## Important limits
- Insurer pages mostly show marketing text, and real OSHC/OVHC premiums come from quote forms the scraper does not fill in. `pricing.extract` only picks up advertised prices written in the page text ("from $X per month"), skips discount amounts, and labels every row `advertised_text`. Check its output against the live pages before showing it as market pricing.
- If no prices are found, record quote prices by hand with `data/pricing/manual_prices.template.csv` and run `python3 -m pricing.run_pricing --manual your_file.csv`.
- The deployed stacks (`oshc-pricing-mvp`, `oshc-pricing-analytics`, `oshc-tableau-sync`) were not in the zip you sent. This schema is new. Compare it with the deployed Athena table (`SHOW CREATE TABLE`) before uploading data.
- `.gitignore` excludes `data/raw/**/*.json`, `data/processed/` and `data/runs/`. Zip those separately if you want to share them.
