"""Synthetic Allianz-shaped evidence; not a live market accuracy benchmark."""
import json
from pathlib import Path
import tempfile
import unittest

from processing.allianz import CAMPAIGN_URL, build_campaign, canonical_url, parse_terms
from processing.run_processing import extract


PARAGRAPHS = [
    'Enjoy 8 weeks free with OVHC for Workers. Use code: 8WKSFREE.',
    "New customers who purchase a new eligible policy using promotional code 8WKSFREE between 12.01AM AEST 13 July 2026 and 11.59PM AEST 21 September 2026 ('Promotion Dates') that commences by 31 October 2026 will receive 8 weeks free cover.",
    'To receive 8 weeks free cover, customers must maintain their policy for 60 consecutive days of active cover (including payment of all required premiums).',
    '3rd and 4th month if customers pay premiums monthly;',
    '4th and 5th month if customers pay premiums quarterly;',
    '7th and 8th month if customers pay premiums every 6 months; or',
    '13th and 14th month if customers pay premiums annually.',
    'Eligible policies are Allianz Care Overseas Visitor Health Cover Hospital Care Workers, Everyday Care Workers, Classic Care Workers and Premium Care Workers.',
    'Ineligible policies for this promotion are Value Care, Hospital Care Visitors, Classic Care Visitors and Overseas Student Health Cover policies.',
    'Former and existing Allianz Care Overseas Visitor Health Cover customers are ineligible for this promotion.',
]


class AllianzTests(unittest.TestCase):
    def test_tracking_url_has_same_campaign_identity(self):
        tracked = CAMPAIGN_URL + '?utm_source=website&utm_medium=banner&utm_campaign=q3_2026_workers_promo'
        self.assertEqual(canonical_url(tracked), CAMPAIGN_URL)
        self.assertEqual(canonical_url(CAMPAIGN_URL + '/#terms'), CAMPAIGN_URL)

    def test_terms_dates_scope_products_and_schedule(self):
        row = parse_terms({'paragraphs': PARAGRAPHS})
        self.assertEqual(row['promo_code'], '8WKSFREE')
        self.assertEqual(row['cover_type'], 'OVHC')
        self.assertEqual(row['target_segment'], 'Workers')
        self.assertEqual(row['benefit_total_weeks'], 8)
        self.assertEqual(row['promotion_start'], '2026-07-13')
        self.assertEqual(row['promotion_start_local_time'], '12.01AM')
        self.assertEqual(row['join_by'], '2026-09-21')
        self.assertEqual(row['join_deadline_local_time'], '11.59PM')
        self.assertEqual(row['join_deadline_timezone'], 'AEST')
        self.assertEqual(row['policy_start_by'], '2026-10-31')
        self.assertEqual(row['required_cover_days'], 60)
        self.assertEqual([s['free_months'] for s in row['benefit_schedule']],
                         [[3, 4], [4, 5], [7, 8], [13, 14]])
        self.assertEqual(row['eligible_products'], [
            'Hospital Care Workers', 'Everyday Care Workers',
            'Classic Care Workers', 'Premium Care Workers'])
        self.assertIn('Overseas Student Health Cover', row['excluded_products'])
        self.assertEqual(row['validation_issues'], ['human_review_required'])

    def test_rendered_ordinal_spacing_keeps_payment_schedule(self):
        rendered = [p.replace('3rd', '3 rd').replace('4th', '4 th')
                    .replace('5th', '5 th').replace('7th', '7 th')
                    .replace('8th', '8 th').replace('13th', '13 th')
                    .replace('14th', '14 th') for p in PARAGRAPHS]
        row = parse_terms({'paragraphs': rendered})
        self.assertEqual(len(row['benefit_schedule']), 4)
        self.assertNotIn('payment_schedule_incomplete', row['validation_issues'])

    def test_multiple_pages_build_one_campaign_and_preserve_utm(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            raw, runs = root / 'raw', root / 'runs'
            raw.mkdir()
            runs.mkdir()
            tracked = CAMPAIGN_URL + '?utm_source=website&utm_medium=banner&utm_campaign=q3_2026_workers_promo'
            common = dict(organisation='Allianz Care Australia', http_status=200,
                          collected_at='2026-09-16T07:00:00+00:00')
            discovery = dict(common, source_id='allianz_ovhc',
                             final_url='https://www.allianzcare.com.au/en/visas/visitors-visa-ovhc.html',
                             links=[tracked], headings=['Overseas Visitor Health Cover'], paragraphs=['OVHC'])
            campaign = dict(common, source_id='allianz_8wksfree', final_url=CAMPAIGN_URL,
                            links=[], headings=['Terms and Conditions'], paragraphs=PARAGRAPHS)
            (raw / 'discovery.json').write_text(json.dumps(discovery), encoding='utf8')
            (raw / 'campaign.json').write_text(json.dumps(campaign), encoding='utf8')

            row = build_campaign(raw, runs)
            self.assertTrue(row['campaign_link_verified_in_saved_pages'])
            self.assertEqual(row['discovered_urls'], [tracked])
            self.assertEqual(row['campaign_key'], 'allianz:8WKSFREE')
            self.assertEqual(row['benefit_total_weeks'], 8)
            self.assertEqual(len(row['observations']), 2)

            discovery['links'] = []
            discovery['collected_at'] = '2026-09-16T08:00:00+00:00'
            (raw / 'discovery_new.json').write_text(json.dumps(discovery), encoding='utf8')
            missing = build_campaign(raw, runs)
            self.assertFalse(missing['campaign_link_verified_in_saved_pages'])
            self.assertNotIn('benefit_total_weeks', missing)
            self.assertIn('missing_verified_discovery_link_or_campaign_snapshot', missing['validation_issues'])

    def test_specialist_pages_do_not_create_generic_duplicates(self):
        data = {'source_id': 'allianz_8wksfree', 'organisation': 'Allianz Care Australia',
                'paragraphs': PARAGRAPHS, 'final_url': CAMPAIGN_URL,
                'collected_at': '2026-09-16T07:00:00+00:00'}
        self.assertEqual(extract(data, 'snapshot'), [])


if __name__ == '__main__':
    unittest.main()
