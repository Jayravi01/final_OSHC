import csv
import json
import tempfile
import unittest
from pathlib import Path

from pricing.extract import cover_type_for, extract_price_observations
from pricing.run_pricing import daily_lowest, run


def snap(source_id='bupa_oshc', paragraphs=None, when='2026-09-28T01:00:00+00:00'):
    return {'organisation': 'Bupa', 'source_id': source_id, 'market_segment': 'OSHC', 'collected_at': when,
            'final_url': 'https://example.test', 'paragraphs': paragraphs or []}


class ExtractTests(unittest.TestCase):
    def test_monthly_price(self):
        obs = extract_price_observations(snap(paragraphs=['OSHC from $58.40 per month for a single student.']))
        self.assertEqual(len(obs), 1)
        self.assertEqual(obs[0]['price_monthly_aud'], 58.40)
        self.assertEqual(obs[0]['cover_type'], 'OSHC')

    def test_yearly_price_converted(self):
        obs = extract_price_observations(snap(paragraphs=['Cover from $720 per year.']))
        self.assertEqual(obs[0]['price_monthly_aud'], 60.0)

    def test_promo_amounts_skipped(self):
        obs = extract_price_observations(snap(paragraphs=['Save $50 per month with our offer.',
                                                          'Get a $100 gift card when you join.']))
        self.assertEqual(obs, [])

    def test_out_of_range_skipped(self):
        obs = extract_price_observations(snap(paragraphs=['Premium from $3 per month.']))
        self.assertEqual(obs, [])

    def test_cover_type_from_source(self):
        self.assertEqual(cover_type_for({'source_id': 'nib_ovhc'}), 'OVHC')
        self.assertEqual(cover_type_for({'source_id': 'hbf_ovhc_workers'}), 'OVHC')
        self.assertEqual(cover_type_for({'source_id': 'nib_485_visa'}), 'OWHC')
        self.assertEqual(cover_type_for({'source_id': 'x'}), 'UNKNOWN')


class RunTests(unittest.TestCase):
    def test_daily_lowest_and_outputs(self):
        with tempfile.TemporaryDirectory() as tmp:
            raw = Path(tmp, 'raw', 'bupa')
            raw.mkdir(parents=True)
            for i, text in enumerate(['OSHC from $60 per month.', 'OSHC from $55 per month. Also $70 per month.']):
                (raw / f'{i}.json').write_text(json.dumps(snap(paragraphs=[text], when='2026-09-28T0%d:00:00+00:00' % i)))
            obs, daily = run(Path(tmp, 'raw'), Path(tmp, 'out'))
            self.assertEqual(len(obs), 3)
            self.assertEqual(daily, [{'organisation': 'Bupa', 'cover_type': 'OSHC',
                                      'collected_at': '2026-09-28', 'price_aud': 55.0}])
            rows = list(csv.DictReader(open(Path(tmp, 'out', 'daily_lowest.csv'))))
            self.assertEqual(rows[0]['price_aud'], '55.0')
            self.assertEqual(len(Path(tmp, 'out', 'observations.jsonl').read_text().splitlines()), 3)

    def test_unknown_cover_excluded_from_daily(self):
        self.assertEqual(daily_lowest([{'organisation': 'A', 'cover_type': 'UNKNOWN',
                                        'collected_at': '2026-09-28', 'price_monthly_aud': 50}]), [])


if __name__ == '__main__':
    unittest.main()
