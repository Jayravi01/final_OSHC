"""Synthetic fixtures only: these are not observed market offers."""
import json
from pathlib import Path
import tempfile
import unittest

from processing.run_processing import clean, extract, process
from scraper.base_scraper import decode_html, extract_page_data


def fixture(paragraphs, date='2026-09-15T00:00:00+00:00'):
    return dict(source_id='synthetic', organisation='Synthetic insurer',
                final_url='https://example.com/offer', collected_at=date,
                http_status=200, paragraphs=paragraphs)


class ProcessingTests(unittest.TestCase):
    def test_html_encoding_prefers_utf8_meta_over_latin1_header(self):
        html = '<meta charset="utf-8"><p>We\u2019ll waive waits.</p>'
        self.assertEqual(decode_html(html.encode('utf8'), 'ISO-8859-1'), html)

    def test_two_cards_have_separate_codes_and_multiple_benefits(self):
        # Screenshot-derived expected values; HTML below is a synthetic DOM fixture.
        html = '''<html><body><section>
        <h1>Want up to 10 weeks free plus up to $300 in gift cards?</h1>
        <p>New joins who maintain eligible Hospital and Extras cover can get up to
        10 weeks free plus 15,000 Live Better points ($150 in gift cards) for
        singles/single parents or 30,000 Live Better points ($300 in gift cards)
        for couples/families. We'll also waive 2&6 month waiting periods on Extras.</p>
        <div>Use promo code <button>10WEEKSPLUS</button></div>
        <a href="/hospital-details">Find out more</a></section><section>
        <h2>4 weeks free on Extras cover</h2><p>New joins who maintain eligible Extras cover can get:</p>
        <ul><li>4 weeks free</li><li>$50 gift card</li>
        <li>2&6 month waits waived on eligible extras</li></ul>
        <div>Copy promo code <span>Copied!</span><button>EXTRA4WEEKS</button></div>
        <a href="/extras-details">Find out more</a></section></body></html>'''
        data = extract_page_data(html, 'https://example.com/', 'https://example.com/')
        data.update(source_id='synthetic_homepage', organisation='Synthetic insurer', http_status=200)
        records = extract(data, 'synthetic')
        self.assertEqual(len(records), 2)
        by_code = {r['promo_code']: r for r in records}
        hospital = by_code['10WEEKSPLUS']
        self.assertEqual(hospital['benefits'][0]['qualifier'], 'up_to')
        self.assertEqual(hospital['benefits'][0]['value'], 10)
        rewards = [b for b in hospital['benefits'] if b['type'] == 'reward_points']
        self.assertEqual([(b['value'], b['redemption_value']['value'], b['audience']) for b in rewards],
                         [(15000, 150, ['singles', 'single parents']), (30000, 300, ['couples', 'families'])])
        self.assertFalse(any(b['type'] == 'gift_card' for b in hospital['benefits']))
        extras = by_code['EXTRA4WEEKS']
        self.assertEqual([(b['type'], b.get('value')) for b in extras['benefits']],
                         [('free_cover', 4), ('gift_card', 50), ('waiting_period_waiver', None)])
        self.assertEqual(extras['benefits'][2]['periods'], [2, 6])
        self.assertEqual(extras['detail_links'][0]['url'], 'https://example.com/extras-details')
        self.assertEqual(extras['scope_status'], 'unconfirmed_do_not_publish_as_overseas')
        self.assertIsNone(extras['terms_url'])
        self.assertIsNone(extras['join_by'])
        self.assertIn('block_id', extras['evidence'][0])

    def test_old_encoding_and_absent_code_do_not_invent_missing_evidence(self):
        record = extract(fixture(['Eligible Extras cover: 4 weeks free\u00c2 $50 gift card.']), 'test')[0]
        self.assertEqual(len(record['benefits']), 2)
        self.assertEqual(record['benefits'][0]['value'], 4)
        self.assertIsNone(record['promo_code'])

    def test_navigation_and_generic_free_are_not_promotions(self):
        data = fixture(['Join nib for free', 'We offer a range of health covers.',
                        'Find health cover Get a quote Make a claim 20% off travel insurance'])
        self.assertEqual(extract(data, 'test'), [])

    def test_other_insurance_discount_is_excluded(self):
        self.assertEqual(extract(fixture(['Health members save 15% off travel insurance.']), 'test'), [])

    def test_exclusions_do_not_change_cover_and_evidence_is_exact(self):
        paragraphs = ['Get 6 weeks free on Overseas Workers Health Cover. Offer ends 30 September 2026.',
                      'Use promo code: WORKER6',
                      "Must quote promo code 'WORKER6'. Excludes OSHC and Overseas Visitors Health Cover."]
        records = extract(fixture(paragraphs), 'test')
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]['cover_type'], 'OWHC')
        self.assertEqual(records[0]['join_by'], '2026-09-30')
        self.assertEqual([e['raw_text'] for e in records[0]['evidence']], paragraphs)
        self.assertEqual(records[0]['review_status'], 'needs_review')

    def test_ambiguous_segment_and_invalid_value_are_flagged(self):
        record = extract(fixture(['Get 120% off OSHC and OVHC.']), 'test')[0]
        self.assertIsNone(record['cover_type'])
        self.assertIn('invalid_offer_value', record['validation_issues'])
        self.assertIsNone(record['join_by'])

    def test_encoding_repair_preserves_valid_unicode(self):
        self.assertEqual(clean('\u00c2\xa0Hello \u00e2\x80\x99'), 'Hello \u2019')
        # Unicode escapes preserve multilingual coverage in an English-only source file.
        unicode_sample = '\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22 caf\u00e9'
        self.assertEqual(clean(unicode_sample), unicode_sample)

    def test_repeated_run_and_history_and_missing_offer(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            raw, out = root / 'raw', root / 'out'
            raw.mkdir()
            for index, (weeks, day) in enumerate([(6, 15), (8, 16), (8, 17)]):
                data = fixture([f'Get {weeks} weeks free on OSHC. Offer ends 30 September 2026.',
                                'Use promo code: STUDENT'], f'2026-09-{day}T00:00:00+00:00')
                (raw / f'{index}.json').write_text(json.dumps(data))
            # A later successful page without an offer must not imply termination.
            (raw / 'absent.json').write_text(json.dumps(fixture(['Information only'], '2026-09-18T00:00:00+00:00')))
            (raw / 'bad.json').write_text('{broken')
            process(raw, out)
            before = {p.name: p.read_bytes() for p in out.iterdir()}
            process(raw, out)
            self.assertEqual(before, {p.name: p.read_bytes() for p in out.iterdir()})
            history = json.loads((out / 'promotion_candidates.json').read_text())
            self.assertEqual([r['version'] for r in history], [1, 2, 2])
            events = json.loads((out / 'candidate_events.json').read_text())
            self.assertEqual([e['event_type'] for e in events], ['first_observed_candidate', 'candidate_changed'])
            self.assertEqual(len(json.loads((out / 'source_audit.json').read_text())['errors']), 1)
            self.assertEqual(json.loads((out / 'validated_promotions.json').read_text()), [])
            self.assertEqual(json.loads((out / 'review_queue.json').read_text()), [])


if __name__ == '__main__':
    unittest.main()
