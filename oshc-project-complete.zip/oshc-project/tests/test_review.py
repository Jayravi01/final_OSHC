"""Human decisions persist separately and only apply to matching evidence."""
import json
from pathlib import Path
import re
import tempfile
import unittest

from processing.review import (ReviewError, apply_decisions, interactive_review,
                               record_decision, specialist_fingerprint)
from processing.run_processing import process


def snapshot(weeks, collected_at):
    return {
        'source_id': 'synthetic',
        'organisation': 'Synthetic insurer',
        'final_url': 'https://example.com/offer',
        'collected_at': collected_at,
        'http_status': 200,
        'paragraphs': [
            f'Get {weeks} weeks free on OSHC. Offer ends 30 September 2026.',
            'Use promo code: STUDENT8',
        ],
    }


def unscoped_snapshot(collected_at):
    # No OSHC/OVHC/OWHC wording, so extract() cannot confirm this is the
    # project's overseas market and scopes it unconfirmed_do_not_publish_as_overseas.
    return {
        'source_id': 'synthetic_homepage', 'organisation': 'Synthetic insurer',
        'final_url': 'https://example.com/', 'collected_at': collected_at,
        'http_status': 200,
        'paragraphs': ['New members save with 8 weeks free when you join today.',
                       'Use promo code: MEMBER8'],
    }


class HumanReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.raw = self.root / 'raw'
        self.output = self.root / 'processed'
        self.approvals = self.root / 'approvals/promotion_decisions.json'
        self.raw.mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def _process(self):
        process(self.raw, self.output, self.approvals)

    def test_approved_matching_candidate_is_validated_and_removed_from_queue(self):
        (self.raw / 'one.json').write_text(json.dumps(
            snapshot(8, '2026-09-20T00:00:00+00:00')))
        self._process()
        candidate = json.loads((self.output / 'review_queue.json').read_text())[0]
        record_decision(candidate['record_id'], 'approved', 'Test reviewer',
                        'Compared with terms', {'cover_type': 'OSHC'},
                        self.output, self.approvals,
                        '2026-09-20T01:00:00+00:00')
        self._process()

        self.assertEqual(json.loads((self.output / 'review_queue.json').read_text()), [])
        validated = json.loads((self.output / 'validated_promotions.json').read_text())
        self.assertEqual(len(validated), 1)
        self.assertEqual(validated[0]['review_status'], 'approved')
        self.assertEqual(validated[0]['cover_type'], 'OSHC')
        self.assertEqual(validated[0]['approval']['reviewer'], 'Test reviewer')
        self.assertTrue(validated[0]['pre_approval_validation_issues'])
        self.assertEqual(validated[0]['validation_issues'], [])

    def test_changed_evidence_makes_old_approval_stale(self):
        (self.raw / 'one.json').write_text(json.dumps(
            snapshot(8, '2026-09-20T00:00:00+00:00')))
        self._process()
        candidate = json.loads((self.output / 'review_queue.json').read_text())[0]
        record_decision(candidate['record_id'], 'approved', 'Test reviewer',
                        output_dir=self.output, approvals_file=self.approvals,
                        reviewed_at='2026-09-20T01:00:00+00:00')

        (self.raw / 'two.json').write_text(json.dumps(
            snapshot(6, '2026-09-21T00:00:00+00:00')))
        self._process()
        self.assertEqual(json.loads(
            (self.output / 'validated_promotions.json').read_text()), [])
        queue = json.loads((self.output / 'review_queue.json').read_text())
        self.assertEqual(len(queue), 1)
        self.assertEqual(queue[0]['approval_status'],
                         'stale_decision_requires_review')
        audit = json.loads((self.output / 'approval_audit.json').read_text())
        self.assertEqual(len(audit['stale']), 1)

    def test_rejection_resolves_candidate_without_validating_it(self):
        (self.raw / 'one.json').write_text(json.dumps(
            snapshot(8, '2026-09-20T00:00:00+00:00')))
        self._process()
        candidate = json.loads((self.output / 'review_queue.json').read_text())[0]
        record_decision(candidate['record_id'], 'rejected', 'Test reviewer',
                        output_dir=self.output, approvals_file=self.approvals,
                        reviewed_at='2026-09-20T01:00:00+00:00')
        self._process()
        self.assertEqual(json.loads((self.output / 'review_queue.json').read_text()), [])
        self.assertEqual(json.loads(
            (self.output / 'validated_promotions.json').read_text()), [])

    def test_negative_monitor_cannot_be_approved_as_a_promotion(self):
        (self.raw / 'one.json').write_text(json.dumps(
            snapshot(8, '2026-09-20T00:00:00+00:00')))
        self._process()
        with self.assertRaises(ReviewError):
            record_decision('hbf:ovhc_monitor', 'approved', 'Test reviewer',
                            output_dir=self.output,
                            approvals_file=self.approvals)

    def test_unconfirmed_scope_cannot_be_approved_without_a_cover_type_correction(self):
        (self.raw / 'one.json').write_text(json.dumps(
            unscoped_snapshot('2026-09-20T00:00:00+00:00')))
        self._process()
        candidate = json.loads((self.output / 'review_queue.json').read_text())[0]
        self.assertEqual(candidate['scope_status'],
                         'unconfirmed_do_not_publish_as_overseas')
        with self.assertRaises(ReviewError):
            record_decision(candidate['record_id'], 'approved', 'Test reviewer',
                            output_dir=self.output, approvals_file=self.approvals)
        self._process()
        # The rejected attempt must not have been persisted or validated.
        self.assertEqual(json.loads((self.output / 'validated_promotions.json').read_text()), [])
        self.assertFalse(self.approvals.exists())

    def test_unconfirmed_scope_can_be_approved_with_an_explicit_cover_type(self):
        (self.raw / 'one.json').write_text(json.dumps(
            unscoped_snapshot('2026-09-20T00:00:00+00:00')))
        self._process()
        candidate = json.loads((self.output / 'review_queue.json').read_text())[0]
        record_decision(candidate['record_id'], 'approved', 'Test reviewer',
                        'Confirmed against the OSHC terms page', {'cover_type': 'OSHC'},
                        self.output, self.approvals)
        self._process()
        validated = json.loads((self.output / 'validated_promotions.json').read_text())
        self.assertEqual(len(validated), 1)
        self.assertEqual(validated[0]['cover_type'], 'OSHC')

    def test_interactive_review_guides_negative_monitor_to_option_six(self):
        (self.raw / 'one.json').write_text(json.dumps(
            snapshot(8, '2026-09-20T00:00:00+00:00')))
        self._process()
        # hbf:ovhc_monitor is a negative monitoring result whenever no HBF
        # snapshot exists; Approve does not apply to it, only option 6 does.
        messages = []
        state = {'asked_name': False, 'current_target': None, 'tried_approve': False}

        def fake_input(prompt):
            if not state['asked_name']:
                state['asked_name'] = True
                return 'Charin'
            header = next((m for m in reversed(messages) if re.match(r'^\[\d+/\d+\] ', m)), '')
            state['current_target'] = header.split('] ', 1)[1] if header else None
            if prompt == 'Review note: ':
                return 'note'
            assert prompt == 'Decision: '
            if state['current_target'] != 'hbf:ovhc_monitor':
                return 's'
            if not state['tried_approve']:
                state['tried_approve'] = True
                return '1'
            return '6'

        saved = interactive_review(
            self.output, self.approvals,
            input_fn=fake_input, output_fn=messages.append,
        )
        self.assertEqual(saved, 1)
        guidance = next(m for m in messages if m.startswith('Cannot choose this option'))
        self.assertIn('option 6', guidance)
        decisions = json.loads(self.approvals.read_text())
        self.assertEqual(decisions[0]['decision'], 'no_active_promotion')
        self.assertEqual(decisions[0]['target_id'], 'hbf:ovhc_monitor')

    def test_specialist_fingerprint_ignores_run_metadata_but_not_terms(self):
        base = {'campaign_key': 'example:OFFER', 'promo_code': 'OFFER',
                'terms_evidence': {'paragraphs': ['8 weeks free']},
                'latest_attempts': {'source': {'status': 'success'}},
                'collected_at': '2026-09-20T00:00:00+00:00'}
        rerun = dict(base, latest_attempts={'source': {'status': 'failed'}},
                     collected_at='2026-09-21T00:00:00+00:00')
        changed = dict(base, terms_evidence={'paragraphs': ['6 weeks free']})
        self.assertEqual(specialist_fingerprint(base),
                         specialist_fingerprint(rerun))
        self.assertNotEqual(specialist_fingerprint(base),
                            specialist_fingerprint(changed))

    def test_correction_cannot_overwrite_audit_identity(self):
        candidate = {
            'record_id': 'record', 'fingerprint': 'fingerprint',
            'validation_issues': ['human_review_required'],
        }
        decision = {
            'decision_id': 'decision', 'target_id': 'record',
            'target_type': 'candidate', 'fingerprint': 'fingerprint',
            'decision': 'approved', 'reviewer': 'Test reviewer',
            'reviewed_at': '2026-09-20T01:00:00+00:00',
            'field_corrections': {'record_id': 'replaced'},
        }
        with self.assertRaises(ReviewError):
            apply_decisions([candidate], [], [decision])

    def test_interactive_review_saves_numbered_choice_without_target_id(self):
        (self.raw / 'one.json').write_text(json.dumps(
            snapshot(8, '2026-09-20T00:00:00+00:00')))
        self._process()
        answers = iter(['Test reviewer', '1', 'Checked terms', 'q'])
        messages = []
        saved = interactive_review(
            self.output, self.approvals,
            input_fn=lambda prompt: next(answers), output_fn=messages.append,
        )
        self.assertEqual(saved, 1)
        decisions = json.loads(self.approvals.read_text())
        self.assertEqual(decisions[0]['decision'], 'approved')
        self.assertEqual(decisions[0]['reviewer'], 'Test reviewer')
        self.assertTrue(any('Synthetic insurer' in message for message in messages))

    def test_interactive_review_guides_unscoped_approval_to_the_cli(self):
        (self.raw / 'one.json').write_text(json.dumps(
            unscoped_snapshot('2026-09-20T00:00:00+00:00')))
        self._process()
        target_id = json.loads((self.output / 'review_queue.json').read_text())[0]['record_id']
        # The pending list also carries one unlinked placeholder per specialist
        # campaign (Bupa/Allianz/HBF/Medibank all build a record even with no
        # matching evidence). Skip those and press Approve twice, then Skip, on
        # the one record under test, regardless of where it falls in the order.
        messages = []
        state = {'asked_name': False, 'current_target': None, 'attempts': 0}

        def fake_input(prompt):
            if not state['asked_name']:
                state['asked_name'] = True
                return 'Charin'
            header = next((m for m in reversed(messages) if re.match(r'^\[\d+/\d+\] ', m)), '')
            state['current_target'] = header.split('] ', 1)[1] if header else None
            if prompt == 'Review note: ':
                return 'note'
            assert prompt == 'Decision: '
            if state['current_target'] != target_id:
                return 's'
            state['attempts'] += 1
            return '1' if state['attempts'] <= 2 else 's'

        saved = interactive_review(
            self.output, self.approvals,
            input_fn=fake_input, output_fn=messages.append,
        )
        self.assertEqual(saved, 0)
        self.assertFalse(self.approvals.exists())
        guidance = next(m for m in messages if 'approve' in m and target_id in m)
        self.assertIn(f'python3 -m processing.review approve {target_id}', guidance)
        self.assertIn('--reviewer "Charin"', guidance)
        self.assertIn('field cover_type', guidance)


if __name__ == '__main__':
    unittest.main()
