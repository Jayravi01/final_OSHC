"""Synthetic Medibank-shaped evidence; not a live market accuracy benchmark.

Medibank WORKER8: 8 weeks free OWHC, promo code WORKER8, ends 30 Sep 2026.
Explicitly excludes OSHC, OVHC, ahm covers and corporate covers.
"""
import json
from pathlib import Path
import tempfile
import unittest

from processing.medibank import (
    CAMPAIGN_URL, OSHC_URL, PROMO_CODE, ELIGIBLE_PRODUCTS,
    build_campaign, canonical_url, parse_terms,
)
from processing.run_processing import extract

PARAGRAPHS = [
    'Want 8 weeks free on truly Australian cover?',
    'Join and maintain Medibank Overseas Workers Health Cover and you could get '
    '8 weeks free. Offer ends 30 September 2026. T&Cs apply.',
    'New members and existing Medibank or ahm OSHC members only. '
    'Use promo code WORKER8.',
    'Must take out eligible Medibank Overseas Workers Health covers by '
    '30 September 2026. Offer available via phone, web, messaging and in store.',
    'For new members on new memberships residing in Australia on a working visa '
    'or Medibank members who are transferring from Medibank OSHC or ahm OSHC.',
    'Must be over the age of 18. Must quote promo code \'WORKER8\' when joining. '
    'Member must sign up to direct debit.',
    'Excludes Overseas Visitors Health Cover, all corporate covers, all Corporate '
    'Non-resident covers, all residential hospital and extras covers, Overseas '
    'Students Health Cover (OSHC), Ambulance Cover, ahm covers, and other '
    'selected covers.',
    'Member must maintain direct debit and keep policy premium payments up to '
    'date and hold eligible cover for 42 consecutive days from the policy start '
    'date to get next 8 weeks free.',
    'Not available with any other offer except the Overseas Extras only offer.',
    'Overseas Workers Base Hospital cover.',
    'Overseas Workers Standard Hospital and Medical cover.',
    'Overseas Workers Premium Hospital, Medical and Extras cover.',
    'Overseas Workers Advanced Hospital and Medical cover.',
]


class MedibankTests(unittest.TestCase):

    def test_canonical_url_strips_tracking(self):
        tracked = CAMPAIGN_URL + '?utm_source=google&utm_campaign=worker8_2026'
        self.assertEqual(canonical_url(tracked), canonical_url(CAMPAIGN_URL))

    def test_terms_promo_code_weeks_dates_and_eligibility(self):
        row = parse_terms({'paragraphs': PARAGRAPHS})
        # Cover type
        self.assertEqual(row['cover_type'], 'OWHC')
        self.assertEqual(row['target_segment'], 'Workers / Graduates')
        # Promo code
        self.assertEqual(row['promo_code'], PROMO_CODE)
        # Benefit
        self.assertEqual(row['benefit_total_weeks'], 8)
        # Offer end
        self.assertEqual(row['offer_end'], '2026-09-30')
        # Hold period
        self.assertEqual(row['required_hold_days'], 42)
        # Age
        self.assertEqual(row['minimum_age'], 18)
        # Direct debit
        self.assertTrue(row['direct_debit_required'])
        # Eligible member types
        self.assertIn('new_members', row['eligible_member_types'])
        self.assertIn('medibank_or_ahm_oshc_transferees', row['eligible_member_types'])
        # Combinable offer
        self.assertIn('Overseas Extras only offer', row['combinable_offer'])
        # Eligible products
        for product in ELIGIBLE_PRODUCTS:
            self.assertIn(product, row['eligible_products'])
        # Exclusions
        self.assertTrue(len(row['exclusion_evidence']) > 0)
        # Always needs human review
        self.assertIn('human_review_required', row['validation_issues'])

    def test_changed_terms_return_none_fields(self):
        changed = parse_terms({'paragraphs': ['Changed terms — check manually.']})
        self.assertIsNone(changed['promo_code'])
        self.assertIsNone(changed['benefit_total_weeks'])
        self.assertIsNone(changed['offer_end'])
        self.assertIn('promo_code_missing_or_changed', changed['validation_issues'])

    def test_build_campaign_verified_link_and_terms(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            raw, runs = root / 'raw', root / 'runs'
            raw.mkdir(); runs.mkdir()
            common = dict(organisation='Medibank', http_status=200,
                          collected_at='2026-09-16T06:00:00+00:00')
            campaign = dict(common, source_id='medibank_worker8_campaign',
                            final_url=CAMPAIGN_URL, links=[],
                            headings=['Want 8 weeks free?'],
                            paragraphs=PARAGRAPHS)
            working_visas = dict(common, source_id='medibank_working_visas',
                                 final_url=WORKING_VISAS_URL,
                                 links=[CAMPAIGN_URL],
                                 headings=['Overseas Workers Health Cover'],
                                 paragraphs=['Use promo code WORKER8 for 8 weeks free.'])
            (raw / 'campaign.json').write_text(json.dumps(campaign), encoding='utf-8')
            (raw / 'working_visas.json').write_text(json.dumps(working_visas), encoding='utf-8')
            row = build_campaign(raw, runs)
            self.assertTrue(row['campaign_link_verified_in_saved_pages'])
            self.assertEqual(row['campaign_key'], 'medibank:WORKER8')
            self.assertEqual(row['promo_code'], PROMO_CODE)
            self.assertEqual(row['benefit_total_weeks'], 8)
            self.assertEqual(row['cover_type'], 'OWHC')
            self.assertIn('terms_evidence', row)

    def test_build_campaign_missing_link_sets_validation_issues(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            raw, runs = root / 'raw', root / 'runs'
            raw.mkdir(); runs.mkdir()
            common = dict(organisation='Medibank', http_status=200,
                          collected_at='2026-09-16T06:00:00+00:00')
            working_visas = dict(common, source_id='medibank_working_visas',
                                 final_url=WORKING_VISAS_URL,
                                 links=[], headings=[], paragraphs=[])
            (raw / 'working_visas.json').write_text(json.dumps(working_visas), encoding='utf-8')
            row = build_campaign(raw, runs)
            self.assertFalse(row['campaign_link_verified_in_saved_pages'])
            self.assertNotIn('benefit_total_weeks', row)
            self.assertIn('missing_verified_campaign_snapshot_or_discovery_link',
                          row['validation_issues'])

    def test_specialist_pages_do_not_create_generic_duplicates(self):
        data = {
            'source_id': 'medibank_worker8_campaign',
            'organisation': 'Medibank',
            'paragraphs': PARAGRAPHS,
            'final_url': CAMPAIGN_URL,
            'collected_at': '2026-09-16T06:00:00+00:00',
        }
        self.assertEqual(extract(data, 'snapshot'), [])

    def test_supporting_page_keeps_non_worker8_candidate(self):
        data = {
            'source_id': 'medibank_oshc',
            'organisation': 'Medibank',
            'paragraphs': [
                'Existing OSHC members can get 8 weeks free on eligible Extras cover.',
                'Use promo code EXTRAS8COVER.',
            ],
            'promotion_blocks': [],
            'structured_offers': [],
            'final_url': OSHC_URL,
            'collected_at': '2026-09-16T06:00:00+00:00',
            'source_metadata': {},
        }
        rows = extract(data, 'snapshot')
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['promo_code'], 'EXTRAS8COVER')

    def test_supporting_page_deduplicates_worker8_candidate(self):
        data = {
            'source_id': 'medibank_working_visas',
            'organisation': 'Medibank',
            'paragraphs': ['Get 8 weeks free on Overseas Workers Health Cover.',
                           'Use promo code WORKER8.'],
            'promotion_blocks': [],
            'structured_offers': [],
            'final_url': WORKING_VISAS_URL,
            'collected_at': '2026-09-16T06:00:00+00:00',
            'source_metadata': {},
        }
        self.assertEqual(extract(data, 'snapshot'), [])


WORKING_VISAS_URL = 'https://www.medibank.com.au/overseas-health-insurance/working-visas/'


if __name__ == '__main__':
    unittest.main()
