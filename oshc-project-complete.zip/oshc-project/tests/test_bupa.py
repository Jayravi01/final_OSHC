"""Synthetic Bupa-shaped markup; not a live market accuracy benchmark."""
import json
from pathlib import Path
import tempfile
import unittest
from scraper.base_scraper import extract_page_data
from processing.bupa import TERMS_URL, parse_terms, build_campaign

PARAGRAPHS = [
 '8 weeks free, with the value of your free weeks based on your level of cover.',
 'Unless you pay yearly, in most cases, your 6 weeks free will be applied 28 days after you join. The remaining 2 weeks are applied once you’ve held eligible cover for 13 months, extending the date on the following billing cycle.',
 'If you join through a Bupa consultant and pay yearly, your first payment will be reduced by the value of 6 weeks. The remaining 2 weeks are applied once you’ve held eligible cover for 13 months. This means your third yearly payment will be reduced by the value of 2 weeks.',
 'take out a policy between 01/09/2026 and 11:59pm AEDT on 12/10/2026 and commence your policy by 12/11/2026;',
 'use promo code FREE8 if joining online.',
 'An Eligible Health Insurance Policy is a working Overseas Visitors Cover Hospital + Extra product issued by Bupa listed below:',
 'Essential 50 Visitors Cover', 'This offer excludes :', 'Overseas Student Health Cover;',
 'All non-working Overseas Visitors Cover products;', '4. General']


class BupaTests(unittest.TestCase):
    def test_attribute_text_and_terms_link_survive(self):
        html = '''<modular-text text="Get up to 8 weeks free"></modular-text>
        <modular-text text="&lt;p&gt;Use promo code: &lt;click-to-copy&gt;FREE8&lt;/click-to-copy&gt;&lt;/p&gt;&lt;a href='/campaigns/health-insurance/ovcfree8weeks'&gt;T&amp;Cs apply&lt;/a&gt;"></modular-text>'''
        data = extract_page_data(html, 'https://www.bupa.com.au/test', 'https://www.bupa.com.au/test')
        self.assertEqual(data['raw_html'], html)
        self.assertIn(TERMS_URL, data['links'])
        self.assertTrue(any('FREE8' in p for p in data['paragraphs']))
        self.assertEqual(len(data['component_evidence']), 2)

    def test_terms_dates_stages_and_worker_scope(self):
        row = parse_terms({'paragraphs': PARAGRAPHS})
        self.assertEqual(row['cover_type'], 'OWHC')
        self.assertEqual(row['join_from'], '2026-09-01')
        self.assertEqual(row['join_by'], '2026-10-12')
        self.assertEqual(row['policy_start_by'], '2026-11-12')
        self.assertEqual(row['join_deadline_timezone'], 'AEDT')
        self.assertEqual(row['benefit_total_weeks'], 8)
        self.assertEqual([s['weeks'] for s in row['benefit_stages'] if 'weeks' in s], [6, 2])
        self.assertEqual(row['benefit_stages'][2]['third_payment_free_weeks'], 2)
        self.assertIn('Overseas Student Health Cover;', row['excluded_products_evidence'])
        self.assertEqual(row['validation_issues'], ['human_review_required'])
        changed = parse_terms({'paragraphs':['Changed terms - check manually']})
        self.assertIsNone(changed['join_by'])
        self.assertIsNone(changed['benefit_total_weeks'])

    def test_multiple_pages_one_review_and_terms_require_link(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            common = dict(organisation='Bupa', http_status=200, collected_at='2026-09-16T06:00:00+00:00')
            terms = dict(common, source_id='bupa_free8_terms', final_url=TERMS_URL, paragraphs=PARAGRAPHS)
            (root / 'terms.json').write_text(json.dumps(terms))
            for source in ['bupa_visitors', 'bupa_working']:
                data = dict(common, source_id=source, final_url='https://www.bupa.com.au/'+source,
                            paragraphs=[], links=[TERMS_URL], component_evidence=[{'text':'Get up to 8 weeks free. Use promo code FREE8'}])
                (root / f'{source}.json').write_text(json.dumps(data))
            row = build_campaign(root, root / 'logs')
            self.assertEqual(len(row['observations']), 2)
            self.assertTrue(row['terms_link_verified_in_saved_pages'])
            self.assertEqual(row['promo_code'], 'FREE8')
            for p in root.glob('bupa_*.json'):
                d=json.loads(p.read_text());d['links']=[];p.write_text(json.dumps(d))
            missing = build_campaign(root, root / 'logs')
            self.assertFalse(missing['terms_link_verified_in_saved_pages'])
            self.assertNotIn('benefit_total_weeks', missing)
