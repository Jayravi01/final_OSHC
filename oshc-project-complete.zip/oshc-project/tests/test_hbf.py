"""Synthetic HBF-shaped evidence; not a live market accuracy benchmark.

HBF offers OVHC only. No OSHC, no OWHC.
Student visas (500, 580, 590) explicitly excluded by HBF.
Domestic PHI promotions are out of scope.
"""
import json
from pathlib import Path
import tempfile
import unittest

from processing.hbf import (
    WORKERS_SOURCE, VISITORS_SOURCE, HUB_SOURCE,
    build_campaign, canonical_url,
)

OVHC_PARAGRAPHS_NO_PROMO = [
    'Overseas Visitors Health Cover is health insurance for people in Australia '
    'on visitor, work, or temporary visas.',
    'Working Visa Hospital cover. Policies start at $59.90 per month.',
    'Working Visa Hospital and Medical cover. Policies start at $197.17 per month.',
    'Standard Overseas Visitors cover. Policies start at $170.65 per month.',
    'Student visas: Unfortunately we do not offer any cover for visas 500, 580 and 590.',
]

OVHC_PARAGRAPHS_WITH_PROMO = OVHC_PARAGRAPHS_NO_PROMO + [
    'Get 6 weeks free on your Working Visa Hospital cover when you join before '
    '31 October 2026. New OVHC members only. T&Cs apply.',
]

DOMESTIC_PHI_PARAGRAPHS = [
    'Up to 12 weeks free plus up to $200 gift card for new hospital and extras members.',
    'The offer does not apply to Overseas Visitors Health Cover.',
]

GENERIC_MEMBER_PERKS = [
    'HBF Member Perks Explore special offers and member discounts.',
    'HBF members get access to discounts on gym memberships, shopping, '
    'entertainment and more.',
]


class HBFTests(unittest.TestCase):

    def _write_snap(self, root, source_id, paragraphs, url):
        data = {
            'source_id': source_id,
            'organisation': 'HBF',
            'http_status': 200,
            'collected_at': '2026-09-16T06:00:00+00:00',
            'final_url': url,
            'headings': ['Overseas Visitors Health Cover'],
            'paragraphs': paragraphs,
            'links': [],
        }
        (root / f'{source_id}.json').write_text(json.dumps(data), encoding='utf-8')

    def test_no_ovhc_promotion_returns_clean_record(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            raw, runs = root / 'raw', root / 'runs'
            raw.mkdir(); runs.mkdir()
            self._write_snap(raw, WORKERS_SOURCE, OVHC_PARAGRAPHS_NO_PROMO,
                             'https://www.hbf.com.au/health-insurance/overseas/working-in-australia')
            row = build_campaign(raw, runs)
            self.assertFalse(row['promotion_detected'])
            self.assertEqual(row['review_status'], 'no_active_ovhc_promotion')
            self.assertEqual(row['validation_issues'], [])
            self.assertEqual(row['cover_type'], 'OVHC')
            self.assertFalse(row['oshc_offered'])
            self.assertFalse(row['owhc_offered'])

    def test_ovhc_promotion_detected_flags_for_review(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            raw, runs = root / 'raw', root / 'runs'
            raw.mkdir(); runs.mkdir()
            self._write_snap(raw, WORKERS_SOURCE, OVHC_PARAGRAPHS_WITH_PROMO,
                             'https://www.hbf.com.au/health-insurance/overseas/working-in-australia')
            row = build_campaign(raw, runs)
            self.assertTrue(row['promotion_detected'])
            self.assertEqual(row['review_status'], 'needs_review')
            self.assertIn('ovhc_promotion_detected_human_review_required',
                          row['validation_issues'])
            self.assertIn('promotion_evidence', row)

    def test_domestic_phi_promotion_not_surfaced_as_ovhc(self):
        """Domestic PHI promotion paragraphs must not trigger OVHC promotion flag."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            raw, runs = root / 'raw', root / 'runs'
            raw.mkdir(); runs.mkdir()
            # Mix domestic PHI copy with OVHC page content — should NOT trigger.
            self._write_snap(raw, WORKERS_SOURCE,
                             OVHC_PARAGRAPHS_NO_PROMO + DOMESTIC_PHI_PARAGRAPHS,
                             'https://www.hbf.com.au/health-insurance/overseas/working-in-australia')
            row = build_campaign(raw, runs)
            self.assertFalse(row['promotion_detected'])

    def test_generic_member_perks_not_surfaced_as_ovhc(self):
        """Site-wide member discounts are not evidence of an OVHC join offer."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            raw, runs = root / 'raw', root / 'runs'
            raw.mkdir(); runs.mkdir()
            self._write_snap(raw, WORKERS_SOURCE,
                             OVHC_PARAGRAPHS_NO_PROMO + GENERIC_MEMBER_PERKS,
                             'https://www.hbf.com.au/health-insurance/overseas/working-in-australia')
            row = build_campaign(raw, runs)
            self.assertFalse(row['promotion_detected'])

    def test_multiple_sources_all_recorded(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            raw, runs = root / 'raw', root / 'runs'
            raw.mkdir(); runs.mkdir()
            for sid, url in [
                (WORKERS_SOURCE, 'https://www.hbf.com.au/health-insurance/overseas/working-in-australia'),
                (VISITORS_SOURCE, 'https://www.hbf.com.au/health-insurance/overseas/visiting-australia'),
                (HUB_SOURCE, 'https://www.hbf.com.au/health-insurance/overseas/what-is-ovhc'),
            ]:
                self._write_snap(raw, sid, OVHC_PARAGRAPHS_NO_PROMO, url)
            row = build_campaign(raw, runs)
            self.assertEqual(len(row['observations']), 3)

    def test_canonical_url_strips_tracking(self):
        url = 'https://www.hbf.com.au/health-insurance/overseas/working-in-australia'
        tracked = url + '?utm_source=google&utm_campaign=ovhc'
        self.assertEqual(canonical_url(tracked), canonical_url(url))


if __name__ == '__main__':
    unittest.main()
