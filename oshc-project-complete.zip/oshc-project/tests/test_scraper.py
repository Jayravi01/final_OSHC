"""Regression checks for evidence retention, immutable storage and failed runs."""
from hashlib import sha256
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import requests

from scraper.base_scraper import (PDF_MEDIA_TYPE, download_page, extract_document_data,
                                  extract_page_data, is_pdf, pdf_paragraphs,
                                  scrape_source)
from scraper.storage import save_json
from scraper.run_scraper import run_sources
from processing.run_processing import extract


def minimal_pdf(lines):
    """Build a small valid PDF in memory so no binary fixture is stored in the repository."""
    content = b"BT /F1 12 Tf 12 TL 20 260 Td\n"
    for line in lines:
        content += b"(" + line.encode("ascii") + b") Tj T*\n"
    content += b"ET"
    objects = [
        b"<</Type/Catalog/Pages 2 0 R>>",
        b"<</Type/Pages/Kids[3 0 R]/Count 1>>",
        b"<</Type/Page/Parent 2 0 R/MediaBox[0 0 300 300]/Contents 4 0 R"
        b"/Resources<</Font<</F1 5 0 R>>>>>>",
        b"<</Length " + str(len(content)).encode() + b">>stream\n" + content + b"\nendstream",
        b"<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>",
    ]
    out, offsets = bytearray(b"%PDF-1.4\n"), []
    for number, body in enumerate(objects, start=1):
        offsets.append(len(out))
        out += str(number).encode() + b" 0 obj" + body + b"endobj\n"
    start = len(out)
    out += b"xref\n0 " + str(len(objects) + 1).encode() + b"\n0000000000 65535 f \n"
    for offset in offsets:
        out += ("%010d 00000 n \n" % offset).encode()
    out += (b"trailer<</Size " + str(len(objects) + 1).encode() + b"/Root 1 0 R>>\n"
            b"startxref\n" + str(start).encode() + b"\n%%EOF\n")
    return bytes(out)


class PdfSourceTests(unittest.TestCase):
    def test_pdf_is_detected_by_media_type_or_signature(self):
        self.assertTrue(is_pdf(b'%PDF-1.7 ...', 'application/octet-stream'))
        self.assertTrue(is_pdf(b'anything', PDF_MEDIA_TYPE))
        self.assertFalse(is_pdf('<html></html>', 'text/html'))

    def test_pdf_paragraphs_rejoin_wrapped_lines(self):
        text = '(a) Join by 31 October 2026 to\nreceive 8 weeks free.\n\n(b) Excludes OSHC.'
        self.assertEqual(pdf_paragraphs(text),
                         ['(a) Join by 31 October 2026 to receive 8 weeks free.',
                          '(b) Excludes OSHC.'])
        # A document without blank lines keeps all of its text in one paragraph.
        self.assertEqual(pdf_paragraphs('one\ntwo'), ['one two'])
        self.assertEqual(pdf_paragraphs('   \n\n  '), [])

    def test_pdf_terms_extract_text_instead_of_empty_snapshot(self):
        # Decoding PDF bytes as HTML previously produced a successful-looking
        # snapshot with no paragraphs and the hash of an empty string.
        pdf = minimal_pdf(['8 weeks free on OSHC. Join by 31 October 2026.'])
        data = extract_document_data(pdf, 'https://example.com/terms',
                                     'https://example.com/terms', PDF_MEDIA_TYPE)
        self.assertEqual(data['media_type'], PDF_MEDIA_TYPE)
        self.assertTrue(any('8 weeks free on OSHC' in p for p in data['paragraphs']))
        self.assertGreater(data['word_count'], 0)
        self.assertEqual(data['quality_warnings'], [])
        self.assertEqual(data['pdf_page_count'], 1)
        self.assertIsNone(data['raw_html'])
        self.assertEqual(data['raw_document_hash'], sha256(pdf).hexdigest())
        data.update(source_id='terms', organisation='Test')
        self.assertEqual(extract(data, 's')[0]['cover_type'], 'OSHC')

    def test_pdf_download_returns_undecoded_bytes(self):
        pdf = minimal_pdf(['Terms and Conditions'])
        response = requests.Response()
        response.status_code = 200
        response._content = pdf
        response.headers['content-type'] = 'application/pdf;charset=UTF-8'
        response.url = 'https://example.com/terms.pdf'
        with patch('scraper.base_scraper.requests.get', return_value=response):
            payload, final_url, status, media_type = download_page('https://example.com/terms.pdf')
        self.assertIsInstance(payload, bytes)
        self.assertEqual(payload, pdf)
        self.assertEqual(media_type, PDF_MEDIA_TYPE)
        self.assertEqual((final_url, status), ('https://example.com/terms.pdf', 200))


class ScraperTests(unittest.TestCase):
    def test_configured_403_uses_browser_fallback(self):
        response = requests.Response()
        response.status_code = 403
        forbidden = requests.HTTPError('Forbidden', response=response)
        source = {
            'source_id': 'browser_source',
            'organisation': 'Test',
            'market_segment': 'OVHC',
            'url': 'https://example.com/ovhc',
            'collection_method': 'browser_on_403',
        }
        rendered = ('<html><title>OVHC</title><p>8 weeks free on OVHC.</p></html>',
                    source['url'], 200, 'text/html')
        with patch('scraper.base_scraper.download_page', side_effect=forbidden), \
                patch('scraper.base_scraper.download_page_browser',
                      return_value=rendered) as browser:
            data = scrape_source(source)
        browser.assert_called_once_with(source['url'], headless=True)
        self.assertEqual(data['collection_method'], 'browser')
        self.assertEqual(data['http_status'], 200)
        self.assertIn('8 weeks free on OVHC.', data['paragraphs'])

    def test_short_offer_survives_and_hash_covers_headings(self):
        first = extract_page_data('<h1>First</h1><p>20% off OSHC</p>', 'https://example.com', 'https://example.com')
        second = extract_page_data('<h1>Second</h1><p>20% off OSHC</p>', 'https://example.com', 'https://example.com')
        self.assertIn('20% off OSHC', first['paragraphs'])
        self.assertNotEqual(first['raw_html_hash'], second['raw_html_hash'])
        self.assertEqual(first['content_hash'], second['content_hash'])
        first.update(source_id='test', organisation='Test')
        self.assertEqual(extract(first, 's')[0]['cover_type'], 'OSHC')

    def test_snapshots_do_not_overwrite_or_escape_root(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = dict(organisation='Test', source_id='../../test', value=1)
            a = save_json(data, tmp)
            b = save_json(dict(data, value=2), tmp)
            self.assertNotEqual(a, b)
            self.assertEqual(json.loads(a.read_text())['value'], 1)
            self.assertEqual(json.loads(b.read_text())['value'], 2)
            self.assertTrue(a.is_relative_to(Path(tmp)))
            self.assertEqual(len(list(Path(tmp).rglob('*.json'))), 2)

    def test_failed_attempt_persisted_and_next_source_runs(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            response = requests.Response()
            response.status_code = 403
            error = requests.HTTPError('Forbidden', response=response)
            sources = [dict(source_id='bad', url='https://example.com/bad'),
                       dict(source_id='ok', url='https://example.com/ok')]
            result = dict(source_id='ok', organisation='Test', http_status=200, final_url='https://example.com/ok')
            with patch('scraper.run_scraper.scrape_source', side_effect=[error, result]):
                code = run_sources(sources, root / 'raw', root / 'logs', delay=0)
            self.assertEqual(code, 1)
            logs = [json.loads(p.read_text()) for p in (root / 'logs').glob('*.json')]
            self.assertEqual({x['status'] for x in logs}, {'success', 'failed'})
            self.assertEqual(next(x for x in logs if x['status'] == 'failed')['http_status'], 403)
            self.assertEqual(len(list((root / 'raw').rglob('*.json'))), 1)

    def test_worker_terms_do_not_add_excluded_segments_or_rewards(self):
        html = '''<section><p>Join Overseas Workers Health Cover for 8 weeks free.
        Offer ends 30 September 2026.</p><p>Use promo code: WORKER8</p></section>
        <section><p>Offer available until 30 September 2026. Must quote promo code 'WORKER8'.
        For members transferring from OSHC. Excludes OSHC and Overseas Visitors Health Cover.
        Offer available via phone, web, messaging and in store.
        Member must maintain direct debit and hold eligible cover for 42 consecutive days.</p></section>
        <section><p>Live Better rewards up to $400 every year.</p></section>'''
        data = extract_page_data(html, 'https://example.com', 'https://example.com')
        data.update(source_id='worker', organisation='Medibank')
        rows = extract(data, 's')
        self.assertEqual(len(rows), 1)
        row = rows[0]
        self.assertEqual(row['cover_type'], 'OWHC')
        self.assertEqual(row['conditions']['required_cover_days'], 42)
        self.assertTrue(row['conditions']['direct_debit_required'])
        self.assertEqual(row['conditions']['excluded_cover_types'], ['OSHC', 'OVHC'])
        self.assertEqual(row['conditions']['redemption_channels'], ['phone', 'web', 'messaging', 'in store'])
        self.assertEqual(row['terms_url'], 'https://example.com')
        self.assertEqual(len(row['benefits']), 1)
        self.assertEqual(row['review_status'], 'needs_review')

    def test_empty_page_is_flagged(self):
        data = extract_page_data('<html></html>', 'https://example.com', 'https://example.com')
        self.assertIn('no_paragraphs_extracted', data['quality_warnings'])

    def test_extras_stages_and_audience_are_not_oshc_discount(self):
        data = extract_page_data('''<section><p>Join eligible Medibank extras cover for
        6 weeks free in your second month, plus 2 more weeks free in your second year.
        We'll waive any 2 & 6 month waiting periods.</p><p>Use promo code EXTRAS8COVER</p></section>
        <p>For existing members on Medibank OSHC, ahm OSHC and Medibank Overseas Workers Health Cover
        who join eligible extras. Must quote promo code EXTRAS8COVER and set up direct debit when joining.</p>''',
        'https://example.com', 'https://example.com')
        data.update(source_id='student', organisation='Medibank')
        row = extract(data, 's')[0]
        self.assertIsNone(row['cover_type'])
        self.assertEqual(row['offer_relationship'], 'extras_cross_sell_to_overseas_members')
        self.assertEqual(row['eligible_existing_member_cover_types'], ['OSHC', 'OWHC'])
        self.assertEqual([b['value'] for b in row['benefits'] if b['type']=='free_cover'], [6, 2])
        self.assertEqual(row['benefits'][1]['timing_text'], 'in your second year')
        self.assertTrue(row['conditions']['direct_debit_required'])
        self.assertEqual(row['benefits'][2]['type'], 'waiting_period_waiver')
