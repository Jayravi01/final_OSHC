"""Synthetic nib-shaped page data; not a live market accuracy benchmark."""
import json
import unittest

from bs4 import BeautifulSoup

from scraper.base_scraper import (embedded_json, extract_page_data, strip_personal_data,
                                  structured_offers)
from processing.run_processing import benefits, extract

HOMEPAGE_URL = 'https://www.nib.com.au/'

OFFER = {
    'name': 'nib Sept Oct 2026 Offer',
    'headerText': 'Skip the 2 & 6 month wait on Extras',
    'offerName1': 'Skip the 2 & 6 month Extras wait!',
    'offerName2': '',
    'supportingText1': 'Choose a combined Hospital + Extras cover online by 31 October.',
    'supportingText2': 'Winning at Health Insurance',
    'supportingText3': '',
    'termsAndConditions': 'Available to new members with Australian residency.',
    'termsAndConditionsLink': 'https://www.nib.com.au/docs/join-offer-terms-sept-2026',
    'startDate': '2026-09-01',
    'endDate': '2026-10-31',
    'visas': [],
    'waiverOnly': True,
    'lastModifiedBy': 'staff.member@nib.com.au',
}


def homepage(offer=OFFER, **page):
    """A page whose offer is published in embedded data rather than in HTML text."""
    payload = {'props': {'pageProps': dict({'offer': offer, 'showOfferOnHomepageHero': False}, **page)}}
    return ('<html><body><h1>Win at Health Insurance</h1>'
            '<p>Find the right health insurance for you.</p>'
            '<script id="__NEXT_DATA__" type="application/json">'
            + json.dumps(payload) + '</script></body></html>')


class NibPageDataTests(unittest.TestCase):
    def test_personal_data_is_removed_from_captured_page_data(self):
        cleaned = strip_personal_data({'lastModifiedBy': 'a@b.com', 'name': 'Offer',
                                       'nested': [{'author': 'x', 'endDate': '2026-10-31'}]})
        self.assertEqual(cleaned, {'name': 'Offer', 'nested': [{'endDate': '2026-10-31'}]})

    def test_offer_is_captured_from_page_data_not_page_text(self):
        data = extract_page_data(homepage(), HOMEPAGE_URL, HOMEPAGE_URL)
        # The offer wording is absent from the visible text the page renders.
        self.assertNotIn('Skip the 2 & 6 month wait on Extras', data['full_text'])
        offer = data['structured_offers'][0]
        self.assertEqual(offer['offer_name'], 'nib Sept Oct 2026 Offer')
        self.assertEqual((offer['starts_at'], offer['ends_at']), ('2026-09-01', '2026-10-31'))
        self.assertEqual(offer['terms_url'], OFFER['termsAndConditionsLink'])
        self.assertEqual(offer['visas'], [])
        self.assertFalse(offer['displayed_on_homepage_hero'])
        self.assertNotIn('lastModifiedBy', offer['raw_offer'])
        self.assertNotIn('staff.member@nib.com.au', json.dumps(offer))

    def test_other_publishers_are_not_read_as_nib_page_data(self):
        data = extract_page_data(homepage(), 'https://example.com/', 'https://example.com/')
        self.assertEqual(data['structured_offers'], [])

    def test_unreadable_page_data_is_skipped_without_failing_collection(self):
        html = '<script id="__NEXT_DATA__" type="application/json">{not json</script><p>Cover</p>'
        data = extract_page_data(html, HOMEPAGE_URL, HOMEPAGE_URL)
        self.assertEqual(embedded_json(BeautifulSoup(html, 'html.parser')), [])
        self.assertEqual(data['structured_offers'], [])
        self.assertIn('Cover', data['full_text'])

    def test_offer_without_an_offer_object_is_not_invented(self):
        html = '<script id="__NEXT_DATA__" type="application/json">{"props":{"pageProps":{}}}</script>'
        soup = BeautifulSoup(html, 'html.parser')
        self.assertEqual(len(embedded_json(soup)), 1)
        self.assertEqual(structured_offers(soup, HOMEPAGE_URL), [])


class NibCandidateTests(unittest.TestCase):
    def snapshot(self, html=None):
        data = extract_page_data(html or homepage(), HOMEPAGE_URL, HOMEPAGE_URL)
        data.update(source_id='nib_homepage', organisation='nib', http_status=200,
                    collected_at='2026-09-16T08:00:00+00:00')
        return data

    def test_waiver_wording_covers_skip_and_waive_forms(self):
        for text in ["We'll waive any 2 & 6 month waiting periods",
                     '2&6 month waits waived on eligible extras',
                     'Skip the 2 & 6 month wait on Extras',
                     'Skip the 2 & 6 month Extras wait!',
                     "We'll waive the 2 and 6 month wait on Extras"]:
            found = [b for b in benefits(text) if b['type'] == 'waiting_period_waiver']
            self.assertEqual([b['periods'] for b in found], [[2, 6]], text)
        # Stating that a waiting period applies is not a waiver.
        self.assertEqual(benefits('A 2 & 6 month waiting period applies to extras.'), [])

    def test_published_offer_dates_are_preferred_over_prose(self):
        row = extract(self.snapshot(), 'snapshot')[0]
        self.assertEqual(row['offer_name'], 'nib Sept Oct 2026 Offer')
        self.assertEqual((row['starts_at'], row['join_by']), ('2026-09-01', '2026-10-31'))
        self.assertEqual(row['terms_url'], OFFER['termsAndConditionsLink'])
        self.assertEqual(row['benefits'][0]['type'], 'waiting_period_waiver')
        self.assertEqual(row['benefits'][0]['periods'], [2, 6])
        self.assertEqual(row['published_visa_targeting'], [])
        self.assertEqual(row['evidence'][0]['offer_id'], 'structured_offer_0')
        self.assertNotIn('join_by_not_extracted', row['validation_issues'])
        self.assertEqual(row['review_status'], 'needs_review')

    def test_resident_offer_is_not_published_as_overseas(self):
        row = extract(self.snapshot(), 'snapshot')[0]
        self.assertIsNone(row['cover_type'])
        self.assertEqual(row['scope_status'], 'unconfirmed_do_not_publish_as_overseas')
        self.assertIn('cover_type_missing_or_ambiguous', row['validation_issues'])

    def test_unrecognised_benefit_wording_is_flagged_not_dropped(self):
        offer = dict(OFFER, headerText='A brand new kind of member bonus',
                     offerName1='', supportingText1='', supportingText2='',
                     termsAndConditions='')
        rows = extract(self.snapshot(homepage(offer)), 'snapshot')
        # A live campaign is never discarded because its wording is unfamiliar.
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['benefits'], [])
        self.assertIn('benefit_wording_not_recognised', rows[0]['validation_issues'])
        self.assertEqual(rows[0]['join_by'], '2026-10-31')

    def test_offer_identity_survives_a_wording_change(self):
        first = extract(self.snapshot(), 'snapshot')[0]
        reworded = dict(OFFER, headerText='Skip the 2 & 6 month wait on Extras cover today')
        second = extract(self.snapshot(homepage(reworded)), 'snapshot')[0]
        # The published offer name anchors identity, so this is a change, not a new offer.
        self.assertEqual(first['record_id'], second['record_id'])
        self.assertNotEqual(first['fingerprint'], second['fingerprint'])


if __name__ == '__main__':
    unittest.main()
