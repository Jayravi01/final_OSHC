"""Evidence-based Medibank WORKER8 OWHC review assembled from saved snapshots.

Medibank offers OSHC, OVHC and OWHC (Overseas Workers Health Cover).
The active campaign as of September 2026 is WORKER8 — 8 weeks free on
Medibank Overseas Workers Health Cover (OWHC), ending 30 September 2026.

This module targets the OWHC WORKER8 campaign only.
Medibank OSHC has no active new-member promotion of its own.
Medibank OVHC (visitors) has no active promotion as of September 2026.
"""
import json
import re
from datetime import datetime
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

CAMPAIGN_URL = 'https://www.medibank.com.au/overseas-health-insurance/c/worker8/'
WORKING_VISAS_URL = 'https://www.medibank.com.au/overseas-health-insurance/working-visas/'
OVERSEAS_HUB_URL = 'https://www.medibank.com.au/overseas-health-insurance/'
OSHC_URL = 'https://www.medibank.com.au/overseas-health-insurance/oshc/'

CAMPAIGN_SOURCE = 'medibank_worker8_campaign'
WORKING_VISAS_SOURCE = 'medibank_working_visas'
OVERSEAS_HUB_SOURCE = 'medibank_overseas'
OSHC_SOURCE = 'medibank_oshc'
SPECIALIST_SOURCES = {CAMPAIGN_SOURCE, WORKING_VISAS_SOURCE,
                      OVERSEAS_HUB_SOURCE, OSHC_SOURCE}

PROMO_CODE = 'WORKER8'

ELIGIBLE_PRODUCTS = [
    'Overseas Workers Base Hospital',
    'Overseas Workers Standard Hospital and Medical',
    'Overseas Workers Premium Hospital, Medical and Extras',
    'Overseas Workers Advanced Hospital and Medical',
]

EXCLUDED_COVERS = [
    'Overseas Visitors Health Cover',
    'Overseas Students Health Cover (OSHC)',
    'ahm covers',
    'Ambulance Cover',
    'corporate covers',
]


def canonical_url(value):
    """Remove tracking/query data while retaining a stable page identity."""
    parts = urlsplit(value)
    path = parts.path.rstrip('/') or '/'
    return urlunsplit((parts.scheme.lower(), parts.netloc.lower(), path, '', ''))


def parse_terms(data):
    """Parse fields from the Medibank WORKER8 campaign page."""
    paragraphs = data.get('paragraphs', [])
    text = ' '.join(' '.join(p.split()) for p in paragraphs)

    def match(pattern):
        return re.search(pattern, text, re.I)

    # --- Promo code ---
    code = match(r"(?:promo(?:tion)?\s+code\s+['\u2018\u2019\"]*\s*)(WORKER8)\b")

    # --- Offer end date ---
    offer_end = match(
        r'(?:offer\s+ends?|available\s+until|by)\s+(\d{1,2}\s+\w+\s+\d{4})'
    )

    # --- Total weeks free ---
    total_weeks = match(r'(\d+)\s+weeks?\s+free')

    # --- Required hold period ---
    hold_days = match(r'hold\s+eligible\s+cover\s+for\s+(\d+)\s+consecutive\s+days')

    # --- Minimum age ---
    age = match(r'(?:must\s+be\s+|over\s+the\s+age\s+of\s+)(\d+)')

    # --- Eligible member types ---
    new_members = bool(match(r'new\s+members\s+on\s+new\s+memberships'))
    oshc_transfer = bool(match(
        r'Medibank\s+members\s+who\s+are\s+transferring\s+from\s+Medibank\s+OSHC\s+or\s+ahm\s+OSHC'
    ))

    # --- Direct debit required ---
    direct_debit = bool(match(r'sign\s+up\s+to\s+direct\s+debit'))

    # --- Not available with other offers ---
    offer_combination = match(
        r'Not\s+available\s+with\s+any\s+other\s+offer\s+except\s+the\s+(Overseas\s+Extras\s+only\s+offer)'
    )

    # --- Excluded covers evidence ---
    exclusion_evidence = [
        p for p in paragraphs
        if re.search(r'Excludes|excludes|not\s+available', p, re.I)
        and re.search(r'OSHC|Visitors|ahm|Ambulance|corporate', p, re.I)
    ]

    # --- Eligible product evidence ---
    eligible_evidence = [
        p for p in paragraphs
        if any(prod.lower() in p.lower() for prod in ELIGIBLE_PRODUCTS)
    ]

    # --- Customer eligibility evidence ---
    customer_evidence = [
        p for p in paragraphs
        if re.search(
            r'new\s+member|working\s+visa|transferring\s+from|over\s+the\s+age|direct\s+debit',
            p, re.I
        )
    ]

    # --- Validation ---
    issues = ['human_review_required']
    if not code:
        issues.append('promo_code_missing_or_changed')
    if not offer_end:
        issues.append('offer_end_date_missing_or_changed')
    if not total_weeks:
        issues.append('benefit_total_weeks_missing_or_changed')
    if not hold_days:
        issues.append('required_hold_days_missing_or_changed')

    try:
        offer_end_iso = (
            datetime.strptime(offer_end[1].strip(), '%d %B %Y').date().isoformat()
            if offer_end else None
        )
    except ValueError:
        offer_end_iso = None
        issues.append('offer_end_date_parse_failed')

    return {
        'product_name': 'Medibank Overseas Workers Health Cover',
        'target_segment': 'Workers / Graduates',
        'cover_type': 'OWHC',
        'promo_code': code[1].upper() if code else None,
        'benefit_total_weeks': int(total_weeks[1]) if total_weeks else None,
        'offer_end': offer_end_iso,
        'required_hold_days': int(hold_days[1]) if hold_days else None,
        'minimum_age': int(age[1]) if age else None,
        'direct_debit_required': direct_debit,
        'eligible_member_types': (
            (['new_members'] if new_members else []) +
            (['medibank_or_ahm_oshc_transferees'] if oshc_transfer else [])
        ),
        'combinable_offer': offer_combination[1] if offer_combination else None,
        'eligible_products': ELIGIBLE_PRODUCTS,
        'excluded_covers': EXCLUDED_COVERS,
        'eligible_products_evidence': eligible_evidence,
        'exclusion_evidence': exclusion_evidence,
        'customer_eligibility_evidence': customer_evidence,
        'validation_issues': issues,
    }


def _latest_snapshots(raw_dir):
    """Return the most recent snapshot per source_id for Medibank sources."""
    latest = {}
    for path in Path(raw_dir).rglob('*.json'):
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
            if data.get('organisation') != 'Medibank' or data.get('http_status') != 200:
                continue
            source = data['source_id']
            if source not in latest or data['collected_at'] > latest[source][1]['collected_at']:
                latest[source] = (path, data)
        except (ValueError, KeyError, OSError):
            continue
    return latest


def _latest_attempts(run_dir):
    """Return the most recent run attempt per source_id for Medibank sources."""
    attempts = {}
    for path in Path(run_dir).glob('medibank_*.json'):
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
            source = data['source_id']
            if source not in attempts or data['started_at'] > attempts[source]['started_at']:
                attempts[source] = data
        except (ValueError, KeyError, OSError):
            continue
    return attempts


def build_campaign(raw_dir, run_dir):
    """Build Medibank WORKER8 OWHC campaign record from saved snapshots."""
    latest = _latest_snapshots(raw_dir)
    attempts = _latest_attempts(run_dir)
    observations = []

    # --- Primary: WORKER8 campaign page ---
    campaign = latest.get(CAMPAIGN_SOURCE)
    campaign_identity_verified = False
    if campaign:
        path, data = campaign
        page_text = ' '.join(data.get('headings', []) + data.get('paragraphs', []))
        campaign_identity_verified = (
            canonical_url(data['final_url']) == canonical_url(CAMPAIGN_URL)
            and bool(re.search(r'WORKER8', page_text, re.I))
            and bool(re.search(r'8\s+weeks?\s+free', page_text, re.I))
        )
        observations.append({
            'source_id': CAMPAIGN_SOURCE,
            'source_role': 'offer_detail_and_terms',
            'url': data['final_url'],
            'collected_at': data['collected_at'],
            'snapshot_path': str(path.resolve()),
            'campaign_identity_verified': campaign_identity_verified,
            'latest_attempt': attempts.get(CAMPAIGN_SOURCE),
        })

    # --- Discovery: working visas hub ---
    working_visas = latest.get(WORKING_VISAS_SOURCE)
    campaign_linked = False
    if working_visas:
        path, data = working_visas
        campaign_linked = canonical_url(CAMPAIGN_URL) in [
            canonical_url(u) for u in data.get('links', [])
        ] or bool(re.search(r'WORKER8', ' '.join(data.get('paragraphs', [])), re.I))
        observations.append({
            'source_id': WORKING_VISAS_SOURCE,
            'source_role': 'campaign_discovery',
            'url': data['final_url'],
            'collected_at': data['collected_at'],
            'snapshot_path': str(path.resolve()),
            'campaign_linked': campaign_linked,
            'latest_attempt': attempts.get(WORKING_VISAS_SOURCE),
        })

    # --- Secondary: overseas hub and OSHC page ---
    for source_id, role in [
        (OVERSEAS_HUB_SOURCE, 'overseas_hub'),
        (OSHC_SOURCE, 'oshc_discovery'),
    ]:
        snap = latest.get(source_id)
        if snap:
            path, data = snap
            observations.append({
                'source_id': source_id,
                'source_role': role,
                'url': data['final_url'],
                'collected_at': data['collected_at'],
                'snapshot_path': str(path.resolve()),
                'latest_attempt': attempts.get(source_id),
            })

    linked = campaign_linked and campaign_identity_verified

    record = {
        'campaign_key': 'medibank:WORKER8',
        'promo_code': PROMO_CODE,
        'canonical_url': CAMPAIGN_URL,
        'review_status': 'needs_review',
        'observations': observations,
        'campaign_link_verified_in_saved_pages': linked,
        'latest_attempts': attempts,
        'note': (
            'Medibank OWHC WORKER8 campaign — 8 weeks free for new workers or '
            'Medibank/ahm OSHC transferees joining eligible Overseas Workers '
            'Health Cover by 30 September 2026. '
            'Explicitly excludes OVHC, OSHC, ahm covers, and corporate covers. '
            'Medibank OSHC and OVHC have no separate active promotion as of '
            'September 2026 — those pages are monitored via secondary sources.'
        ),
    }

    if linked:
        path, data = campaign
        record.update(parse_terms(data))
        record['terms_evidence'] = {
            'source_url': data['final_url'],
            'canonical_url': canonical_url(data['final_url']),
            'collected_at': data['collected_at'],
            'snapshot_path': str(path.resolve()),
            'headings': data.get('headings', []),
            'paragraphs': data.get('paragraphs', []),
        }
    else:
        record['validation_issues'] = [
            'missing_verified_campaign_snapshot_or_discovery_link',
            'human_review_required',
        ]

    return record
