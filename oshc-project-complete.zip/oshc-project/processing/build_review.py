"""Build page-by-page Markdown review files from saved source evidence."""
import json
from pathlib import Path
from processing.run_processing import (ROOT, extract, digest, BUPA_SPECIALIST_SOURCES,
                                       ALLIANZ_SPECIALIST_SOURCES, HBF_SPECIALIST_SOURCES,
                                       MEDIBANK_SPECIALIST_SOURCES,
                                       MEDIBANK_WORKER8_SUPPORTING_SOURCES)
from scraper.sources import SOURCES


def main():
    output = ROOT / 'data/review'
    output.mkdir(parents=True, exist_ok=True)
    latest = {}
    for path in (ROOT / 'data/raw').rglob('*.json'):
        data = json.loads(path.read_text())
        source = data['source_id']
        if source not in latest or data['collected_at'] > latest[source][1]['collected_at']:
            latest[source] = (path, data)
    for source, (path, data) in latest.items():
        rows = extract(data, digest(data['collected_at']))
        if source in BUPA_SPECIALIST_SOURCES:
            specialist_message = 'FREE8: see [linked campaign review](bupa_free8.md). Generic candidate counting is disabled for this source.'
        elif source in ALLIANZ_SPECIALIST_SOURCES:
            specialist_message = '8WKSFREE: see [linked campaign review](allianz_8wksfree_campaign.md). Generic candidate counting is disabled for this source.'
        elif source in HBF_SPECIALIST_SOURCES:
            specialist_message = 'HBF OVHC: see [linked specialist review](hbf_ovhc.md). Generic candidate counting is disabled for this source.'
        elif source in MEDIBANK_SPECIALIST_SOURCES:
            specialist_message = 'WORKER8: see [linked campaign review](medibank_worker8.md). Generic candidate counting is disabled for this source.'
        elif source in MEDIBANK_WORKER8_SUPPORTING_SOURCES:
            specialist_message = (f'Candidate offers: {len(rows)}. All require human review. '
                                  'WORKER8 is deduplicated into [the linked campaign review](medibank_worker8.md).')
        else:
            specialist_message = f'Candidate offers: {len(rows)}. All require human review.'
        lines = [f'# Review: {source}', '',
                 f"Source: {data['final_url']}", '',
                 f"Collected (UTC): {data['collected_at']}", '',
                 f"HTTP status: {data['http_status']}", '',
                 f"Page title: {data['page_title']}", '',
                 f'Raw snapshot: [{path.name}]({path.resolve()})', '',
                 f"Extracted paragraphs: {len(data['paragraphs'])}; promotion blocks: {len(data.get('promotion_blocks', []))}", '',
                 specialist_message, '',
                 'Zero candidates means the rules did not detect an offer in this snapshot, not that the provider has no offers.', '',
                 'This is extracted evidence, not a rendered copy of the page. Numbers below are paragraph indices used by the processor.', '',
                 '## Candidate details', '']
        for row in rows:
            lines += ['```json', json.dumps(row, indent=2, ensure_ascii=False), '```', '']
        lines += ['## Component attribute evidence', '']
        for component in data.get('component_evidence', []):
            lines += [f"Component {component['component_index']}:", '', component['text'], '']
        lines += ['## Headings', '']
        lines += [f'- {h}' for h in data['headings']]
        lines += ['', '## Extracted paragraphs', '']
        for index, paragraph in enumerate(data['paragraphs']):
            lines += [f'### Paragraph {index}', '', paragraph, '']
        lines += ['## Captured links (destinations not automatically fetched)', '']
        lines += [f'- {url}' for url in data['links']]
        (output / f'{source}.md').write_text('\n'.join(lines) + '\n', encoding='utf8')
        print(source, len(rows), output / f'{source}.md')

    # A failed latest collection still needs a review page; never substitute a
    # screenshot or an older provider page for missing saved evidence.
    latest_attempts = {}
    for path in (ROOT / 'data/runs').glob('*.json'):
        try:
            attempt = json.loads(path.read_text(encoding='utf8'))
            source = attempt['source_id']
            if source not in latest_attempts or attempt['started_at'] > latest_attempts[source][1]['started_at']:
                latest_attempts[source] = (path, attempt)
        except (ValueError, KeyError, OSError):
            continue
    for configured in SOURCES:
        source = configured['source_id']
        if source in latest:
            continue
        attempt_path, attempt = latest_attempts.get(source, (None, {}))
        lines = [f'# Review: {source}', '',
                 f"Configured source: {configured['url']}", '',
                 'No valid saved snapshot is available for this source.', '',
                 f"Latest attempt status: {attempt.get('status', 'not_run')}", '',
                 f"HTTP status: {attempt.get('http_status')}", '',
                 f"Error type: {attempt.get('error_type')}", '',
                 f"Error: {attempt.get('error')}", '']
        if attempt_path:
            lines += [f'Attempt log: [{attempt_path.name}]({attempt_path.resolve()})', '']
        lines += ['No page content or promotion fields were inferred from the failed attempt.', '']
        (output / f'{source}.md').write_text('\n'.join(lines), encoding='utf8')
        print(source, 'no valid snapshot', output / f'{source}.md')

    from processing.bupa import build_campaign
    campaign = build_campaign(ROOT / 'data/raw', ROOT / 'data/runs')
    lines = ['# Bupa FREE8 - review before approval', '',
             'One provisional campaign with multiple source observations. Not automatically approved.', '',
             '| Field | Extracted value |', '| --- | --- |']
    for key in ['promo_code', 'product_name', 'target_segment', 'benefit_total_weeks', 'join_from',
                'join_by', 'join_deadline_local_time', 'join_deadline_timezone', 'policy_start_by']:
        lines.append(f"| {key} | {campaign.get(key)} |")
    lines += ['', '## Benefit stages (parts of the total, not extra benefits)', '']
    for stage in campaign.get('benefit_stages', []):
        lines += ['```json', json.dumps(stage, ensure_ascii=False, indent=2), '```', '']
    lines += ['## Observed pages', '']
    for observation in campaign['observations']:
        lines += [f"- [{observation['source_id']}]({observation['source_id']}.md): {observation['url']} ({observation['collected_at']})"]
    lines += ['', '## Full terms evidence', '']
    for p in campaign.get('terms_evidence', {}).get('paragraphs', []):
        lines += [p, '']
    lines += ['## Validation issues', '', str(campaign['validation_issues']), '',
              'Latest collection attempt results and raw evidence paths are in data/processed/bupa_free8_review.json.']
    (output / 'bupa_free8.md').write_text('\n'.join(lines) + '\n', encoding='utf8')

    from processing.allianz import build_campaign as build_allianz_campaign
    campaign = build_allianz_campaign(ROOT / 'data/raw', ROOT / 'data/runs')
    lines = ['# Allianz 8WKSFREE - review before approval', '',
             'One provisional campaign linked from the OVHC product page to its detail and terms page. Not automatically approved.', '',
             '| Field | Extracted value |', '| --- | --- |']
    for key in ['promo_code', 'product_name', 'cover_type', 'target_segment',
                'benefit_total_weeks', 'promotion_start', 'promotion_start_local_time',
                'promotion_start_timezone', 'join_by', 'join_deadline_local_time',
                'join_deadline_timezone', 'policy_start_by', 'required_cover_days']:
        lines.append(f"| {key} | {campaign.get(key)} |")
    lines += ['', '## Benefit schedule', '']
    for stage in campaign.get('benefit_schedule', []):
        lines += ['```json', json.dumps(stage, ensure_ascii=False, indent=2), '```', '']
    lines += ['## Eligible products', '']
    lines += [f'- {product}' for product in campaign.get('eligible_products', [])]
    lines += ['', '## Excluded products', '']
    lines += [f'- {product}' for product in campaign.get('excluded_products', [])]
    lines += ['', '## Observed pages', '']
    for observation in campaign['observations']:
        page = observation['source_id'] + '.md'
        lines += [f"- [{observation['source_id']}]({page}): {observation['url']} ({observation['collected_at']})"]
        for url in observation.get('campaign_links', []):
            lines += [f'  - Discovered campaign URL: {url}']
    lines += ['', '## Full terms evidence', '']
    for heading in campaign.get('terms_evidence', {}).get('headings', []):
        lines += [f'- Heading: {heading}']
    for paragraph in campaign.get('terms_evidence', {}).get('paragraphs', []):
        lines += [paragraph, '']
    lines += ['## Validation issues', '', str(campaign['validation_issues']), '',
              'Latest collection attempt results and raw evidence paths are in data/processed/allianz_8wksfree_review.json.']
    (output / 'allianz_8wksfree_campaign.md').write_text('\n'.join(lines) + '\n', encoding='utf8')

    from processing.hbf import build_campaign as build_hbf_campaign
    campaign = build_hbf_campaign(ROOT / 'data/raw', ROOT / 'data/runs')
    lines = ['# HBF OVHC - review before approval', '',
             'Specialist monitoring record for HBF overseas visitor cover. Domestic PHI offers are excluded.', '',
             '| Field | Extracted value |', '| --- | --- |']
    for key in ['organisation', 'cover_type', 'oshc_offered', 'owhc_offered',
                'promotion_detected', 'review_status']:
        lines.append(f"| {key} | {campaign.get(key)} |")
    lines += ['', '## OVHC products', '']
    lines += [f'- {product}' for product in campaign.get('ovhc_products', [])]
    lines += ['', '## Observed pages', '']
    for observation in campaign['observations']:
        page = observation['source_id'] + '.md'
        lines += [f"- [{observation['source_id']}]({page}): {observation['url']} "
                  f"({observation['collected_at']}); promotion detected: "
                  f"{observation['promotion_detected']}"]
    if campaign.get('promotion_evidence'):
        lines += ['', '## Promotion evidence requiring review', '', '```json',
                  json.dumps(campaign['promotion_evidence'], ensure_ascii=False, indent=2),
                  '```']
    lines += ['', '## Validation issues', '', str(campaign['validation_issues']), '',
              campaign['note'], '',
              'Latest collection attempt results and raw evidence paths are in data/processed/hbf_ovhc_review.json.']
    (output / 'hbf_ovhc.md').write_text('\n'.join(lines) + '\n', encoding='utf8')

    from processing.medibank import build_campaign as build_medibank_campaign
    campaign = build_medibank_campaign(ROOT / 'data/raw', ROOT / 'data/runs')
    lines = ['# Medibank WORKER8 - review before approval', '',
             'One provisional OWHC campaign linked from Medibank overseas pages to its detail and terms page. Not automatically approved.', '',
             '| Field | Extracted value |', '| --- | --- |']
    for key in ['promo_code', 'product_name', 'cover_type', 'target_segment',
                'benefit_total_weeks', 'offer_end', 'required_hold_days',
                'minimum_age', 'direct_debit_required',
                'campaign_link_verified_in_saved_pages', 'review_status']:
        lines.append(f"| {key} | {campaign.get(key)} |")
    lines += ['', '## Eligible member types', '']
    lines += [f'- {value}' for value in campaign.get('eligible_member_types', [])]
    lines += ['', '## Eligible products', '']
    lines += [f'- {value}' for value in campaign.get('eligible_products', [])]
    lines += ['', '## Excluded covers', '']
    lines += [f'- {value}' for value in campaign.get('excluded_covers', [])]
    lines += ['', '## Observed pages', '']
    for observation in campaign['observations']:
        page = observation['source_id'] + '.md'
        lines += [f"- [{observation['source_id']}]({page}): {observation['url']} "
                  f"({observation['collected_at']})"]
    lines += ['', '## Full terms evidence', '']
    for heading in campaign.get('terms_evidence', {}).get('headings', []):
        lines += [f'- Heading: {heading}']
    for paragraph in campaign.get('terms_evidence', {}).get('paragraphs', []):
        lines += [paragraph, '']
    lines += ['## Validation issues', '', str(campaign['validation_issues']), '',
              campaign['note'], '',
              'Latest collection attempt results and raw evidence paths are in data/processed/medibank_worker8_review.json.']
    (output / 'medibank_worker8.md').write_text('\n'.join(lines) + '\n', encoding='utf8')


if __name__ == '__main__':
    main()
