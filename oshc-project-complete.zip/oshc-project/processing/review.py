"""Persist and apply human review decisions for promotion candidates.

Review decisions live outside generated processing output so rerunning the
pipeline cannot erase them.  Every decision is bound to the fingerprint of the
evidence reviewed; changed evidence therefore requires another decision.
"""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import re
import uuid


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT_DIR = ROOT / 'data/processed'
DEFAULT_APPROVALS_FILE = ROOT / 'data/approvals/promotion_decisions.json'
DECISIONS = {
    'approved',
    'rejected',
    'needs_correction',
    'needs_more_evidence',
    'expired',
    'no_active_promotion',
}
UNSCOPED = 'unconfirmed_do_not_publish_as_overseas'
COVER_TYPES = {'OSHC', 'OVHC', 'OWHC'}
RESOLVED_DECISIONS = {'approved', 'rejected', 'expired', 'no_active_promotion'}
SPECIALIST_FILES = (
    'medibank_worker8_review.json',
    'bupa_free8_review.json',
    'allianz_8wksfree_review.json',
    'hbf_ovhc_review.json',
)
VOLATILE_KEYS = {
    'approval', 'approval_fingerprint', 'approval_status', 'approval_target_id',
    'collected_at', 'latest_attempt', 'latest_attempts', 'review_status',
    'snapshot_path', 'validation_issues',
}
RESERVED_CORRECTION_FIELDS = {
    'approval', 'approval_fingerprint', 'approval_status', 'approval_target_id',
    'approval_target_type', 'campaign_key', 'evidence', 'fingerprint',
    'latest_review_decision', 'observations', 'record_id', 'review_status',
    'snapshot_id', 'terms_evidence', 'validation_issues',
}


class ReviewError(ValueError):
    """Raised for a malformed or inapplicable review action."""


def _digest(value):
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True,
                         separators=(',', ':')).encode('utf-8')
    return sha256(encoded).hexdigest()[:24]


def _stable_evidence(value):
    """Remove collection metadata while retaining offer and evidence content."""
    if isinstance(value, dict):
        return {key: _stable_evidence(item) for key, item in sorted(value.items())
                if key not in VOLATILE_KEYS}
    if isinstance(value, list):
        return [_stable_evidence(item) for item in value]
    return value


def specialist_fingerprint(record):
    """Fingerprint parsed campaign facts and source evidence, not run metadata."""
    return _digest(_stable_evidence(record))


def prepare_specialist(record):
    prepared = deepcopy(record)
    target_id = prepared.get('campaign_key')
    if not target_id:
        raise ReviewError('specialist campaign is missing campaign_key')
    prepared['approval_target_id'] = target_id
    prepared['approval_target_type'] = 'specialist_campaign'
    prepared['approval_fingerprint'] = specialist_fingerprint(prepared)
    return prepared


def prepare_candidate(record):
    prepared = deepcopy(record)
    if not prepared.get('record_id') or not prepared.get('fingerprint'):
        raise ReviewError('candidate is missing record_id or fingerprint')
    prepared['approval_target_id'] = prepared['record_id']
    prepared['approval_target_type'] = 'candidate'
    prepared['approval_fingerprint'] = prepared['fingerprint']
    return prepared


def load_decisions(path):
    path = Path(path)
    if not path.exists():
        return []
    try:
        decisions = json.loads(path.read_text(encoding='utf-8'))
    except json.JSONDecodeError as exc:
        raise ReviewError(f'invalid approvals JSON: {exc}') from exc
    if not isinstance(decisions, list):
        raise ReviewError('approvals file must contain a JSON array')
    for index, decision in enumerate(decisions):
        if not isinstance(decision, dict):
            raise ReviewError(f'decision {index} must be an object')
        missing = [field for field in ('decision_id', 'target_id', 'fingerprint',
                                       'decision', 'reviewer', 'reviewed_at')
                   if not decision.get(field)]
        if missing:
            raise ReviewError(f'decision {index} missing: {", ".join(missing)}')
        if decision['decision'] not in DECISIONS:
            raise ReviewError(f'decision {index} has unsupported status')
        try:
            stamp = datetime.fromisoformat(decision['reviewed_at'])
        except ValueError as exc:
            raise ReviewError(f'decision {index} has invalid reviewed_at') from exc
        if stamp.tzinfo is None:
            raise ReviewError(f'decision {index} reviewed_at must include timezone')
        if not isinstance(decision.get('field_corrections', {}), dict):
            raise ReviewError(f'decision {index} field_corrections must be an object')
    return decisions


def save_decisions(path, decisions):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f'.{path.name}.{uuid.uuid4().hex}.tmp')
    temporary.write_text(json.dumps(decisions, ensure_ascii=False, indent=2) + '\n',
                         encoding='utf-8')
    temporary.replace(path)


def latest_decisions(decisions):
    latest = {}
    for decision in decisions:
        key = (decision['target_id'], decision['fingerprint'])
        previous = latest.get(key)
        order = (datetime.fromisoformat(decision['reviewed_at']).timestamp(),
                 decision['decision_id'])
        previous_order = ((datetime.fromisoformat(previous['reviewed_at']).timestamp(),
                           previous['decision_id']) if previous else None)
        if previous is None or order > previous_order:
            latest[key] = decision
    return latest


def _set_field(record, path, value):
    parts = path.split('.')
    if not all(re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', part) for part in parts):
        raise ReviewError(f'invalid correction field: {path}')
    if parts[0] in RESERVED_CORRECTION_FIELDS:
        raise ReviewError(f'correction cannot overwrite audit field: {parts[0]}')
    target = record
    for part in parts[:-1]:
        existing = target.get(part)
        if existing is None:
            target[part] = {}
        elif not isinstance(existing, dict):
            raise ReviewError(f'cannot set nested field below non-object: {path}')
        target = target[part]
    target[parts[-1]] = value


def apply_decisions(candidates, specialists, decisions):
    """Return pending queue, approved records, and an approval audit."""
    targets = prepare_targets(candidates, specialists)
    current_by_id = {record['approval_target_id']: record for _, record in targets}
    latest = latest_decisions(decisions)
    pending, validated, applied = [], [], []

    for target_type, record in targets:
        target_id = record['approval_target_id']
        fingerprint = record['approval_fingerprint']
        decision = latest.get((target_id, fingerprint))
        matching_history = [item for item in decisions if item['target_id'] == target_id]
        stale = bool(matching_history and decision is None)

        if decision and decision['decision'] == 'approved':
            approved = deepcopy(record)
            for field, value in decision.get('field_corrections', {}).items():
                _set_field(approved, field, value)
            approved['pre_approval_validation_issues'] = approved.get('validation_issues', [])
            approved['validation_issues'] = []
            approved['review_status'] = 'approved'
            approved['approval'] = deepcopy(decision)
            validated.append(approved)
        elif not decision or decision['decision'] not in RESOLVED_DECISIONS:
            queued = deepcopy(record)
            queued['approval_status'] = (
                'stale_decision_requires_review' if stale else
                decision['decision'] if decision else 'awaiting_review'
            )
            if decision:
                queued['latest_review_decision'] = deepcopy(decision)
            pending.append(queued)

        if decision:
            applied.append({'target_id': target_id, 'target_type': target_type,
                            'fingerprint': fingerprint,
                            'decision_id': decision['decision_id'],
                            'decision': decision['decision']})

    orphaned = [item for item in decisions if item['target_id'] not in current_by_id]
    stale = [item for item in decisions
             if item['target_id'] in current_by_id
             and item['fingerprint'] != current_by_id[item['target_id']]['approval_fingerprint']]
    audit = {'applied': applied, 'stale': stale, 'orphaned': orphaned,
             'decision_count': len(decisions)}
    return pending, validated, audit


def prepare_targets(candidates, specialists):
    return ([('candidate', prepare_candidate(row)) for row in candidates] +
            [('specialist_campaign', prepare_specialist(row)) for row in specialists])


def load_targets(output_dir):
    output_dir = Path(output_dir)
    targets = {}
    complete_path = output_dir / 'approval_targets.json'
    if complete_path.exists():
        for record in json.loads(complete_path.read_text(encoding='utf-8')):
            targets[record['approval_target_id']] = (
                record['approval_target_type'], record
            )
        return targets
    queue_path = output_dir / 'review_queue.json'
    if queue_path.exists():
        for record in json.loads(queue_path.read_text(encoding='utf-8')):
            prepared = prepare_candidate(record)
            targets[prepared['approval_target_id']] = ('candidate', prepared)
    for name in SPECIALIST_FILES:
        path = output_dir / name
        if not path.exists():
            continue
        record = json.loads(path.read_text(encoding='utf-8'))
        prepared = prepare_specialist(record)
        targets[prepared['approval_target_id']] = ('specialist_campaign', prepared)
    return targets


def decision_conflict(record, decision):
    """
    A human-readable reason `decision` cannot apply to `record` as it stands,
    or None if it may proceed. This is the single place these rules live, so
    the interactive wizard can warn before asking for a note the decision
    will not use, and record_decision can enforce the same rule with no risk
    of the two checks drifting apart.
    """
    if decision == 'no_active_promotion' and record.get('promotion_detected') is not False:
        return 'no_active_promotion is only valid for a negative monitoring result'
    if decision == 'approved' and record.get('promotion_detected') is False:
        return ('a negative monitoring result cannot be approved as a promotion; '
                'use no_active_promotion (option 6) instead')
    return None


def record_decision(target_id, decision, reviewer, note='', field_corrections=None,
                    output_dir=DEFAULT_OUTPUT_DIR,
                    approvals_file=DEFAULT_APPROVALS_FILE, reviewed_at=None):
    if decision not in DECISIONS:
        raise ReviewError(f'unsupported decision: {decision}')
    if not reviewer.strip():
        raise ReviewError('reviewer is required')
    targets = load_targets(output_dir)
    if target_id not in targets:
        raise ReviewError(f'unknown review target: {target_id}')
    target_type, record = targets[target_id]
    conflict = decision_conflict(record, decision)
    if conflict:
        raise ReviewError(conflict)
    corrections = field_corrections or {}
    check_record = deepcopy(record)
    for field, value in corrections.items():
        _set_field(check_record, field, value)
    if decision == 'approved' and check_record.get('scope_status') == UNSCOPED:
        if check_record.get('cover_type') not in COVER_TYPES:
            raise ReviewError(
                f"cannot approve a record scoped '{UNSCOPED}' without a "
                "field_corrections cover_type of OSHC, OVHC or OWHC confirming "
                "it belongs to this project's overseas market"
            )
    stamp = reviewed_at or datetime.now(timezone.utc).isoformat()
    item = {
        'decision_id': uuid.uuid4().hex,
        'target_id': target_id,
        'target_type': target_type,
        'fingerprint': record['approval_fingerprint'],
        'decision': decision,
        'reviewer': reviewer.strip(),
        'reviewed_at': stamp,
        'note': note,
        'field_corrections': corrections,
    }
    decisions = load_decisions(approvals_file)
    decisions.append(item)
    save_decisions(approvals_file, decisions)
    return item


def _parse_field(value):
    if '=' not in value:
        raise argparse.ArgumentTypeError('field correction must use FIELD=JSON_VALUE')
    field, raw = value.split('=', 1)
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        parsed = raw
    return field, parsed


def _summary(record):
    return {
        'target_id': record['approval_target_id'],
        'organisation': record.get('organisation') or record.get('campaign_key', '').split(':')[0].title(),
        'promo_code': record.get('promo_code'),
        'cover_type': record.get('cover_type'),
        'review_status': record.get('review_status'),
        'approval_fingerprint': record['approval_fingerprint'],
    }


def _review_urls(record):
    urls = []
    for key in ('canonical_url', 'source_url'):
        if record.get(key):
            urls.append(record[key])
    for observation in record.get('observations', []):
        if observation.get('url'):
            urls.append(observation['url'])
    return list(dict.fromkeys(urls))


def _benefit_summary(record):
    if record.get('benefit_total_weeks') is not None:
        return f"{record['benefit_total_weeks']} weeks free"
    values = []
    for benefit in record.get('benefits', []):
        if benefit.get('type') == 'free_cover':
            qualifier = 'up to ' if benefit.get('qualifier') == 'up_to' else ''
            values.append(f"{qualifier}{benefit.get('value')} weeks free")
        elif benefit.get('value') is not None:
            values.append(f"{benefit['type']}: {benefit['value']} {benefit.get('unit', '')}".strip())
        else:
            values.append(benefit.get('type', 'benefit'))
    return '; '.join(values) or 'No normalized benefit'


def _unscoped_guidance(record, reviewer):
    return (
        "Note: this offer's market (OSHC/OVHC/OWHC) was not confirmed by the "
        "extraction rules, so option 1 is blocked here. Open the URL above, "
        "confirm the cover type against the page, skip this record (s), then run:\n"
        f'  python3 -m processing.review approve {record["approval_target_id"]} '
        f'--reviewer "{reviewer}" --field cover_type=\'"OSHC"\'\n'
        "(replace OSHC with the confirmed cover type). Choose 2-5 here instead "
        "if it is not one of this project's overseas products."
    )


def interactive_review(output_dir=DEFAULT_OUTPUT_DIR,
                       approvals_file=DEFAULT_APPROVALS_FILE,
                       reviewer=None, input_fn=input, output_fn=print):
    """Guide a reviewer through unresolved targets without copying target IDs."""
    targets = load_targets(output_dir)
    decisions = load_decisions(approvals_file)
    latest = latest_decisions(decisions)
    pending = []
    for target_type, record in targets.values():
        current = latest.get((record['approval_target_id'],
                              record['approval_fingerprint']))
        if current and current['decision'] in RESOLVED_DECISIONS:
            continue
        pending.append((target_type, record, current))

    if not pending:
        output_fn('No review targets are awaiting a decision.')
        return 0
    if not reviewer:
        reviewer = input_fn('Reviewer name: ').strip()
    if not reviewer:
        raise ReviewError('reviewer is required')

    saved = 0
    choices = {
        '1': 'approved', '2': 'rejected', '3': 'needs_correction',
        '4': 'needs_more_evidence', '5': 'expired',
        '6': 'no_active_promotion',
    }
    for index, (target_type, record, current) in enumerate(pending, 1):
        output_fn('\n' + '=' * 72)
        output_fn(f'[{index}/{len(pending)}] {record["approval_target_id"]}')
        output_fn(f'Organisation: {_summary(record)["organisation"]}')
        output_fn(f'Promo code: {record.get("promo_code") or "None"}')
        output_fn(f'Cover type: {record.get("cover_type") or "Unconfirmed"}')
        output_fn(f'Benefit: {_benefit_summary(record)}')
        deadline = (record.get('join_by') or record.get('offer_end') or
                    record.get('policy_start_by'))
        output_fn(f'Deadline: {deadline or "Not extracted"}')
        output_fn('Issues: ' + (', '.join(record.get('validation_issues', [])) or 'None'))
        if current:
            output_fn(f'Current decision: {current["decision"]}')
        for url in _review_urls(record):
            output_fn(f'URL: {url}')

        negative_monitor = record.get('promotion_detected') is False
        unscoped = (record.get('scope_status') == UNSCOPED
                   and record.get('cover_type') not in COVER_TYPES)
        approve_hint = (' (not valid here; use 6 instead)' if negative_monitor else
                        ' (blocked here; needs a cover-type correction, see below)' if unscoped else '')
        output_fn(f'  1 Approve{approve_hint}   2 Reject   3 Needs correction')
        output_fn('  4 Needs more evidence   5 Expired')
        if negative_monitor:
            output_fn('  6 Confirm no active promotion (recommended for this record)')
        output_fn('  s Skip      q Save and quit')
        if unscoped:
            output_fn(_unscoped_guidance(record, reviewer))

        while True:
            choice = input_fn('Decision: ').strip().lower()
            if choice == 'q':
                output_fn(f'Finished. Saved {saved} decision(s).')
                return saved
            if choice == 's':
                break
            decision = choices.get(choice)
            if decision is None:
                output_fn('Please enter 1-6, s, or q.')
                continue
            if decision == 'approved' and unscoped:
                output_fn(_unscoped_guidance(record, reviewer))
                continue
            conflict = decision_conflict(record, decision)
            if conflict:
                output_fn(f'Cannot choose this option: {conflict}')
                continue
            note = input_fn('Review note: ').strip()
            try:
                record_decision(record['approval_target_id'], decision, reviewer,
                                note, output_dir=output_dir,
                                approvals_file=approvals_file)
            except ReviewError as exc:
                output_fn(f"Cannot save decision: {exc}\nEnter a different choice, or s to skip.")
                continue
            saved += 1
            output_fn(f'Saved: {decision}')
            break
    output_fn(f'\nFinished. Saved {saved} decision(s).')
    return saved


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw-dir', type=Path, default=ROOT / 'data/raw')
    parser.add_argument('--output-dir', type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument('--approvals-file', type=Path, default=DEFAULT_APPROVALS_FILE)
    subparsers = parser.add_subparsers(dest='command', required=True)
    subparsers.add_parser('list', help='list current review targets')
    interactive = subparsers.add_parser(
        'interactive', help='review unresolved targets with a numbered menu')
    interactive.add_argument('--reviewer', help='reviewer name; prompted if omitted')
    show = subparsers.add_parser('show', help='show one current review target')
    show.add_argument('target_id')
    for command, decision in [
        ('approve', 'approved'), ('reject', 'rejected'),
        ('needs-correction', 'needs_correction'),
        ('needs-more-evidence', 'needs_more_evidence'),
        ('expire', 'expired'), ('confirm-no-active', 'no_active_promotion'),
    ]:
        action = subparsers.add_parser(command)
        action.set_defaults(decision=decision)
        action.add_argument('target_id')
        action.add_argument('--reviewer', required=True)
        action.add_argument('--note', default='')
        action.add_argument('--field', action='append', default=[], type=_parse_field,
                            metavar='FIELD=JSON_VALUE')
    args = parser.parse_args(argv)
    targets = load_targets(args.output_dir)
    if args.command == 'interactive':
        try:
            saved = interactive_review(args.output_dir, args.approvals_file,
                                       args.reviewer)
        except ReviewError as exc:
            parser.error(str(exc))
        if saved:
            from processing.run_processing import process
            process(args.raw_dir, args.output_dir, args.approvals_file)
            print('Processing refreshed. Review data/processed/validated_promotions.json.')
        return 0
    if args.command == 'list':
        decisions = load_decisions(args.approvals_file)
        latest = latest_decisions(decisions)
        rows = []
        for target_type, record in targets.values():
            row = _summary(record)
            row['target_type'] = target_type
            matching = latest.get((record['approval_target_id'], record['approval_fingerprint']))
            row['decision'] = matching['decision'] if matching else None
            rows.append(row)
        print(json.dumps(rows, ensure_ascii=False, indent=2))
        return 0
    if args.command == 'show':
        if args.target_id not in targets:
            parser.error(f'unknown review target: {args.target_id}')
        print(json.dumps(targets[args.target_id][1], ensure_ascii=False, indent=2))
        return 0
    try:
        item = record_decision(
            args.target_id, args.decision, args.reviewer, args.note,
            dict(args.field), args.output_dir, args.approvals_file,
        )
    except ReviewError as exc:
        parser.error(str(exc))
    print(json.dumps(item, ensure_ascii=False, indent=2))
    print('\nDecision saved. Run: python3 -m processing.run_processing')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
