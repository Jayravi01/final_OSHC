"""Evidence-based Bupa FREE8 review. Terms remain unapproved, never inferred from URLs."""
import json
import re
from datetime import datetime
from pathlib import Path

TERMS_URL = 'https://www.bupa.com.au/campaigns/health-insurance/ovcfree8weeks'


def parse_terms(data):
    paragraphs = data['paragraphs']
    text = ' '.join(' '.join(p.split()) for p in paragraphs)
    def match(pattern):
        return re.search(pattern, text, re.I)
    def iso(value):
        return datetime.strptime(value, '%d/%m/%Y').date().isoformat()
    dates = match(r'between (\d{2}/\d{2}/\d{4}) and (\d{1,2}:\d{2}[ap]m) (AEDT|AEST) on (\d{2}/\d{2}/\d{4}) and commence your policy by (\d{2}/\d{2}/\d{4})')
    total = match(r'(\d+) weeks free\s*,? with the value')
    stages = []
    first = match(r'Unless you pay yearly.*?your (\d+) weeks free will be applied (\d+) days after you join')
    second = match(r'remaining (\d+) weeks are applied once you.ve held eligible cover for (\d+) months')
    yearly = match(r'If you join through a Bupa consultant and pay yearly.*?first payment will be reduced by the\s+value of (\d+) weeks.*?third yearly payment will be reduced by the value of (\d+) weeks')
    if first:
        stages.append({'payment_schedule':'non_annual', 'weeks':int(first[1]),
                       'after_days':int(first[2]), 'qualifier':'in most cases', 'evidence_text':first[0]})
    if second:
        stages.append({'payment_schedule':'non_annual', 'weeks':int(second[1]),
                       'after_months':int(second[2]), 'application':'following billing cycle', 'evidence_text':second[0]})
    if yearly:
        stages.append({'payment_schedule':'annual_via_consultant', 'first_payment_free_weeks':int(yearly[1]),
                       'third_payment_free_weeks':int(yearly[2]), 'evidence_text':yearly[0]})
    eligible, exclusions = [], []
    mode = None
    for p in paragraphs:
        if p.startswith('An Eligible Health Insurance Policy'):
            mode = 'eligible'
        elif p.startswith('This offer excludes'):
            mode = 'excluded'
        elif p.startswith('4. General'):
            mode = None
        elif mode == 'eligible':
            eligible.append(p)
        elif mode == 'excluded':
            exclusions.append(p)
    working = bool(match(r'An Eligible Health Insurance Policy is a working Overseas Visitors Cover Hospital \+ Extra'))
    issues = ['human_review_required']
    if not dates: issues.append('date_pattern_missing_or_changed')
    if not (total and first and second and yearly): issues.append('benefit_schedule_incomplete')
    if not working: issues.append('eligible_product_not_confirmed')
    if not eligible or not exclusions: issues.append('product_lists_incomplete')
    return {
        'product_name':'Working Overseas Visitors Cover Hospital + Extras' if working else None,
        'target_segment':'Workers' if working else None,
        'cover_type':'OWHC' if working else None,
        'benefit_total_weeks':int(total[1]) if total else None,
        'benefit_stages':stages,
        'join_from':iso(dates[1]) if dates else None,
        'join_by':iso(dates[4]) if dates else None,
        'join_deadline_local_time':dates[2] if dates else None,
        'join_deadline_timezone':dates[3] if dates else None,
        'policy_start_by':iso(dates[5]) if dates else None,
        'eligible_products_evidence':eligible,
        'excluded_products_evidence':exclusions,
        'customer_eligibility_evidence':[p for p in paragraphs if any(x in p.lower() for x in
            ['last 60 days', 'transferring from', 'over the age', 'direct debit', 'valid email', 'promo code', 'price comparator', 'corporate'])],
        'validation_issues':issues,
    }


def build_campaign(raw_dir, run_dir):
    latest = {}
    for path in Path(raw_dir).rglob('*.json'):
        try:
            d = json.loads(path.read_text())
            if d.get('organisation') != 'Bupa' or d.get('http_status') != 200: continue
            if d['source_id'] not in latest or d['collected_at'] > latest[d['source_id']][1]['collected_at']:
                latest[d['source_id']] = (path, d)
        except (ValueError, KeyError, OSError):
            continue
    attempts = {}
    for path in Path(run_dir).glob('bupa_*.json'):
        d = json.loads(path.read_text())
        if d['source_id'] not in attempts or d['started_at'] > attempts[d['source_id']]['started_at']:
            attempts[d['source_id']] = d
    observations = []
    for source, (path, d) in latest.items():
        if source == 'bupa_free8_terms': continue
        evidence = [c for c in d.get('component_evidence', [])
                    if re.search(r'FREE8|weeks free', c['text'], re.I)]
        if not any('FREE8' in c['text'] for c in evidence): continue
        observations.append({'source_id':source, 'url':d['final_url'], 'collected_at':d['collected_at'],
                             'snapshot_path':str(path.resolve()), 'evidence':evidence,
                             'terms_link_captured':TERMS_URL in d['links'],
                             'latest_attempt':attempts.get(source)})
    terms = latest.get('bupa_free8_terms')
    linked = bool(terms and terms[1]['final_url'].rstrip('/') == TERMS_URL
                  and any(re.search(r'promo code\s+FREE8\b', p, re.I) for p in terms[1]['paragraphs'])
                  and any(o['terms_link_captured'] for o in observations))
    record = {'campaign_key':'bupa:FREE8', 'promo_code':'FREE8', 'review_status':'needs_review',
              'observations':observations, 'terms_link_verified_in_saved_pages':linked,
              'latest_attempts':attempts,
              'note':'One provisional campaign review, multiple page observations. Total weeks are not additive to stages. Latest snapshots may have different collection times; not a historical as-of join.'}
    if linked:
        path, data = terms
        record.update(parse_terms(data))
        record['terms_evidence'] = {'source_url':data['final_url'], 'collected_at':data['collected_at'],
                                  'snapshot_path':str(path.resolve()), 'paragraphs':data['paragraphs']}
    else:
        record['validation_issues'] = ['missing_verified_terms_link_or_snapshot', 'human_review_required']
    return record
