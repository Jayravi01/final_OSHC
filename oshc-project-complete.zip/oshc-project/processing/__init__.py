"""Evidence-preserving, offline promotion processing prototype."""
