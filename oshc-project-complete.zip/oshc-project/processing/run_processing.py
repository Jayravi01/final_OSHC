"""Process saved scraper JSON; never publish unreviewed claims as validated offers."""
import argparse
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
import re
import unicodedata

ROOT = Path(__file__).resolve().parents[1]
RULE_VERSION = '0.6.0'
BUPA_SPECIALIST_SOURCES = {'bupa_visitors', 'bupa_working_visitors', 'bupa_working', 'bupa_free8_terms'}
ALLIANZ_SPECIALIST_SOURCES = {'allianz_ovhc', 'allianz_8wksfree'}
HBF_SPECIALIST_SOURCES = {'hbf_ovhc_workers', 'hbf_ovhc_visitors', 'hbf_ovhc_hub'}
MEDIBANK_SPECIALIST_SOURCES = {'medibank_worker8_campaign'}
MEDIBANK_WORKER8_SUPPORTING_SOURCES = {'medibank_working_visas',
                                      'medibank_overseas', 'medibank_oshc'}
MEDIBANK_CAMPAIGN_SOURCES = (MEDIBANK_SPECIALIST_SOURCES |
                             MEDIBANK_WORKER8_SUPPORTING_SOURCES)


def digest(value):
    return sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:24]


def clean(text):
    # Repair only reversible UTF-8 mojibake; retain original evidence separately.
    text = re.sub(r'[\u0080-\u00ff]+', repair_fragment, text)
    # Historical scraper output sometimes contains a stranded Latin-1 marker.
    text = re.sub(r'\u00c2(?=\s|$)', ' ', text)
    return ' '.join(unicodedata.normalize('NFKC', text).split())


def repair_fragment(match):
    value = match.group()
    try:
        return value.encode('latin1').decode('utf8')
    except UnicodeError:
        return value


def navigation(text):
    signals = ['quick links', 'find health cover', 'compare health cover',
               'get a quote', 'make a claim', 'help and support', 'compare travel cover']
    return sum(s in text.lower() for s in signals) >= 3


def unrelated_product(text):
    return (not re.search(r'\b(?:OSHC|OVHC|OWHC)\b|overseas .*?health cover', text, re.I)
            and bool(re.search(r'\b(?:travel|pet|life|income protection) insurance\b', text, re.I)))


def benefits(text):
    """Extract benefits without counting points and redemption value twice."""
    result = []
    for m in re.finditer(r'(?P<up>up to\s+)?(?P<n>\d+)\s+(?:more\s+)?weeks?\s+free\b', text, re.I):
        benefit = {'type': 'free_cover', 'value': int(m['n']), 'unit': 'weeks',
                   'qualifier': 'up_to' if m['up'] else 'exact', 'evidence_text': m.group()}
        timing = re.match(r'\s+in your (second month|second year)', text[m.end():], re.I)
        if timing:
            benefit['timing_text'] = timing.group().strip()
            benefit['evidence_text'] += timing.group()
        result.append(benefit)
    points_pattern = (r'([\d,]+)\s+Live Better points\s*\(\$([\d,]+) in gift cards\)'
                      r'\s+for\s+(singles/single parents|couples/families)')
    point_spans = []
    for m in re.finditer(points_pattern, text, re.I):
        point_spans.append(m.span())
        result.append({'type': 'reward_points', 'value': int(m[1].replace(',', '')),
                       'unit': 'points', 'programme': 'Live Better',
                       'redemption_value': {'value': int(m[2].replace(',', '')), 'unit': 'AUD'},
                       'audience': m[3].lower().split('/'), 'evidence_text': m.group()})
    for kind, unit, pattern in [
        ('gift_card', 'AUD', r'\$\s*(\d+(?:\.\d{1,2})?)\s+(?:in\s+)?gift\s+cards?\b'),
        ('cashback', 'AUD', r'\$\s*(\d+(?:\.\d{1,2})?)\s+cash\s*back\b'),
        ('percentage_discount', 'percent', r'\b(\d+(?:\.\d+)?)\s*%\s*(?:off|discount)\b'),
        ('dollar_discount', 'AUD', r'\$\s*(\d+(?:\.\d{1,2})?)\s*(?:off|discount)\b'),
    ]:
        for m in re.finditer(pattern, text, re.I):
            if any(start <= m.start() < end for start, end in point_spans):
                continue
            # A card headline may summarize the redemption value detailed below.
            if (kind == 'gift_card' and re.search(r'up to\s*$', text[max(0, m.start()-12):m.start()], re.I)
                    and any(b['type'] == 'reward_points' and b['redemption_value']['value'] == float(m[1]) for b in result)):
                continue
            result.append({'type': kind, 'value': float(m[1]), 'unit': unit, 'evidence_text': m.group()})
    # Publishers describe the same benefit as waiving or skipping a wait, in the
    # singular or plural, sometimes naming the service between the two.
    waiver = re.search(r'(?:(?:waive|skip)\s+(?:the\s+|any\s+)?)?'
                       r'(\d+)\s*(?:&|and)\s*(\d+)\s+month\s+(?:\w+\s+)?(?:waiting periods?|waits?)'
                       r'(?:\s+waived)?', text, re.I)
    if waiver and re.search(r'waiv|skip', waiver.group(), re.I):
        result.append({'type': 'waiting_period_waiver', 'periods': [int(waiver[1]), int(waiver[2])],
                       'unit': 'months', 'applies_to': 'eligible_extras' if re.search(r'extras', text, re.I) else None,
                       'evidence_text': waiver.group()})
    # Headline and body may repeat an incentive in the same card.
    unique = {}
    for item in result:
        key = digest({k: v for k, v in item.items() if k != 'evidence_text'})
        unique.setdefault(key, item)
    return list(unique.values())


def incentives(text):
    return benefits(text)


def codes(text):
    return re.findall(r"(?i:promo(?:tion)? code)\s*[:'\"\u2018\u2019]*\s*(?:(?i:copied!)\s*)?([A-Z0-9][A-Z0-9_-]{2,})", text)


def segment(text):
    matches = []
    for label, pattern in [('OWHC', r'\bOWHC\b|overseas workers? health cover'),
                           ('OSHC', r'\bOSHC\b|overseas students? health cover'),
                           ('OVHC', r'\bOVHC\b|overseas visitors? health cover')]:
        if re.search(pattern, text, re.I):
            matches.append(label)
    return matches[0] if len(matches) == 1 else None


def deadline(text):
    dates = []
    for match in re.finditer(r'(?:offer ends|join by|offer available until)\s+(\d{1,2}\s+[A-Za-z]+\s+\d{4})', text, re.I):
        for fmt in ['%d %B %Y', '%d %b %Y']:
            try:
                dates.append(datetime.strptime(match.group(1), fmt).date().isoformat())
                break
            except ValueError:
                pass
    return dates[0] if len(set(dates)) == 1 else None


def extract(data, snapshot):
    # FREE8 combines separate banner and terms snapshots; the dedicated campaign
    # review prevents total/stages/terms pages becoming separate generic offers.
    if data.get('source_id') in (BUPA_SPECIALIST_SOURCES | ALLIANZ_SPECIALIST_SOURCES |
                                 HBF_SPECIALIST_SOURCES | MEDIBANK_SPECIALIST_SOURCES):
        return []
    paragraphs = data['paragraphs']
    cleaned = [clean(p) for p in paragraphs]
    units = []
    blocks = data.get('promotion_blocks', [])
    covered = set()
    for block in blocks:
        text = clean(block['text'])
        if navigation(text) or unrelated_product(text) or not benefits(text):
            continue
        units.append((text, [{'block_id': block['block_id'], 'raw_text': block['text'],
                               'clean_text': text}], block.get('links', []), None))
        covered.update(i for i, p in enumerate(cleaned) if p and p in text)
    # The publisher labels these records as offers and states their own dates, so
    # they are retained even when no benefit wording is recognised; dropping them
    # would hide a live campaign whose wording the rules do not yet cover.
    for offer in data.get('structured_offers', []):
        text = clean(offer.get('text') or '')
        if not text or navigation(text) or unrelated_product(text):
            continue
        units.append((text, [{'offer_id': offer['offer_id'], 'raw_text': offer.get('text', ''),
                              'clean_text': text}], [], offer))
    for i, text in enumerate(cleaned):
        if i in covered or navigation(text) or unrelated_product(text) or not benefits(text):
            continue
        if re.search(r'\b(excludes|terms:|not available|must take out)\b', text, re.I):
            continue
        indices = {i}
        if i + 1 < len(cleaned) and re.match(r'^(?:(?:use|copy) )?promo code', cleaned[i + 1], re.I):
            indices.add(i + 1)
        context = ' '.join(cleaned[j] for j in sorted(indices))
        evidence = [{'paragraph_index': j, 'raw_text': paragraphs[j], 'clean_text': cleaned[j]}
                    for j in sorted(indices)]
        units.append((context, evidence, [], None))
    result, seen = [], set()
    for text, evidence, links, offer in units:
        unique_codes = sorted(set(codes(text)))
        code = unique_codes[0] if len(unique_codes) == 1 else None
        if code:
            for j, p in enumerate(cleaned):
                if code in codes(p) and not any(e.get('paragraph_index') == j or p in e['clean_text'] for e in evidence):
                    evidence.append({'paragraph_index': j, 'raw_text': paragraphs[j], 'clean_text': p})
        # Terms are evidence, never a source of product keywords for classification:
        # 'excludes OSHC' and 'transferring from OSHC' must not change the offer segment.
        terms_evidence = [e for e in evidence
                          if code and code in codes(e['clean_text'])
                          and re.search(r'excludes|must |terms|not available', e['clean_text'], re.I)]
        terms_text = ' '.join(e['clean_text'] for e in terms_evidence)
        hold = re.search(r'(\d+) consecutive days', terms_text, re.I)
        conditions = {
            'required_cover_days': int(hold[1]) if hold else None,
            'direct_debit_required': True if re.search(r'(?:must (?:sign up to|maintain|set up) direct debit|must quote promo code[^.]*and set up direct debit)', terms_text, re.I) else None,
            'excluded_cover_types': [],
            'redemption_channels': [],
        }
        for clause in re.findall(r'Excludes[^.]*', terms_text, re.I):
            for label, pattern in [('OSHC', r'OSHC|Overseas Students? Health Cover'),
                                   ('OVHC', r'OVHC|Overseas Visitors Health Cover'),
                                   ('OWHC', r'OWHC|Overseas Workers Health Cover')]:
                if re.search(pattern, clause, re.I) and label not in conditions['excluded_cover_types']:
                    conditions['excluded_cover_types'].append(label)
        channels = re.search(r'Offer available via ([^.]+)', terms_text, re.I)
        if channels:
            conditions['redemption_channels'] = [c.strip() for c in re.split(r',| and ', channels[1])]
        offer_deadline = deadline(text)
        terms_deadline = deadline(terms_text)
        cover = segment(text)
        product = ('Hospital and Extras cover' if re.search(r'hospital and extras', text, re.I)
                   else 'Extras cover' if re.search(r'eligible (?:Medibank )?extras cover|on extras cover', text, re.I)
                   else cover)
        audience_types = []
        audience_match = re.search(r'For existing members on (.*?) who', terms_text, re.I)
        if audience_match:
            for label, pattern in [('OSHC', r'OSHC'), ('OWHC', r'Overseas Workers Health Cover'), ('OVHC', r'OVHC')]:
                if re.search(pattern, audience_match[1], re.I):
                    audience_types.append(label)
        relationship = 'extras_cross_sell_to_overseas_members' if product == 'Extras cover' and audience_types else None
        # Product-based fallback is tentative and limited to one source; manual review remains required.
        # A published offer name is a more stable identity than its wording.
        anchor = (offer.get('offer_name') if offer else None) or code or product or re.sub(r'\d+', '#', text.lower())
        key = digest([data['source_id'], cover, anchor])
        if key in seen:
            continue
        seen.add(key)
        extracted = benefits(text)
        issues = ['human_review_required', 'eligibility_and_terms_require_review']
        if not cover:
            issues.append('cover_type_missing_or_ambiguous')
        if len(unique_codes) > 1:
            issues.append('multiple_promo_codes')
        published_end = offer.get('ends_at') if offer else None
        if not (published_end or offer_deadline or terms_deadline):
            issues.append('join_by_not_extracted')
        if any(b.get('value', 1) <= 0 or (b['unit'] == 'percent' and b['value'] > 100) for b in extracted):
            issues.append('invalid_offer_value')
        if offer_deadline and terms_deadline and offer_deadline != terms_deadline:
            issues.append('conflicting_offer_and_terms_deadlines')
        if offer and not extracted:
            issues.append('benefit_wording_not_recognised')
        details = [l for l in links if re.search(r'find out more|terms|conditions', l['text'], re.I)]
        # Dates stated in the publisher's own offer record are preferred over a
        # date matched in prose; a linked terms document is still not fetched here.
        fields = {'organisation': data['organisation'], 'cover_type': cover, 'product_name': product,
                  'scope_status': 'overseas_candidate' if cover else 'unconfirmed_do_not_publish_as_overseas',
                  'benefits': extracted, 'promo_code': code,
                  'join_by': published_end or offer_deadline or terms_deadline,
                  'starts_at': offer.get('starts_at') if offer else None, 'conditions': conditions,
                  'eligible_existing_member_cover_types': audience_types,
                  'offer_relationship': relationship,
                  'offer_name': offer.get('offer_name') if offer else None,
                  'published_visa_targeting': offer.get('visas') if offer else None}
        result.append(dict(fields, record_id=key, snapshot_id=snapshot,
                           source_id=data['source_id'], source_url=data['final_url'],
                           collected_at=data['collected_at'], evidence=evidence,
                           detail_links=details,
                           terms_url=(offer.get('terms_url') if offer else None)
                                     or (data['final_url'] if terms_evidence else None),
                           terms_evidence=terms_evidence,
                           discovery_channel=data.get('source_metadata', {}).get('discovery_channel'),
                           review_status='needs_review',
                           validation_issues=issues, extraction_method='rules',
                           rule_version=RULE_VERSION,
                           fingerprint=digest([fields, [e['clean_text'] for e in evidence]])))
    # Broad Medibank product and hub pages may contain unrelated offers such as
    # EXTRAS8COVER. Keep those candidates, while leaving WORKER8 to the linked
    # specialist record so the same campaign is not emitted once per page.
    if data.get('source_id') in MEDIBANK_WORKER8_SUPPORTING_SOURCES:
        result = [row for row in result if row.get('promo_code') != 'WORKER8']
    return result


def process(raw_dir, output_dir, approvals_file=None):
    from scraper.sources import SOURCES
    records, audits, errors = [], [], []
    for path in sorted(raw_dir.rglob('*.json')):
        try:
            data = json.loads(path.read_text(encoding='utf8'))
            for field in ['source_id', 'organisation', 'final_url', 'collected_at']:
                if not data.get(field):
                    raise ValueError('missing/empty ' + field)
            if not isinstance(data.get('paragraphs'), list) or not all(isinstance(p, str) for p in data['paragraphs']):
                raise ValueError('paragraphs must be a list of strings')
            stamp = datetime.fromisoformat(data['collected_at'])
            if stamp.tzinfo is None:
                raise ValueError('collected_at must include timezone')
            if not data['final_url'].startswith(('http://', 'https://')):
                raise ValueError('invalid source URL')
            if data.get('http_status') != 200:
                raise ValueError('snapshot HTTP status is not 200')
            snapshot = digest([data['source_id'], data['collected_at'], data['paragraphs'],
                               data.get('promotion_blocks', []), data.get('structured_offers', [])])
            found = extract(data, snapshot)
            records.extend(found)
            specialist_review = (
                'bupa_free8_review.json' if data['source_id'] in BUPA_SPECIALIST_SOURCES else
                'allianz_8wksfree_review.json' if data['source_id'] in ALLIANZ_SPECIALIST_SOURCES else
                'hbf_ovhc_review.json' if data['source_id'] in HBF_SPECIALIST_SOURCES else
                'medibank_worker8_review.json' if data['source_id'] in MEDIBANK_CAMPAIGN_SOURCES else
                None
            )
            audits.append({'source_id': data['source_id'], 'snapshot_id': snapshot,
                           'raw_file': str(path.resolve()), 'collected_at': data['collected_at'],
                           'candidate_count': len(found),
                           'specialist_review': specialist_review,
                           'status': (('specialist_campaign_review_and_candidates_need_review'
                                      if specialist_review and found else
                                      'specialist_campaign_review' if specialist_review else
                                      'candidates_need_review' if found else
                                      'no_candidate_detected_by_rules')
                                      if data['paragraphs'] else 'empty_extraction_needs_review'),
                           'excluded_other_product_paragraphs': [
                               {'paragraph_index': i, 'raw_text': p, 'reason': 'other_insurance_product'}
                               for i, p in enumerate(data['paragraphs'])
                               if incentives(clean(p)) and unrelated_product(clean(p)) and not navigation(clean(p))],
                           'navigation_paragraphs': sum(navigation(clean(p)) for p in data['paragraphs']),
                           'cleaned_paragraphs': sum(clean(p) != p for p in data['paragraphs'])})
        except (ValueError, KeyError, TypeError, AttributeError, OSError) as exc:
            errors.append({'raw_file': str(path), 'error': str(exc)})

    # Rebuild deterministically from raw history: repeated runs do not append duplicates.
    unique = {(r['record_id'], r['snapshot_id'], r['fingerprint']): r for r in records}
    history, events, latest = [], [], {}
    for record in sorted(unique.values(), key=lambda r: (datetime.fromisoformat(r['collected_at']), r['snapshot_id'], r['fingerprint'])):
        previous = latest.get(record['record_id'])
        changed = previous and previous['fingerprint'] != record['fingerprint']
        record['version'] = (previous['version'] + int(bool(changed))) if previous else 1
        history.append(record)
        if previous is None or changed:
            events.append({'event_id': digest([record['record_id'], record['snapshot_id'], record['fingerprint']]),
                           'record_id': record['record_id'],
                           'event_type': 'candidate_changed' if previous else 'first_observed_candidate',
                           'previous_snapshot_id': previous['snapshot_id'] if previous else None,
                           'snapshot_id': record['snapshot_id'], 'observed_at': record['collected_at'],
                           'review_status': 'needs_review'})
        latest[record['record_id']] = record
    observed = {a['source_id'] for a in audits}
    missing = [s['source_id'] for s in SOURCES if s['source_id'] not in observed]
    newest_snapshot = {}
    for audit in sorted(audits, key=lambda a: (datetime.fromisoformat(a['collected_at']), a['snapshot_id'])):
        newest_snapshot[audit['source_id']] = audit['snapshot_id']
    queue = [r for r in latest.values() if r['snapshot_id'] == newest_snapshot[r['source_id']]]
    # Suggest cross-page matches without discarding evidence or asserting campaign identity.
    groups = {}
    for record in queue:
        if record['promo_code'] and record['cover_type']:
            signature = digest([record['organisation'], record['cover_type'], record['promo_code']])
            groups.setdefault(signature, []).append(record)
    duplicate_review = [
        {'group_id': key, 'promo_code': rows[0]['promo_code'],
         'record_ids': [r['record_id'] for r in rows],
         'source_urls': [r['source_url'] for r in rows],
         'review_status': 'compare_benefits_dates_and_terms_before_merging'}
        for key, rows in groups.items() if len({r['source_id'] for r in rows}) > 1]
    output_dir.mkdir(parents=True, exist_ok=True)
    from processing.bupa import build_campaign
    bupa_review = build_campaign(raw_dir, raw_dir.parent / 'runs')
    from processing.allianz import build_campaign as build_allianz_campaign
    allianz_review = build_allianz_campaign(raw_dir, raw_dir.parent / 'runs')
    from processing.hbf import build_campaign as build_hbf_campaign
    hbf_review = build_hbf_campaign(raw_dir, raw_dir.parent / 'runs')
    from processing.medibank import build_campaign as build_medibank_campaign
    medibank_review = build_medibank_campaign(raw_dir, raw_dir.parent / 'runs')
    from processing.review import (apply_decisions, load_decisions,
                                   prepare_specialist, prepare_targets)
    if approvals_file is None:
        approvals_file = output_dir.parent / 'approvals/promotion_decisions.json'
    decisions = load_decisions(approvals_file)
    specialists = [bupa_review, allianz_review, hbf_review, medibank_review]
    approval_queue, validated, approval_audit = apply_decisions(queue, specialists, decisions)
    approval_targets = [record for _, record in prepare_targets(queue, specialists)]
    generic_review_queue = [row for row in approval_queue
                            if row['approval_target_type'] == 'candidate']
    # Include current approval identity in the specialist outputs so reviewers
    # can bind a decision to exactly the evidence they inspected.
    bupa_review, allianz_review, hbf_review, medibank_review = [
        prepare_specialist(row) for row in specialists
    ]
    outputs = {'bupa_free8_review.json': bupa_review,
               'allianz_8wksfree_review.json': allianz_review,
               'hbf_ovhc_review.json': hbf_review,
               'medibank_worker8_review.json': medibank_review,
               'duplicate_review.json': duplicate_review, 'promotion_candidates.json': history,
               'review_queue.json': generic_review_queue,
               'approval_targets.json': approval_targets,
               'approval_queue.json': approval_queue,
               'approval_audit.json': approval_audit,
               'validated_promotions.json': validated, 'candidate_events.json': events,
               'source_audit.json': {'snapshots': audits, 'missing_sources': missing, 'errors': errors}}
    for name, payload in outputs.items():
        (output_dir / name).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
    summary = (f'# Processing run\n\nRule version: {RULE_VERSION}\n\n'
               f'- Valid input snapshots: {len(audits)}\n- Invalid inputs: {len(errors)}\n'
               f'- Candidate observations: {len(history)}\n'
               f'- Generic candidates awaiting review: {len(generic_review_queue)}\n'
               f'- All approval targets awaiting review: {len(approval_queue)}\n'
               f'- Bupa FREE8 page observations (separate specialist review): {len(bupa_review["observations"])}\n'
               f'- Allianz 8WKSFREE page observations (separate specialist review): {len(allianz_review["observations"])}\n'
               f'- HBF OVHC page observations (separate specialist review): {len(hbf_review["observations"])}\n'
               f'- Medibank WORKER8 page observations (separate specialist review): {len(medibank_review["observations"])}\n'
               f'- Stored human review decisions: {len(decisions)}\n'
               f'- Validated promotions: {len(validated)}\n'
               f'- Sources without a valid saved snapshot: {", ".join(missing) or "none"}\n\n'
               'No candidate detected does not mean no promotion exists. Missing snapshots do not establish '
               'a collection failure reason. Records are latest observed candidates, not confirmed active offers. '
               'Absence never creates an ended-offer event. All changes require human review.\n')
    (output_dir / 'RUN_REPORT.md').write_text(summary, encoding='utf8')
    print(summary)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw-dir', type=Path, default=ROOT / 'data/raw')
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'data/processed')
    parser.add_argument('--approvals-file', type=Path,
                        default=ROOT / 'data/approvals/promotion_decisions.json')
    args = parser.parse_args()
    if not args.raw_dir.is_dir():
        parser.error('raw directory does not exist')
    process(args.raw_dir, args.output_dir, args.approvals_file)
