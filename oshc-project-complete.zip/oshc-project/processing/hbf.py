"""Evidence-based HBF OVHC review assembled from saved snapshots.

HBF offers Overseas Visitors Health Cover (OVHC) only.
HBF does NOT offer OSHC or OWHC.
Student visas (500, 580, 590) are explicitly excluded.

HBF OVHC products:
  - Working Visa Hospital cover (visa condition 8501 compliant)
  - Working Visa Hospital and Medical cover
  - Standard Overseas Visitors cover (visitors, not 8501 compliant)

As of September 2026, no dedicated HBF OVHC new-member promotion
(weeks free or gift card) has been confirmed on their OVHC pages.
The domestic PHI promotions (12 weeks free, gift card) published on
hbf.com.au/terms-and-conditions/new-member-promotion explicitly
exclude OVHC members and are out of scope for this project.

This module monitors the HBF OVHC pages for any new promotion and
returns a no-active-promotion record if none is found, rather than
incorrectly surfacing a domestic PHI offer.
"""
import json
import re
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

WORKERS_URL = 'https://www.hbf.com.au/health-insurance/overseas/working-in-australia'
VISITORS_URL = 'https://www.hbf.com.au/health-insurance/overseas/visiting-australia'
OVHC_HUB_URL = 'https://www.hbf.com.au/health-insurance/overseas/what-is-ovhc'
WORKERS_SOURCE = 'hbf_ovhc_workers'
VISITORS_SOURCE = 'hbf_ovhc_visitors'
HUB_SOURCE = 'hbf_ovhc_hub'
SPECIALIST_SOURCES = {WORKERS_SOURCE, VISITORS_SOURCE, HUB_SOURCE}

# Explicitly out-of-scope: domestic PHI new member promotion page.
DOMESTIC_TERMS_URL = 'https://www.hbf.com.au/terms-and-conditions/new-member-promotion'

# Known OVHC products — used to confirm page is an OVHC source.
OVHC_PRODUCTS = [
    'Working Visa Hospital',
    'Working Visa Hospital and Medical',
    'Standard Overseas Visitors',
]

# Promotion signal patterns to detect any future OVHC offer.
PROMOTION_PATTERNS = [
    r'\d+\s+weeks?\s+free',
    r'\$\d+\s+(?:gift\s+card|cashback|visa\s+e-?gift)',
    r'promo(?:tion)?\s+code',
    r'free\s+cover',
    r'discount',
]

OVHC_CONTEXT_PATTERN = (
    r'\bOVHC\b|overseas visitors? health cover|overseas workers? health cover|'
    r'working visa|visitor visa'
)
OVHC_EXCLUSION_PATTERN = (
    r'(?:offer|promotion).{0,80}(?:does not apply|not available|excludes?)'
    r'.{0,80}(?:\bOVHC\b|overseas visitors? health cover)|'
    r'(?:\bOVHC\b|overseas visitors? health cover).{0,80}'
    r'(?:excluded|not eligible|does not apply|not available)'
)
DOMESTIC_PHI_PATTERN = (
    r'(?:hospital\s*(?:and|&)\s*extras|hospital only|extras only|'
    r'Australian resident|domestic (?:health|PHI))'
)
GENERIC_MEMBER_BENEFIT_PATTERN = (
    r'HBF Member Perks|member benefits|gym memberships|shopping, entertainment'
)


def canonical_url(value):
    """Remove tracking/query data while retaining a stable page identity."""
    parts = urlsplit(value)
    path = parts.path.rstrip('/') or '/'
    return urlunsplit((parts.scheme.lower(), parts.netloc.lower(), path, '', ''))


def _promotion_evidence(paragraphs, headings):
    """Return promotion text that can plausibly apply to HBF OVHC.

    HBF can place domestic PHI campaign copy on an overseas page.  A promotion
    signal is therefore insufficient when the page also says that the offer
    excludes OVHC.  Explicit OVHC/visa wording on the promotion itself takes
    precedence because it is direct evidence for the monitored market.
    """
    units = [value for value in headings + paragraphs if isinstance(value, str)]
    page_text = ' '.join(units)
    ovhc_excluded = bool(re.search(OVHC_EXCLUSION_PATTERN, page_text, re.I))
    evidence = []

    for value in units:
        if not any(re.search(pattern, value, re.I) for pattern in PROMOTION_PATTERNS):
            continue
        has_ovhc_context = bool(re.search(OVHC_CONTEXT_PATTERN, value, re.I))
        is_domestic = bool(re.search(DOMESTIC_PHI_PATTERN, value, re.I))
        is_exclusion = bool(re.search(OVHC_EXCLUSION_PATTERN, value, re.I))
        is_generic_member_benefit = bool(re.search(GENERIC_MEMBER_BENEFIT_PATTERN,
                                                   value, re.I))
        only_weak_discount = (bool(re.search(r'\bdiscounts?\b', value, re.I)) and
                              not any(re.search(pattern, value, re.I)
                                      for pattern in PROMOTION_PATTERNS[:-1]))
        if is_exclusion or (is_domestic and not has_ovhc_context):
            continue
        if (is_generic_member_benefit or only_weak_discount) and not has_ovhc_context:
            continue
        if ovhc_excluded and not has_ovhc_context:
            continue
        evidence.append(value)

    return evidence


def _detect_promotion(paragraphs, headings):
    """Return True if any OVHC-specific promotion text is found on the page."""
    return bool(_promotion_evidence(paragraphs, headings))


def _latest_snapshots(raw_dir):
    """Return the most recent snapshot per source_id for HBF sources."""
    latest = {}
    for path in Path(raw_dir).rglob('*.json'):
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
            if data.get('organisation') != 'HBF' or data.get('http_status') != 200:
                continue
            source = data['source_id']
            if source not in latest or data['collected_at'] > latest[source][1]['collected_at']:
                latest[source] = (path, data)
        except (ValueError, KeyError, OSError):
            continue
    return latest


def _latest_attempts(run_dir):
    """Return the most recent run attempt per source_id for HBF sources."""
    attempts = {}
    for path in Path(run_dir).glob('hbf_*.json'):
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
            source = data['source_id']
            if source not in attempts or data['started_at'] > attempts[source]['started_at']:
                attempts[source] = data
        except (ValueError, KeyError, OSError):
            continue
    return attempts


def build_campaign(raw_dir, run_dir):
    """Build HBF OVHC campaign record from saved snapshots.

    Returns a no-active-promotion record if no OVHC-specific offer is
    found, rather than surfacing an out-of-scope domestic PHI offer.
    If a future OVHC promotion is detected, flags it for human review.
    """
    latest = _latest_snapshots(raw_dir)
    attempts = _latest_attempts(run_dir)
    observations = []
    promotion_detected = False
    promotion_evidence = []

    for source_id, source_role, url in [
        (WORKERS_SOURCE, 'primary_product_workers', WORKERS_URL),
        (VISITORS_SOURCE, 'primary_product_visitors', VISITORS_URL),
        (HUB_SOURCE, 'ovhc_hub', OVHC_HUB_URL),
    ]:
        snap = latest.get(source_id)
        if not snap:
            continue
        path, data = snap
        paragraphs = data.get('paragraphs', [])
        headings = data.get('headings', [])
        matched_evidence = _promotion_evidence(paragraphs, headings)
        has_promo = bool(matched_evidence)
        if has_promo:
            promotion_detected = True
            promotion_evidence.append({
                'source_id': source_id,
                'paragraphs_with_promo': matched_evidence,
            })
        observations.append({
            'source_id': source_id,
            'source_role': source_role,
            'url': data['final_url'],
            'collected_at': data['collected_at'],
            'snapshot_path': str(path.resolve()),
            'promotion_detected': has_promo,
            'latest_attempt': attempts.get(source_id),
        })

    record = {
        'campaign_key': 'hbf:ovhc_monitor',
        'organisation': 'HBF',
        'cover_type': 'OVHC',
        'oshc_offered': False,
        'owhc_offered': False,
        'ovhc_products': OVHC_PRODUCTS,
        'promotion_detected': promotion_detected,
        'observations': observations,
        'latest_attempts': attempts,
        'note': (
            'HBF offers OVHC only — no OSHC and no OWHC. '
            'Student visas (500, 580, 590) are explicitly excluded by HBF. '
            'The domestic PHI new-member promotion (weeks free / gift card) on '
            'hbf.com.au/terms-and-conditions/new-member-promotion explicitly '
            'excludes OVHC and is out of scope for this project. '
            'This record monitors HBF OVHC pages for any dedicated OVHC promotion. '
            'As of September 2026, no OVHC-specific promotion has been confirmed.'
        ),
        'scope_note': (
            'If promotion_detected is True, review promotion_evidence and '
            'extend parse_terms() to extract the offer fields. '
            'Do not use the domestic PHI terms page as evidence for OVHC.'
        ),
    }

    if promotion_detected:
        record['review_status'] = 'needs_review'
        record['validation_issues'] = [
            'ovhc_promotion_detected_human_review_required',
            'human_review_required',
        ]
        record['promotion_evidence'] = promotion_evidence
    else:
        record['review_status'] = 'no_active_ovhc_promotion'
        record['validation_issues'] = []

    return record
