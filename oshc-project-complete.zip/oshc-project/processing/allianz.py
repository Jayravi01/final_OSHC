"""Evidence-based Allianz 8WKSFREE review assembled from saved snapshots."""
import json
import re
from datetime import datetime
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit


CAMPAIGN_URL = 'https://www.allianzcare.com.au/en/ovhc-for-workers-8weeks-free.html'
DISCOVERY_SOURCE = 'allianz_ovhc'
CAMPAIGN_SOURCE = 'allianz_8wksfree'
SPECIALIST_SOURCES = {DISCOVERY_SOURCE, CAMPAIGN_SOURCE}


def canonical_url(value):
    """Remove tracking/query data while retaining a stable page identity."""
    parts = urlsplit(value)
    path = parts.path.rstrip('/') or '/'
    return urlunsplit((parts.scheme.lower(), parts.netloc.lower(), path, '', ''))


def _iso(value):
    return datetime.strptime(value, '%d %B %Y').date().isoformat()


def parse_terms(data):
    """Parse fields explicitly present on the Allianz campaign page."""
    paragraphs = data.get('paragraphs', [])
    text = ' '.join(' '.join(p.split()) for p in paragraphs)

    def match(pattern):
        return re.search(pattern, text, re.I)

    dates = match(
        r'between\s+(\d{1,2}[.:]\d{2}\s*[AP]M)\s+(AEST|AEDT)\s+(\d{1,2}\s+[A-Za-z]+\s+\d{4})'
        r'\s+and\s+(\d{1,2}[.:]\d{2}\s*[AP]M)\s+(AEST|AEDT)\s+(?:on\s+)?'
        r'(\d{1,2}\s+[A-Za-z]+\s+\d{4}).*?commences?\s+by\s+'
        r'(\d{1,2}\s+[A-Za-z]+\s+\d{4})'
    )
    total = match(r'(\d+)\s+weeks?\s+free\s+cover')
    hold = match(r'maintain\s+(?:their|your)\s+policy\s+for\s+(\d+)\s+consecutive\s+days')
    code = match(r'(?:promotional\s+code|use\s+code)\s*[:\u2018\u2019\'\"]*\s*(8WKSFREE)\b')

    schedule = []
    schedule_patterns = [
        ('monthly', r'(3\s*(?:rd)?\s+and\s+4\s*(?:th)?\s+month).*?pay premiums monthly'),
        ('quarterly', r'(4\s*(?:th)?\s+and\s+5\s*(?:th)?\s+month).*?pay premiums quarterly'),
        ('six_monthly', r'(7\s*(?:th)?\s+and\s+8\s*(?:th)?\s+month).*?pay premiums every 6 months'),
        ('annually', r'(13\s*(?:th)?\s+and\s+14\s*(?:th)?\s+month).*?pay premiums annually'),
    ]
    for frequency, pattern in schedule_patterns:
        found = match(pattern)
        if found:
            months = [int(n) for n in re.findall(r'\d+', found[1])]
            schedule.append({'payment_frequency': frequency, 'free_months': months,
                             'evidence_text': found[0]})

    eligible_names = [
        'Hospital Care Workers', 'Everyday Care Workers',
        'Classic Care Workers', 'Premium Care Workers',
    ]
    excluded_names = [
        'Value Care', 'Hospital Care Visitors',
        'Classic Care Visitors', 'Overseas Student Health Cover',
    ]
    eligible_evidence = [p for p in paragraphs
                         if re.search(r'Eligible policies are', p, re.I)]
    excluded_evidence = [p for p in paragraphs
                         if re.search(r'(?:ineligible|excluded).*polic', p, re.I)]
    eligible = [name for name in eligible_names if any(name.lower() in p.lower() for p in eligible_evidence)]
    excluded = [name for name in excluded_names if any(name.lower() in p.lower() for p in excluded_evidence)]
    customer_evidence = [p for p in paragraphs if re.search(
        r'new (?:customer|member)|former and existing|60 consecutive days|not transferable|cancel', p, re.I)]

    issues = ['human_review_required']
    if not code:
        issues.append('promo_code_missing_or_changed')
    if not dates:
        issues.append('date_pattern_missing_or_changed')
    if not total:
        issues.append('benefit_total_missing_or_changed')
    if not hold:
        issues.append('required_cover_period_missing_or_changed')
    if len(schedule) != 4:
        issues.append('payment_schedule_incomplete')
    if len(eligible) != len(eligible_names) or len(excluded) != len(excluded_names):
        issues.append('product_lists_incomplete')

    return {
        'product_name': 'Allianz Care Overseas Visitor Health Cover Workers',
        'target_segment': 'Workers',
        'cover_type': 'OVHC',
        'promo_code': code[1].upper() if code else None,
        'benefit_total_weeks': int(total[1]) if total else None,
        'benefit_schedule': schedule,
        'promotion_start': _iso(dates[3]) if dates else None,
        'promotion_start_local_time': dates[1].upper() if dates else None,
        'promotion_start_timezone': dates[2].upper() if dates else None,
        'join_by': _iso(dates[6]) if dates else None,
        'join_deadline_local_time': dates[4].upper() if dates else None,
        'join_deadline_timezone': dates[5].upper() if dates else None,
        'policy_start_by': _iso(dates[7]) if dates else None,
        'required_cover_days': int(hold[1]) if hold else None,
        'eligible_products': eligible,
        'excluded_products': excluded,
        'eligible_products_evidence': eligible_evidence,
        'excluded_products_evidence': excluded_evidence,
        'customer_eligibility_evidence': customer_evidence,
        'validation_issues': issues,
    }


def _latest_snapshots(raw_dir):
    latest = {}
    for path in Path(raw_dir).rglob('*.json'):
        try:
            data = json.loads(path.read_text(encoding='utf8'))
            if data.get('organisation') != 'Allianz Care Australia' or data.get('http_status') != 200:
                continue
            source = data['source_id']
            if source not in latest or data['collected_at'] > latest[source][1]['collected_at']:
                latest[source] = (path, data)
        except (ValueError, KeyError, OSError):
            continue
    return latest


def _latest_attempts(run_dir):
    attempts = {}
    for path in Path(run_dir).glob('allianz_*.json'):
        try:
            data = json.loads(path.read_text(encoding='utf8'))
            source = data['source_id']
            if source not in attempts or data['started_at'] > attempts[source]['started_at']:
                attempts[source] = data
        except (ValueError, KeyError, OSError):
            continue
    return attempts


def build_campaign(raw_dir, run_dir):
    """Join OVHC discovery evidence to the canonical campaign/terms snapshot."""
    latest = _latest_snapshots(raw_dir)
    attempts = _latest_attempts(run_dir)
    target = canonical_url(CAMPAIGN_URL)
    observations = []

    discovery = latest.get(DISCOVERY_SOURCE)
    matched_links = []
    if discovery:
        path, data = discovery
        matched_links = [url for url in data.get('links', []) if canonical_url(url) == target]
        observations.append({
            'source_id': DISCOVERY_SOURCE,
            'source_role': 'campaign_discovery',
            'url': data['final_url'],
            'collected_at': data['collected_at'],
            'snapshot_path': str(path.resolve()),
            'campaign_links': matched_links,
            'latest_attempt': attempts.get(DISCOVERY_SOURCE),
        })

    campaign = latest.get(CAMPAIGN_SOURCE)
    campaign_identity_verified = False
    if campaign:
        path, data = campaign
        page_text = ' '.join(data.get('headings', []) + data.get('paragraphs', []))
        campaign_identity_verified = (
            canonical_url(data['final_url']) == target
            and bool(re.search(r'8WKSFREE', page_text, re.I))
            and bool(re.search(r'Terms and Conditions|Promotion Dates', page_text, re.I))
        )
        observations.append({
            'source_id': CAMPAIGN_SOURCE,
            'source_role': 'offer_detail_and_terms',
            'url': data['final_url'],
            'canonical_url': canonical_url(data['final_url']),
            'collected_at': data['collected_at'],
            'snapshot_path': str(path.resolve()),
            'campaign_identity_verified': campaign_identity_verified,
            'latest_attempt': attempts.get(CAMPAIGN_SOURCE),
        })

    linked = bool(matched_links and campaign_identity_verified)
    record = {
        'campaign_key': 'allianz:8WKSFREE',
        'promo_code': '8WKSFREE',
        'canonical_url': CAMPAIGN_URL,
        'review_status': 'needs_review',
        'observations': observations,
        'discovered_urls': matched_links,
        'campaign_link_verified_in_saved_pages': linked,
        'latest_attempts': attempts,
        'note': ('One provisional campaign assembled from the OVHC discovery page and campaign terms. '
                 'Tracking parameters do not create another campaign. Latest snapshots may have different collection times.'),
    }
    if linked:
        path, data = campaign
        record.update(parse_terms(data))
        record['terms_evidence'] = {
            'source_url': data['final_url'],
            'canonical_url': canonical_url(data['final_url']),
            'collected_at': data['collected_at'],
            'snapshot_path': str(path.resolve()),
            'headings': data.get('headings', []),
            'paragraphs': data.get('paragraphs', []),
        }
    else:
        record['validation_issues'] = [
            'missing_verified_discovery_link_or_campaign_snapshot',
            'human_review_required',
        ]
    return record
