# Scraper and snapshot audit — 2026-09-16

Scope: inspect the existing collector and storage implementation, run the nine
configured public URLs once, inspect saved JSON, and reproduce edge cases offline.
No collector or processing code was changed. No cloud resources were used.

## Observed collection run

Run: `/opt/anaconda3/bin/python3 -u -m scraper.run_scraper`.
Snapshots were collected between 05:38:02 and 05:38:19 UTC.

| Source | Result | Paragraphs | Promotion blocks |
| --- | --- | ---: | ---: |
| bupa_oshc | HTTP 200, JSON saved | 115 | 0 |
| medibank_homepage | HTTP 200, JSON saved | 163 | 2 |
| medibank_overseas | HTTP 200, JSON saved | 102 | 1 |
| medibank_ovhc | HTTP 200, JSON saved | 105 | 0 |
| allianz_oshc | HTTP 403; no snapshot saved | — | — |
| allianz_ovhc | HTTP 403; no snapshot saved | — | — |
| nib_overseas | HTTP 200, JSON saved | 18 | 0 |
| nib_ovhc | HTTP 200, JSON saved | 70 | 0 |
| nib_oshc | HTTP 200, JSON saved | 49 | 0 |

All seven saved files parse as JSON and retain decoded original HTML, source
identity, requested/final URLs, timezone-aware collection timestamps, and HTTP
status. Their content_hash values match their stored full_text. This is not a
byte-for-byte HTTP response archive: original response bytes and headers are not
saved. Successful downloads do not establish complete extraction or valid offers.

An offline extraction pass on these snapshots produced two unconfirmed-segment
candidates on the Medibank homepage and one OWHC candidate on its overseas page.
It produced no OSHC candidates. These are rule outputs, not approved offers or
evidence that no OSHC promotions exist. The nib OSHC source is a page about using
existing cover; source selection requires review for promotion discovery.

## Reproduced and inspected findings

1. **Snapshot overwrite:** storage filenames have second-level precision and are
   opened with `w`. With a frozen clock, two saves of the same source produced one
   file, containing the second snapshot. Add collision-safe, non-overwriting writes.
2. **Short evidence omitted from extraction:** paragraphs shorter than 20 characters
   are removed. A synthetic `<p>20% off OSHC</p>` produced no paragraphs. Its raw
   HTML survives, but paragraph-based downstream extraction misses the offer.
3. **Limited page hash:** changing only a heading and button promo code left
   content_hash unchanged in a synthetic fixture. It hashes filtered paragraphs,
   not the full page. Retain this meaning for compatibility and add a distinct
   raw HTML hash; do not equate either hash with a verified commercial change.
4. **Failed attempts are not persisted:** the two 403 outcomes appeared only in
   terminal output. The runner exited with code 0 despite those failures. Persist
   per-source run outcomes and expose partial failure to scheduling/monitoring.
5. **Storage depends on working directory:** `data/raw` is relative to the launch
   directory, unlike processing defaults. Use an explicit or repository-relative
   output path before scheduled execution.
6. **Offer discovery is narrow:** block extraction requires promo-code text and
   selected benefit wording. Other offers may survive only in raw HTML. Linked
   offer/terms pages, images, and dynamic content are not collected automatically.

## Validation and next work

Existing unit suite: 9 tests passed. These use synthetic fixtures and do not
measure real-world accuracy or market coverage. Edge-case reproductions above
used temporary files, without altering collected snapshots.

Prioritize snapshot preservation and durable run logs, then improve evidence
extraction with real OSHC examples. Review the source register and terms before
recurring collection. Do not bypass the observed Allianz access restrictions.
Only then connect the small validated workflow to scheduled cloud execution.

Raw snapshots remain under `data/raw/` and are excluded from Git by the existing
ignore rule. This report is a manual record of this audit, not an automated run log.
