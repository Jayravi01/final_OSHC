# Promotions processing and human review workflow (0.6.0)

## Purpose

Convert saved scraper JSON into evidence-backed promotion candidates for manual review.
The processor runs offline and preserves raw snapshots. Human review decisions are
persisted separately and only apply to matching evidence fingerprints. Pricing, Visa,
Partnerships, automatic expiry detection, and Supabase/Tableau integration are not implemented.
All source code, comments, and documentation are in English.

## Run

From the repository root:

```sh
python3 -m scraper.run_scraper
python3 -m processing.run_processing
python3 -m processing.review list
python3 -m processing.review interactive
python3 -m unittest discover -s tests -v
```

The scraper and scraper tests require requests and beautifulsoup4 from requirements.txt.
Processing uses only the standard library. This machine was tested with
`/opt/anaconda3/bin/python3`. Processing supports `--raw-dir PATH --output-dir PATH`;
its defaults are repository-relative. Scraper and processing storage defaults are repository-relative.

Generated outputs are rebuilt and overwritten on each processing run. Review decisions
are stored persistently in `data/approvals/promotion_decisions.json`; do not enter them
in generated JSON. Retain raw snapshots.

## Collection improvements

- Decode downloaded HTML using a BOM or declared charset, with UTF-8 and HTTP-encoding
  fallbacks, avoiding requests' default Latin-1 interpretation of UTF-8 pages.
- Preserve decoded `raw_html`, existing paragraphs and links.
- Add `promotion_blocks`: compact DOM containers around promo-code text, including
  button/link text, the container HTML, and labeled absolute links.
- Block grouping stops at multiple promo-code labels, apparent terms text, or a size limit.
  It is a heuristic, not a complete site-independent HTML segmentation method.
- A link labeled Find out more is a detail link, not automatically a verified terms URL.
  Linked pages are not fetched automatically.

## Outputs in data/processed

| File | Meaning |
| --- | --- |
| promotion_candidates.json | All candidate observations and tentative versions |
| approval_targets.json | All current generic and specialist records, including resolved records |
| approval_queue.json | All generic and specialist records still requiring a decision |
| review_queue.json | Generic candidates still requiring a decision (compatibility output) |
| approval_audit.json | Applied, stale, and orphaned stored decisions |
| validated_promotions.json | Current records with a matching `approved` decision |
| candidate_events.json | First-observed or changed candidate observations, not verified market events |
| source_audit.json | Raw files, missing sources, errors and filtered content |
| RUN_REPORT.md | Processing totals and limitations |

A source's latest valid saved snapshot may still be stale. The collector persists each attempt in data/runs, including failed runs. Review those logs separately; processing uses saved successful snapshots and does not yet automatically mark stale candidates from failed attempts. A missing candidate is never assumed to be an ended promotion. Historical
candidates remain in promotion_candidates.json even when absent from review_queue.json.

## Schema migration

Version 0.2.0 replaces top-level promotion_type, offer_value and offer_unit with a `benefits`
array. Each candidate represents an offer context rather than a separate incentive. IDs and
fingerprints are recalculated when raw history is reprocessed; do not join previously exported
0.1.0 IDs to 0.2.0 IDs without a migration/review. Original snapshots are not rewritten.

## Candidate data dictionary

| Field | Type / values | Meaning |
| --- | --- | --- |
| record_id | string | Tentative source-level identity based on code, product fallback, or masked text |
| snapshot_id | string | Hash of source, timestamp, paragraphs and promotion blocks |
| version | integer | Increments when extracted fields or evidence change |
| organisation / source_id | string | Source registry labels |
| source_url | URL | Actual final URL recorded in the snapshot |
| collected_at | timezone-aware ISO datetime | Observation time, not publication date |
| product_name | string / null | Product phrase or overseas category inferred from the offer context |
| cover_type | OSHC / OVHC / OWHC / null | Explicit unambiguous overseas category; not inferred from exclusions |
| scope_status | string | overseas_candidate or unconfirmed_do_not_publish_as_overseas |
| benefits | array | Multiple benefits belonging to this candidate |
| promo_code | string / null | Code extracted in the card or immediately adjacent code paragraph |
| join_by | ISO date / null | Unambiguous offer ends / join by date; other deadline formats need review |
| detail_links | array | Link text and URL from the same offer block |
| terms_url | URL / null | Source page when code-linked terms are captured; otherwise null |
| evidence | array | Exact raw_text and clean_text, with block_id or zero-based paragraph_index |
| review_status | needs_review | No automatic approval |
| validation_issues | array | Missing/ambiguous fields, invalid values and review requirements |
| extraction_method / rule_version | rules / 0.3.0 | Extraction provenance |
| fingerprint | string | Hash of structured values and linked evidence |

## Benefit schema

All benefit objects include `type`, `unit`, and `evidence_text` pointing to a substring of
cleaned source evidence. Fields vary by benefit type:

| Type | Additional fields |
| --- | --- |
| free_cover | value; qualifier = exact or up_to |
| gift_card / cashback / dollar_discount | value (AUD; Australian-site assumption requires review) |
| percentage_discount | value (percent; must be greater than zero and at most 100) |
| reward_points | value, programme, audience array, redemption_value {value, unit} |
| waiting_period_waiver | periods array, applies_to |

`exact` describes the wording, not guaranteed eligibility. Benefits still depend on terms.
Points and their gift-card redemption equivalent are one reward, not two additive payments.
Audience variants are alternatives, not cumulative rewards. Headline maximum redemption
amounts repeated in the detailed points breakdown are suppressed.

Supported example: 10WEEKSPLUS has up to 10 free weeks, two audience-specific Live Better
points variants, and a 2/6-month Extras waiting-period waiver. EXTRA4WEEKS has 4 free weeks,
a $50 gift card, and a 2/6-month Extras waiting-period waiver. These examples are not
classified as overseas insurance without product/terms verification.

## Validation and known limits

- Invalid input files are isolated in source_audit.errors. Required input fields are source_id,
  organisation, final_url, timezone-aware collected_at, nonempty paragraph strings, and HTTP 200.
- Raw and cleaned text are retained. Historical mojibake is repaired conservatively;
  ambiguous corruption can remain. Old snapshots cannot gain a missing promo code from a
  later screenshot or snapshot.
- Full cards are preferred; paragraph fallback supports legacy snapshots. Navigation and
  explicit other-insurance content are filtered. Some legitimate offers may be missed.
- Eligibility and exclusions remain evidence text, not fully normalized validated fields.
- Code reuse and product-based fallback can merge distinct campaigns on one source. Cross-source
  duplicates are suggested in duplicate_review.json and are not automatically merged. Manual campaign identity review is required before reporting counts.
- Changes in collection structure or extraction logic can produce candidate changes without a
  commercial change. First observed does not mean newly launched. No expiry/active status is computed.
- Rule coverage is limited: specific points wording, ampersand-separated waiting periods, selected
  incentive/date formats. Unsupported formats, images, PDFs and dynamic content may be missed.
- Tests include synthetic DOM examples based on supplied screenshots, encoding checks, and history
  behavior. They do not establish the proposal's 95% accuracy target or complete market coverage.

## Source provenance

Medibank homepage is separately registered as medibank_homepage (mixed segment).
The old overseas URL remains attached to its original evidence. Do not substitute a homepage
URL on a historical offer. Although a previous web-tool check returned 403, the latest scraper
run collected both Medibank pages successfully. Access outcomes can vary by client and time.

## Review workflow

### Easiest option: interactive wizard

Run one command and choose a numbered decision for each unresolved record. The
wizard asks for the reviewer name once, shows the offer summary and source URLs,
saves every decision immediately, and refreshes processing after the session:

```sh
python3 -m processing.review interactive
```

Enter `s` to skip one record or `q` to save and quit. The detailed commands below
remain available for automation or for changing one known target directly.

### Individual commands

1. Run `python3 -m processing.review list` and choose a target ID.
2. Open its readable review file or run `python3 -m processing.review show TARGET_ID`.
3. Locate the raw file using source_audit.json and compare the evidence with the live page.
4. Verify campaign identity, overseas cover scope, benefits, dates, eligibility,
   exclusions, payment schedule, and terms.
5. Record one decision using a command below.
6. Rerun `python3 -m processing.run_processing`. Only matching approved evidence is
   written to validated_promotions.json.

Supported decisions:

```sh
python3 -m processing.review approve TARGET_ID --reviewer "Name" --note "Checked against terms"
python3 -m processing.review reject TARGET_ID --reviewer "Name" --note "Domestic promotion"
python3 -m processing.review needs-correction TARGET_ID --reviewer "Name" --note "Date is wrong"
python3 -m processing.review needs-more-evidence TARGET_ID --reviewer "Name" --note "Terms unavailable"
python3 -m processing.review expire TARGET_ID --reviewer "Name" --note "Joining deadline passed"
python3 -m processing.review confirm-no-active hbf:ovhc_monitor --reviewer "Name" --note "All three OVHC pages checked"
```

An approved record may include reviewed corrections. Values use JSON syntax when
possible; unquoted text is retained as a string:

```sh
python3 -m processing.review approve TARGET_ID --reviewer "Name" \
  --field cover_type='"OSHC"' --field join_by='"2026-10-31"'
```

Every decision records its reviewer, timezone-aware review timestamp, note,
fingerprint, and optional corrections. Decisions are append-only audit events. The
latest decision for the same target and fingerprint applies. A later evidence change
produces a new fingerprint, makes the old decision stale, removes the record from
validated output, and returns the current record to the approval queue. A decision for
a campaign that no longer has a current target is reported as orphaned.

The decision meanings are:

- `approved`: publishable after applying the recorded field corrections.
- `rejected`: reviewed and excluded, for example a domestic or false-positive offer.
- `needs_correction` / `needs_more_evidence`: remains in the approval queue.
- `expired`: reviewed and excluded from current validated promotions.
- `no_active_promotion`: confirms a negative monitoring result; it cannot create a
  validated promotion.

A candidate whose extracted `scope_status` is `unconfirmed_do_not_publish_as_overseas`
cannot be approved as-is: `record_decision` raises an error unless the same decision
supplies a `field_corrections` `cover_type` of `OSHC`, `OVHC` or `OWHC`. That status
means the rules could not confirm the offer belongs to this project's overseas market
(the record's `cover_type` is null); approving it silently would let an unrelated or
domestic offer, such as a same-page discount on another insurance product, into
validated_promotions.json with no visible sign that its market was never confirmed.
The interactive wizard does not collect corrections, so this class of record can only
be approved through the `approve` command, which forces a deliberate, recorded choice
of cover type rather than a same-day-testing accidental approval.

Operational review details:

1. Open review_queue.json and locate the raw file using source_audit.json.
2. Compare block/paragraph evidence with the candidate and each benefit.
3. Open captured detail links and verify eligibility, audience, dates, exclusions and terms URL.
4. Never approve a homepage banner without checking its detail page or terms.
5. Add suitable OSHC campaign and terms sources to evaluate the project's priority segment.


## Medibank review update (0.3.0)

- Added direct OSHC and Working visas sources; homepage remains secondary discovery.
- Preserve short paragraphs; retain a separate raw_html_hash alongside the legacy
  paragraph-only content_hash. Original snapshots remain unchanged.
- Immutable snapshot writes use repository-relative paths, unique names and atomic
  publication. Each collector attempt has a durable log; any failed attempt makes
  the command return a nonzero exit code. There is no automatic retry or bypass.
- Product classification uses offer context, not exclusions or prior member cover in
  linked terms. Same-code terms are retained and selected conditions extracted.
  This is heuristic; incomplete or split terms still need human review.
- Split free-cover stages retain timing text. Extras offers aimed at existing OSHC/
  Workers members retain audience separately and are not classified as OSHC discounts.
- Matching organisation, cover and promo code across pages generates a duplicate
  review suggestion. Identity and terms still require confirmation before merging.
- Discovery channel metadata records a user-reported Google Ads discovery, not an
  assertion of ad-exclusive eligibility. The canonical Working visas page was fetched;
  equivalence with the full ad-tracking URL has not been verified.
- Full eligibility normalization, automatic ended status, and automatic extraction of
  general rewards programmes remain unimplemented. Human approval persistence is
  implemented by `processing.review` and is deliberately separate from generated files.

Review commands:

```sh
python3 -m scraper.run_scraper --organisation Medibank
python3 -m processing.run_processing
python3 -m processing.build_review
```

`data/review/medibank_*.md` contains one readable review file per latest saved page,
including candidates, terms evidence, headings, paragraphs and captured links. It
is not a browser rendering, and does not prove every HTML block is currently visible.
Review files and processing outputs are regenerated; do not store approvals in them.
The builder chooses the latest saved snapshot; consult data/runs for later failures.

## Bupa FREE8 update (0.4.0)

Added Bupa Overseas Visitors (primary), both Working pages (supporting), and the
explicit FREE8 terms URL, retaining OSHC. Bupa's `modular-text` text attributes
are decoded as HTML fragments without running JavaScript. Snapshots preserve the
original raw HTML, plus component index, raw attribute and extracted text.

Run:

```sh
python3 -m scraper.run_scraper --organisation Bupa
python3 -m processing.run_processing
python3 -m processing.build_review
```

`data/processed/bupa_free8_review.json` is a separate, provisional campaign review
with three page observations when all pages are collected. It links terms only
when a saved page actually links to the configured terms URL and the saved terms
contain the promo code. It is not inserted into validated_promotions.json.
`data/review/bupa_free8.md` is its readable summary; individual page files include
component evidence, paragraphs, links and a raw snapshot link.

The Bupa FREE8 sources use the specialist review rather than generic candidate
counts, preventing a terms page or the 6+2 schedule from becoming extra offers.
This adapter is deliberately scoped to FREE8; it is not a complete detector for
future campaigns. Missing or changed date, product and benefit patterns are
flagged for review. Product lists and customer eligibility retain original text.
The total benefit is separate from mutually exclusive annual/non-annual schedules.
Joining deadline and policy commencement deadline are separate fields. Membership
transfer from OSHC is not classified as an OSHC discount.

Latest successful snapshots are combined with explicit timestamps; this is not a
historical as-of join. Latest attempt outcomes are included so a failed newer run
can be identified. Human review remains required, including stale evidence and
changes to campaign identity or conditions. No ad-exclusive eligibility is inferred.

## Allianz 8WKSFREE update (0.5.0)

Allianz collection now registers its homepage as secondary discovery, retains the
OSHC product page, uses the OVHC page as product/campaign discovery, and adds the
canonical 8WKSFREE campaign detail and terms page. The tracked banner destination
is evidence of discovery, while query and fragment parameters are removed only for
page-identity comparison. The original tracked URL remains in the campaign review.

Run:

```sh
python3 -m scraper.run_scraper --organisation "Allianz Care Australia"
python3 -m processing.run_processing
python3 -m processing.build_review
```

`data/processed/allianz_8wksfree_review.json` joins the latest saved OVHC discovery
snapshot to the latest saved campaign snapshot only when the former links to the
same canonical page and the latter contains both the promotion code and terms
evidence. `data/review/allianz_8wksfree_campaign.md` is the readable combined
review. The four page-level `allianz_*.md` files retain extracted evidence when a
snapshot succeeds, or the latest failed-attempt status when no snapshot exists.

The specialist parser records OVHC as the insurer's cover terminology and Workers
as the target segment. It keeps the eight-week total separate from the month pairs
for monthly, quarterly, six-monthly and annual payments. Promotion start, joining
deadline and policy commencement deadline are distinct fields. Eligible and
excluded products, the 60-day active-cover requirement and customer restrictions
retain source evidence and require human review.

Allianz OVHC and campaign pages are excluded from generic candidate generation so
the banner, headline and repeated terms cannot become separate offers. Homepage
and OSHC remain eligible for general discovery. This adapter is scoped to
8WKSFREE and does not establish complete future-campaign coverage.

Earlier compliant HTTP collection returned 403 for Allianz. The collector records
any new failed attempts and returns a nonzero status; it does not bypass access
controls or create a snapshot from screenshots.

## Allianz collection governance decision (2026-09-20)

This is a collection-configuration and governance decision, not an extraction
rule change; RULE_VERSION is unaffected.

Allianz's block was investigated further. It is Cloudflare bot-management: the
403 response for a blocked request carries a `__cf_chl_rt_tk` challenge token,
and the block covers the whole domain, including robots.txt, so no alternative
URL on this domain was expected to differ and none did.

A generic `download_page_browser` fallback exists in `scraper/base_scraper.py`
for `collection_method: browser_on_403`, and rendering Allianz's pages with a
non-headless (visible) Chromium session does pass the Cloudflare challenge and
returns real page content. It is deliberately not enabled for any Allianz
source. Passing a bot-management challenge by rendering the page is
circumventing a technical control the publisher put in place to stop
automated collection, which this project's own collection governance rules
out (Section 5 of the project proposal: public information only; no bypassing
of logins, CAPTCHAs, paywalls, or technical controls). It also requires a real
display, which a scheduled/cron collection run does not have, so it could not
run unattended even if it were permitted. The fallback code and its test
remain in the repository as general-purpose infrastructure — usable for a
site that blocks by User-Agent string alone — but no configured source uses
it.

The block is not constant. Repeated compliant HTTP requests, at the existing
2-second inter-source delay and with no special handling, succeeded for
`allianz_homepage` and `allianz_ovhc` in roughly one attempt in six during
this investigation, while `allianz_oshc` and `allianz_8wksfree` did not
succeed in the same run. This is consistent with probabilistic bot-scoring
rather than a fixed rule, and is not a bypass: it is the same compliant
request, sometimes accepted. A source that fails today is not necessarily
unavailable tomorrow, and a single day's failed attempt should not be read as
a permanent block. The practical implication for scheduled collection is that
repeating the existing daily run, or retrying a failed Allianz source a small
number of times within a day at the existing delay, is expected to collect a
genuine snapshot on most days without any change to collection method.

`data/raw` may still contain snapshots collected via the browser fallback
before this decision was recorded; they carry `collection_method: "browser"`
and are distinguishable from `"http"` snapshots on the same field. `data/raw`
is not tracked by version control. Processing does not currently prefer an
`"http"` snapshot over a more recent `"browser"` one for the same source; the
latest successful snapshot is used regardless of collection method, so a
specialist review built while an old browser snapshot is still the latest for
a source reflects that snapshot until a compliant collection succeeds and
supersedes it.

## PDF terms collection (snapshot schema 1.3)

Fund terms are frequently published as PDF rather than HTML. nib's join-offer
terms are the first such source observed in this repository; Bupa's FREE8 and
Allianz's 8WKSFREE terms happen to be HTML pages.

Previously the collector decoded every response body as text. A PDF response
therefore produced a snapshot that reported HTTP 200 and collection success
while containing no paragraphs, no headings, no links and the SHA-256 of an
empty string as its `content_hash`. Processing accepted that snapshot as a valid
input and reported zero candidates, which is indistinguishable from an HTML page
that genuinely carries no offer. Because the empty-string hash is constant, a
replaced terms document could never produce a change event.

`download_page` now reads the response media type and returns PDF payloads
undecoded; `extract_document_data` routes each payload to the extractor for its
media type. PDF text is extracted with pypdf (BSD-3-Clause, no dependencies of
its own) in its default mode, which follows the content stream and keeps the
multi-column terms layouts used by health funds in reading order. Layout mode
and pdfminer-based extraction interleave those columns instead.

PDF snapshots use the shared snapshot fields, so processing and review building
are unchanged, plus:

| Field | Meaning |
| --- | --- |
| media_type | `application/pdf`; HTML snapshots record `text/html` |
| raw_document_hash | SHA-256 of the source bytes; detects a replaced document even when no text is extracted |
| pdf_page_count | Pages read |
| raw_html / raw_html_hash | Null; binary source bytes are not embedded in JSON |

Known limits:

- Paragraph boundaries follow blank lines in the extracted text. A generator
  that emits none yields a single paragraph. No text is lost, but clause-level
  granularity is unavailable for such a document.
- Extraction artifacts occur, for example a space inside a word or around a
  hyphen. Text is retained exactly as extracted rather than repaired, so an
  exact-phrase rule can miss an affected phrase. Compare against the source
  document during review.
- A scanned or image-only PDF yields no text. That snapshot records the
  `no_text_extracted` quality warning instead of appearing as an empty page.
- Source bytes are not archived. The document is retained as extracted text plus
  `raw_document_hash`, consistent with existing snapshots, which are not
  byte-for-byte HTTP response archives.
- Collecting a PDF source requires pypdf from requirements.txt. Processing still
  uses only the standard library.

## nib update (0.6.0)

nib now has the same source roles as Medibank: a homepage registered as secondary
discovery, an overseas directory page, and OSHC, OVHC and OWHC product pages.

`nib_oshc` previously addressed `overseas-students/using-your-oshc`, which
explains existing cover rather than presenting the product, and was recorded as
a source-selection concern in SCRAPER_AUDIT.md. It now addresses
`overseas-students`. Snapshots collected before this change record the previous
address in their own `final_url` and are unchanged. The 485 temporary graduate
visa page is registered for OWHC.

### Offers published as page data

nib publishes its current join offer in the page data of a client-rendered
homepage, not in the HTML text. Removing script elements therefore discarded the
offer, and the homepage produced no candidate while a campaign was running. This
is the same class of problem as Bupa's `modular-text` attributes.

Embedded `__NEXT_DATA__` and JSON-LD scripts are now parsed as JSON before
scripts are removed. Scripts are parsed, never executed. Publishers whose offer
shape is known are mapped to a `structured_offers` snapshot field holding the
offer name, customer-facing copy, start and end dates, terms URL, published visa
targeting and the display flag. Only nib's shape is mapped; other hosts record
an empty list.

Publishing workflow fields that name an individual, such as `lastModifiedBy`,
are dropped before the offer is stored, in line with the public-information-only
collection rule. Note that `raw_html` remains a verbatim copy of the page, as it
is for every source, so anything published in the page itself is retained there.

A structured offer is retained as a candidate even when no benefit wording is
recognised, and carries `benefit_wording_not_recognised`. The publisher labels
the record an offer and states its own dates, so discarding it would hide a live
campaign whose wording the rules do not yet cover. Dates stated in the offer
record are preferred over a date matched in prose, and the published offer name
anchors record identity so that reworded copy is a change rather than a new
offer. Linked terms documents are still not fetched automatically.

Presence in page data is not proof that an offer is displayed; nib's record
carries its own display flag, which is retained for review. Scope is not
inferred from the offer record: the campaign observed during this update applies
to a resident product and is classified
`unconfirmed_do_not_publish_as_overseas`, with its terms confirming Medicare
eligibility. An empty `visas` list states no visa targeting and does not confirm
a cover type.

The waiting-period rule now recognises skipping as well as waiving a wait, in
the singular or plural, with an optional service name between the period and the
noun. Stating that a waiting period applies is still not a waiver.

Run:

```sh
python3 -m scraper.run_scraper --organisation nib
python3 -m processing.run_processing
python3 -m processing.build_review
```
