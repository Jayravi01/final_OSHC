"""
Public competitor source configuration.

All web pages which have been scraped are kept here,
so that additional sources can be added without modifying the
scraper program itself.
"""


SOURCES = [

    # -------------- BUPA --------------

    {
        "source_id": "bupa_oshc",
        "organisation": "Bupa",
        "market_segment": "OSHC",
        "url": "https://www.bupa.com.au/health-insurance/oshc"
    },


    {
        "source_id": "bupa_visitors",
        "organisation": "Bupa",
        "market_segment": "Overseas - classify using offer terms",
        "source_role": "primary_product",
        "url": "https://www.bupa.com.au/health-insurance/cover/overseas-visitors"
    },

    {
        "source_id": "bupa_working_visitors",
        "organisation": "Bupa",
        "market_segment": "Overseas - classify using offer terms",
        "source_role": "supporting_product",
        "url": "https://www.bupa.com.au/health-insurance/cover/overseas-visitors/working-visitors"
    },

    {
        "source_id": "bupa_working",
        "organisation": "Bupa",
        "market_segment": "Overseas - classify using offer terms",
        "source_role": "supporting_product",
        "url": "https://www.bupa.com.au/health-insurance/overseas-visitors/working"
    },

    {
        "source_id": "bupa_free8_terms",
        "organisation": "Bupa",
        "market_segment": "Overseas - classify using offer terms",
        "source_role": "offer_terms",
        "url": "https://www.bupa.com.au/campaigns/health-insurance/ovcfree8weeks"
    },

    # -------------- MEDIBANK --------------

    {
        "source_id": "medibank_oshc",
        "organisation": "Medibank",
        "market_segment": "OSHC",
        "source_role": "primary_product",
        "url": "https://www.medibank.com.au/overseas-health-insurance/oshc/"
    },
    {
        "source_id": "medibank_working_visas",
        "organisation": "Medibank",
        "market_segment": "OWHC",
        "source_role": "primary_product",
        "discovery_channel": "google_ads_user_reported",
        "discovery_campaign": "Overseas|Brand|AUS|WorkerInsurance|Exact",
        "url": "https://www.medibank.com.au/overseas-health-insurance/working-visas/"
    },

    {
        "source_id": "medibank_worker8_campaign",
        "organisation": "Medibank",
        "market_segment": "OWHC",
        "source_role": "offer_detail_and_terms",
        "url": "https://www.medibank.com.au/overseas-health-insurance/c/worker8/"
    },

    # User-supplied discovery page. Classify each offer independently because
    # homepage campaigns may concern domestic or other insurance products.
    {
        "source_id": "medibank_homepage",
        "source_role": "secondary_discovery",
        "organisation": "Medibank",
        "market_segment": "Mixed - requires offer-level classification",
        "url": "https://www.medibank.com.au/"
    },

    {
        "source_id": "medibank_overseas",
        "source_role": "overseas_directory",
        "organisation": "Medibank",
        "market_segment": "Overseas Health Insurance",
        "url": "https://www.medibank.com.au/overseas-health-insurance/"
    },

    {
        "source_id": "medibank_ovhc",
        "source_role": "primary_product",
        "organisation": "Medibank",
        "market_segment": "OVHC",
        "url": "https://www.medibank.com.au/overseas-health-insurance/visitors/"
    },


    # -------------- ALLIANZ CARE AUSTRALIA --------------

    # These four URLs return HTTP 403 from a compliant request. The block is
    # Cloudflare bot-management (a JS challenge), confirmed domain-wide: even
    # robots.txt is blocked, so no alternative path on this domain is expected
    # to differ. A non-headless Playwright render does pass the challenge, but
    # deliberately rendering to get past a bot-management control is a bypass
    # of a technical control, which this project's own collection governance
    # rules out; it also requires a real display, so it cannot run unattended
    # on the scheduled/cron collection this project needs. `collection_method`
    # is intentionally left unset here so scrape_source uses the plain HTTP
    # path only, and a 403 is recorded as a failed attempt like any other
    # blocked source, rather than worked around. See PROCESSING.md for the
    # decision record and processing/allianz.py, which remains ready to build
    # the 8WKSFREE campaign once a permitted snapshot exists.
    {
        "source_id": "allianz_homepage",
        "organisation": "Allianz Care Australia",
        "market_segment": "Mixed - requires offer-level classification",
        "source_role": "secondary_discovery",
        "url": "https://www.allianzcare.com.au/en.html"
    },

    {
        "source_id": "allianz_oshc",
        "organisation": "Allianz Care Australia",
        "market_segment": "OSHC",
        "source_role": "primary_product",
        "url": "https://www.allianzcare.com.au/en/visas/student-visa-oshc.html"
    },

    {
        "source_id": "allianz_ovhc",
        "organisation": "Allianz Care Australia",
        "market_segment": "OVHC",
        "source_role": "primary_product_and_campaign_discovery",
        "url": "https://www.allianzcare.com.au/en/visas/visitors-visa-ovhc.html"
    },

    {
        "source_id": "allianz_8wksfree",
        "organisation": "Allianz Care Australia",
        "market_segment": "OVHC Workers",
        "source_role": "offer_detail_and_terms",
        "url": "https://www.allianzcare.com.au/en/ovhc-for-workers-8weeks-free.html"
    },


    # -------------- NIB --------------

    # nib publishes its current join offer in embedded page data rather than in
    # visible homepage text. Classify each offer independently: a homepage
    # campaign may concern resident cover rather than an overseas product.
    {
        "source_id": "nib_homepage",
        "organisation": "nib",
        "market_segment": "Mixed - requires offer-level classification",
        "source_role": "secondary_discovery",
        "url": "https://www.nib.com.au/"
    },

    {
        "source_id": "nib_overseas",
        "organisation": "nib",
        "market_segment": "Overseas Health Insurance",
        "source_role": "overseas_directory",
        "url": "https://www.nib.com.au/overseas-health-insurance"
    },

    # Replaces the previous using-your-oshc address, which explains existing
    # cover rather than presenting the product. Earlier nib_oshc snapshots
    # record that address in their own final_url and are unchanged.
    {
        "source_id": "nib_oshc",
        "organisation": "nib",
        "market_segment": "OSHC",
        "source_role": "primary_product",
        "url": "https://www.nib.com.au/overseas-students"
    },

    {
        "source_id": "nib_ovhc",
        "organisation": "nib",
        "market_segment": "OVHC",
        "source_role": "primary_product",
        "url": "https://www.nib.com.au/overseas-working-visitors"
    },

    {
        "source_id": "nib_485_visa",
        "organisation": "nib",
        "market_segment": "OWHC",
        "source_role": "primary_product",
        "url": "https://www.nib.com.au/overseas-working-visitors/485-temporary-graduate-visa"
    },


    # -------------- HBF --------------

    # HBF's overseas range is OVHC. Its domestic new-member campaigns can be
    # present in site-wide content, so these sources use the HBF specialist
    # review instead of producing generic promotion candidates.
    {
        "source_id": "hbf_ovhc_workers",
        "organisation": "HBF",
        "market_segment": "OVHC Workers",
        "source_role": "primary_product_workers",
        "url": "https://www.hbf.com.au/health-insurance/overseas/working-in-australia"
    },

    {
        "source_id": "hbf_ovhc_visitors",
        "organisation": "HBF",
        "market_segment": "OVHC Visitors",
        "source_role": "primary_product_visitors",
        "url": "https://www.hbf.com.au/health-insurance/overseas/visiting-australia"
    },

    {
        "source_id": "hbf_ovhc_hub",
        "organisation": "HBF",
        "market_segment": "OVHC",
        "source_role": "overseas_directory",
        "url": "https://www.hbf.com.au/health-insurance/overseas/what-is-ovhc"
    }

]
