"""Web scraping package for competitor data collection."""
# helps to make scraper/ a python package