"""
Common webpage scraper.

This file contains the reusable scraping functions used
for Bupa, Medibank, Allianz Care Australia and nib.
"""

from datetime import datetime, timezone
from hashlib import sha256
from io import BytesIO
from urllib.parse import urljoin, urlparse
from html import escape

import json
import os
import requests
import re
from bs4 import BeautifulSoup

try:
    from pypdf import PdfReader
except ImportError:
    # Report the missing dependency only when a PDF source is actually collected,
    # so HTML collection still works from a plain requests/beautifulsoup4 install.
    PdfReader = None


# -------------- Request --------------

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 "
        "(compatible; RMIT-Market-Intelligence-Project/1.0)"
    )
}

TIMEOUT = 30

HTML_MEDIA_TYPE = "text/html"
PDF_MEDIA_TYPE = "application/pdf"
PDF_SIGNATURE = b"%PDF-"


# -------------- Downloading webapge --------------

def response_media_type(response):
    """Declared media type without its charset parameter."""
    return (response.headers.get("content-type") or "").split(";")[0].strip().lower()


def is_pdf(payload, media_type):
    """Trust the declared type, then the file signature: a served file may lack one."""
    return media_type == PDF_MEDIA_TYPE or (
        isinstance(payload, bytes) and payload.startswith(PDF_SIGNATURE))


def download_page(url):
    """
    Download one public document.

    Parameters
    ----------
    url : str
        Address of the document.

    Returns
    -------
    tuple
        Payload, final URL, HTTP status code and media type. The payload is
        decoded text for HTML and undecoded bytes for PDF.
    """

    response = requests.get(
        url,
        headers=HEADERS,
        timeout=TIMEOUT
    )

    response.raise_for_status()

    media_type = response_media_type(response)

    # Decoding PDF bytes as text silently produces an empty extraction that
    # still reports HTTP 200, so PDF payloads are returned undecoded.
    if is_pdf(response.content, media_type):

        return (
            response.content,
            response.url,
            response.status_code,
            PDF_MEDIA_TYPE
        )

    return (
        decode_html(response.content, response.encoding),
        response.url,
        response.status_code,
        media_type or HTML_MEDIA_TYPE
    )


class _BrowserResponse:
    """Small requests-compatible response shape for persisted attempt logs."""

    def __init__(self, status_code):
        self.status_code = status_code


def download_page_browser(url, headless=True):
    """Render one HTML page in Chromium and return its final DOM."""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise RuntimeError(
            "Browser collection requires Playwright. Install requirements and "
            "run `python -m playwright install chromium`."
        ) from exc

    executable_path = os.environ.get("PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH")

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(
            headless=headless,
            executable_path=executable_path,
        )
        try:
            # Keep Chromium's real browser user agent. Reusing the HTTP
            # collector's explicit bot identifier would trigger the same WAF.
            page = browser.new_page()
            response = page.goto(url, wait_until="domcontentloaded", timeout=TIMEOUT * 1000)
            if response is None:
                raise RuntimeError(f"Browser navigation returned no response for {url}")
            page.wait_for_load_state("load", timeout=TIMEOUT * 1000)
            html = page.content()
            cloudflare_challenge = (
                "Just a moment" in page.title() or
                "__cf_chl" in page.url or
                "cf-chl-" in html
            )
            if response.status >= 400 or cloudflare_challenge:
                raise requests.HTTPError(
                    f"{response.status} browser response for url: {page.url}",
                    response=_BrowserResponse(response.status),
                )
            return html, page.url, response.status, HTML_MEDIA_TYPE
        finally:
            browser.close()


def decode_html(content, fallback_encoding=None):
    """Prefer BOM/meta declarations over requests' default Latin-1 decoding."""
    if content.startswith(b'\xef\xbb\xbf'):
        return content.decode('utf-8-sig')
    declared = re.search(br'charset\s*=\s*[\"\x27]?([a-zA-Z0-9_-]+)', content[:8192], re.I)
    if declared:
        try:
            return content.decode(declared.group(1).decode('ascii'))
        except (LookupError, UnicodeError):
            pass
    try:
        return content.decode('utf-8')
    except UnicodeError:
        return content.decode(fallback_encoding or 'windows-1252', errors='replace')


# -------------- Page data embedded as JSON --------------

# Client-rendered pages keep offer copy in embedded page data rather than in
# HTML text, so removing script elements alone would discard the offer.
EMBEDDED_JSON_SCRIPT_IDS = {"__NEXT_DATA__"}
EMBEDDED_JSON_SCRIPT_TYPES = {"application/ld+json"}

# Publishing workflow fields identify individual staff. Collection is limited to
# public product information, so they are dropped rather than stored.
PERSONAL_DATA_KEYS = {"lastmodifiedby", "modifiedby", "createdby", "author",
                      "owner", "email", "contactemail"}

NIB_HOSTS = {"www.nib.com.au", "nib.com.au"}

# Customer-facing copy only; internal identifiers and workflow fields are kept
# out of the text passed to offer extraction.
NIB_OFFER_TEXT_FIELDS = ("headerText", "offerName1", "offerName2",
                         "supportingText1", "supportingText2", "supportingText3",
                         "termsAndConditions")


def strip_personal_data(value):
    """Remove fields naming an individual from captured page data."""
    if isinstance(value, dict):
        return {key: strip_personal_data(item) for key, item in value.items()
                if key.lower() not in PERSONAL_DATA_KEYS}
    if isinstance(value, list):
        return [strip_personal_data(item) for item in value]
    return value


def embedded_json(soup):
    """Parse embedded page-data scripts, skipping any that is not valid JSON."""
    documents = []
    for node in soup.find_all("script"):
        name = node.get("id")
        if name not in EMBEDDED_JSON_SCRIPT_IDS and node.get("type") not in EMBEDDED_JSON_SCRIPT_TYPES:
            continue
        try:
            documents.append((name or node.get("type"),
                              json.loads(node.string or node.get_text() or "")))
        except ValueError:
            continue
    return documents


def nib_structured_offers(documents, final_url):
    """
    Read the offer object nib publishes in its page data.

    The publisher labels this record an offer and states its own dates, so it is
    stronger evidence than a phrase matched in prose. Its presence is not proof
    that the offer is displayed, and its scope still requires review: an offer
    here may apply to resident cover rather than an overseas product.
    """
    offers = []
    for name, document in documents:
        page = document.get("props", {}).get("pageProps", {}) if isinstance(document, dict) else {}
        offer = page.get("offer")
        if not isinstance(offer, dict):
            continue
        text = " ".join(offer[field].strip() for field in NIB_OFFER_TEXT_FIELDS
                        if isinstance(offer.get(field), str) and offer[field].strip())
        terms_url = offer.get("termsAndConditionsLink")
        offers.append({
            "offer_id": f"structured_offer_{len(offers)}",
            "source_field": name,
            "offer_name": offer.get("name"),
            "text": text,
            "starts_at": offer.get("startDate") or None,
            "ends_at": offer.get("endDate") or None,
            "terms_url": urljoin(final_url, terms_url) if terms_url else None,
            # An empty visa list states no visa targeting; it does not confirm
            # which cover type the offer applies to.
            "visas": offer.get("visas") if isinstance(offer.get("visas"), list) else None,
            "displayed_on_homepage_hero": page.get("showOfferOnHomepageHero"),
            "raw_offer": strip_personal_data(offer),
        })
    return offers


def structured_offers(soup, final_url):
    """Offer records embedded in page data, for publishers whose shape is known."""
    if urlparse(final_url).hostname in NIB_HOSTS:
        return nib_structured_offers(embedded_json(soup), final_url)
    return []


def promotion_blocks(soup, final_url):
    """Find compact DOM containers around promo-code text, preserving linked context."""
    blocks, seen = [], set()
    for node in soup.find_all(string=re.compile(r'promo(?:tion)? code', re.I)):
        if node.find_parent(['nav', 'header', 'footer']):
            continue
        for parent in node.parents:
            text = parent.get_text(' ', strip=True)
            if len(text) > 3500 or len(re.findall(r'promo(?:tion)? code', text, re.I)) > 1:
                break
            if re.search(r'\b(?:excludes|not available|must take out)\b', text, re.I):
                break
            if not re.search(r'\d+\s+weeks?\s+free|\$\s*\d+\s+gift card', text, re.I):
                continue
            if text not in seen:
                seen.add(text)
                links = [{'text': a.get_text(' ', strip=True),
                          'url': urljoin(final_url, a['href'])}
                         for a in parent.find_all('a', href=True)
                         if urljoin(final_url, a['href']).startswith(('https://', 'http://'))]
                blocks.append({'block_id': f'promotion_block_{len(blocks)}', 'text': text,
                               'html': str(parent), 'links': links})
            break
    return blocks


# -------------- Cleaning and extracting webpage-------------

def extract_page_data(
    html,
    requested_url,
    final_url
):
    """
    Extract useful information from webpage HTML.
    """

    soup = BeautifulSoup(
        html,
        "html.parser"
    )

    # Bupa renders text from modular-text attributes. Preserve the original HTML
    # and record each decoded component separately; do not execute page scripts.
    component_evidence = []
    if urlparse(final_url).hostname in {'www.bupa.com.au', 'bupa.com.au'}:
        for index, node in enumerate(soup.find_all('modular-text', attrs={'text': True})):
            fragment = BeautifulSoup(node['text'] if '<' in node['text'] else escape(node['text']), 'html.parser')
            component_evidence.append({
                'component_index': index, 'attribute': 'text',
                'raw_attribute': node['text'], 'text': fragment.get_text(' ', strip=True)})
            # Replace with extracted fragment for paragraph/link processing as well.
            wrapper = soup.new_tag('div')
            wrapper.append(fragment)
            node.replace_with(wrapper)

    # Read embedded page data before scripts are removed below; page scripts are
    # parsed as JSON only and are never executed.
    embedded_offers = structured_offers(soup, final_url)


    # -------------- Remove content that is not useful for analysis --------------

    for tag in soup([
        "script",
        "style",
        "noscript",
        "svg"
    ]):

        tag.decompose()


    # -------------- Page title --------------

    page_title = ""

    if soup.title:

        page_title = soup.title.get_text(
            " ",
            strip=True
        )


    # -------------- Headings --------------

    headings = []

    for tag in soup.find_all(
        ["h1", "h2", "h3"]
    ):

        text = tag.get_text(
            " ",
            strip=True
        )

        if text:

            headings.append(text)


    # Paragraphs/ list

    paragraphs = []

    for tag in soup.find_all(
        ["p", "li"]
    ):

        text = tag.get_text(
            " ",
            strip=True
        )

        if text:

            paragraphs.append(text)


    # Remove duplicate paragraphs while
    # keeping their original order.

    paragraphs = list(
        dict.fromkeys(paragraphs)
    )


    # -------------- LINKS --------------

    links = []

    for tag in soup.find_all(
        "a",
        href=True
    ):

        link = urljoin(
            final_url,
            tag["href"]
        )

        if link.startswith(
            ("http://", "https://")
        ):

            links.append(link)


    links = list(
        dict.fromkeys(links)
    )


    # -------------- FULL TEXT --------------

    full_text = "\n".join(
        paragraphs
    )


    # CONTENT HASH
    content_hash = sha256(
        full_text.encode("utf-8")
    ).hexdigest()


    # RETURN STRUCTURED RESULT

    return {

        "raw_html": html,
        "snapshot_schema_version": "1.3",
        "media_type": HTML_MEDIA_TYPE,
        "component_evidence": component_evidence,
        "raw_html_hash": sha256(html.encode("utf-8")).hexdigest(),
        "quality_warnings": [] if paragraphs else ["no_paragraphs_extracted"],

        "promotion_blocks": promotion_blocks(soup, final_url),

        "structured_offers": embedded_offers,

        "requested_url":
            requested_url,

        "final_url":
            final_url,

        "domain":
            urlparse(
                final_url
            ).netloc,

        "page_title":
            page_title,

        "headings":
            headings,

        "paragraphs":
            paragraphs,

        "full_text":
            full_text,

        "word_count":
            len(
                full_text.split()
            ),

        "number_of_links":
            len(links),

        "links":
            links,

        "content_hash":
            content_hash,

        "collected_at":
            datetime.now(
                timezone.utc
            ).isoformat()
    }


# -------------- Extracting PDF documents --------------

def pdf_paragraphs(text):
    """
    Blank lines separate paragraphs; lines wrapped inside one are rejoined.

    A generator that emits no blank line yields a single paragraph. No text is
    lost, but clause-level granularity is unavailable for such a document.
    """

    paragraphs = []

    for block in re.split(r"\n\s*\n", text):

        joined = " ".join(block.split())

        if joined:

            paragraphs.append(joined)

    return list(dict.fromkeys(paragraphs))


def pdf_links(reader, final_url):
    """Absolute link annotations; the extracted text is not re-scanned for URLs."""

    links = []

    for page in reader.pages:

        for annotation in page.get("/Annots") or []:

            try:
                action = annotation.get_object().get("/A")
                uri = action.get("/URI") if action else None
            except (AttributeError, KeyError, TypeError):
                continue

            if uri:

                link = urljoin(final_url, str(uri))

                if link.startswith(("http://", "https://")):

                    links.append(link)

    return list(dict.fromkeys(links))


def extract_pdf_data(
    content,
    requested_url,
    final_url
):
    """
    Extract text from a PDF source; fund terms are frequently published as PDF.

    Default extraction follows the content stream, which keeps the multi-column
    terms layouts used by health funds in reading order. Layout mode interleaves
    those columns, so it is not used.
    """

    if PdfReader is None:

        raise RuntimeError(
            "pypdf is required to collect PDF sources; install requirements.txt")

    reader = PdfReader(BytesIO(content))

    text = "\n".join(page.extract_text() or "" for page in reader.pages)

    paragraphs = pdf_paragraphs(text)

    links = pdf_links(reader, final_url)

    full_text = "\n".join(paragraphs)

    try:
        page_title = (reader.metadata or {}).get("/Title") or ""
    except (AttributeError, KeyError, TypeError, ValueError):
        page_title = ""

    return {

        # Source bytes are not embedded in JSON; the hash still detects a changed
        # document, including one whose text cannot be extracted.
        "raw_html": None,
        "raw_html_hash": None,
        "raw_document_hash": sha256(content).hexdigest(),

        "media_type": PDF_MEDIA_TYPE,
        "pdf_page_count": len(reader.pages),
        "snapshot_schema_version": "1.3",

        "component_evidence": [],
        "promotion_blocks": [],
        "structured_offers": [],

        "quality_warnings": [] if paragraphs else ["no_text_extracted"],

        "requested_url": requested_url,
        "final_url": final_url,
        "domain": urlparse(final_url).netloc,

        "page_title": page_title,
        "headings": [],
        "paragraphs": paragraphs,
        "full_text": full_text,
        "word_count": len(full_text.split()),

        "number_of_links": len(links),
        "links": links,

        "content_hash": sha256(full_text.encode("utf-8")).hexdigest(),

        "collected_at": datetime.now(timezone.utc).isoformat()
    }


def extract_document_data(
    payload,
    requested_url,
    final_url,
    media_type=HTML_MEDIA_TYPE
):
    """Route a downloaded payload to the extractor for its media type."""

    if is_pdf(payload, media_type):

        return extract_pdf_data(
            payload,
            requested_url,
            final_url
        )

    return extract_page_data(
        payload,
        requested_url,
        final_url
    )


# SCRAPE ONE SOURCE

def scrape_source(source):
    """
    Download and extract one configured source.
    """

    print(
        f"Collecting "
        f"{source['organisation']} "
        f"- {source['market_segment']}"
    )

    collection_method = "http"
    try:
        payload, final_url, status_code, media_type = download_page(source["url"])
    except requests.HTTPError as exc:
        response = getattr(exc, "response", None)
        if (source.get("collection_method") != "browser_on_403" or
                response is None or response.status_code != 403):
            raise
        payload, final_url, status_code, media_type = download_page_browser(
            source["url"], headless=source.get("browser_headless", True)
        )
        collection_method = "browser"

    data = extract_document_data(
        payload,
        source["url"],
        final_url,
        media_type
    )

    # Add source information.

    data["source_id"] = (
        source["source_id"]
    )

    data["organisation"] = (
        source["organisation"]
    )

    data["market_segment"] = (
        source["market_segment"]
    )

    data["http_status"] = (
        status_code
    )

    data["collection_method"] = collection_method

    data["source_metadata"] = {k: v for k, v in source.items()
                               if k not in {"url", "source_id", "organisation"}}
    return data
